// ============================================================
//  Mang: WiFi (STA + AP du phong), NTP, thoi tiet, Web, Bluetooth
//  Web: http://buddy.local  hoac  http://<IP>  (chua co WiFi: noi mang "ESP32-Buddy", mat khau 12345678, http://192.168.4.1)
// ============================================================
#pragma once
#include "core.h"

WebServer server(80);
#if ENABLE_BT
BluetoothSerial SerialBT;
#endif
bool btUp = false;
uint32_t wfT = 0, wfRetry = 0;
bool webStarted = false, mdnsUp = false;
bool wifiRestartPending = false;
uint32_t wifiRestartAt = 0;

void scheduleWifiRestart(uint32_t delayMs = 500) {
  wifiRestartPending = true;
  wifiRestartAt = millis() + delayMs;
}

String wfIp() {
  if (wfState == WF_STA) return WiFi.localIP().toString();
  if (wfState == WF_AP) return WiFi.softAPIP().toString();
  return String("");
}

// ---------- NTP ----------
void onNtp(struct timeval *tv) { ntpFlag = true; }
void ntpSync() { configTime(0, 0, "pool.ntp.org", "time.google.com", "time.cloudflare.com"); }

// ---------- WiFi ----------
void startAP() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP("ESP32-Buddy", "12345678");
  wfState = WF_AP;
}
void wifiStart() {
  if (!S.wifiOn) { wfState = WF_OFF; return; }
  if (wifiSsid.length()) {
    WiFi.mode(WIFI_STA);
    WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
    wfState = WF_CONNECTING;
    wfT = millis();
  } else startAP();
}
void wifiRestart() {
  wifiRestartPending = false;
  // Rebind web server sau khi doi AP/STA hoac bat/tat WiFi.
  if (webStarted) { server.stop(); webStarted = false; }
  if (mdnsUp) { MDNS.end(); mdnsUp = false; }
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  wfState = WF_OFF;
  delay(50);
  wifiStart();
}
void onWifiUp() {
  if (!mdnsUp) {
    if (MDNS.begin("buddy")) { MDNS.addService("http", "tcp", 80); mdnsUp = true; }
  }
  sntp_set_time_sync_notification_cb(onNtp);
  ntpSync();
  wxReq = true;
  showPopup("WiFi", "Da noi " + WiFi.localIP().toString());
}

// ---------- Thoi tiet (Open-Meteo, khong can API key) ----------
float jsonNum(const String &s, const char *key) {
  String k = String("\"") + key + "\"";
  int p = s.indexOf(k);
  if (p < 0) return NAN;
  p = s.indexOf(':', p + k.length());
  if (p < 0) return NAN;
  p++;
  while (p < (int)s.length() && (s[p] == ' ' || s[p] == '\t' || s[p] == '\r' || s[p] == '\n')) p++;
  if (p >= (int)s.length() || s.substring(p, p + 4) == "null") return NAN;
  return s.substring(p).toFloat();
}
bool fetchWeather() {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(9000);
  String url = String("https://api.open-meteo.com/v1/forecast?latitude=") + String(geoLat, 4) + "&longitude=" + String(geoLon, 4) +
               "&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,weather_code,wind_speed_10m&timezone=auto";
  if (!http.begin(client, url)) return false;
  int code = http.GET();
  if (code != 200) { http.end(); return false; }
  String body = http.getString();
  http.end();
  int p = body.indexOf("\"current\"");
  if (p < 0) return false;
  String cur = body.substring(p);
  float t = jsonNum(cur, "temperature_2m");
  float h = jsonNum(cur, "relative_humidity_2m");
  float w = jsonNum(cur, "wind_speed_10m");
  float c = jsonNum(cur, "weather_code");
  float feels = jsonNum(cur, "apparent_temperature");
  float day = jsonNum(cur, "is_day");
  if (isnan(t) || isnan(c)) return false;
  wx.t = t;
  wx.feels = isnan(feels) ? t : feels;
  wx.hum = isnan(h) ? 0 : clampi((int)h, 0, 100);
  wx.wind = isnan(w) ? 0 : w;
  wx.code = (int)c;
  wx.isDay = isnan(day) ? true : day >= 0.5f;
  wx.at = millis();
  wx.ok = true;
  wxFailed = false;
  dirty = true;
  return true;
}
void weatherTask(void *) {
  for (;;) {
    if (wxReq) {
      wxReq = false;
      wxBusy = true;
      bool ok = fetchWeather();
      wxFailed = !ok;
      wxBusy = false;
      if (screen == SC_WEATHER) dirty = true;
    }
    vTaskDelay(pdMS_TO_TICKS(500));
  }
}


// ---------- xac thuc trang web bang PIN (chan nguoi la trong mang WiFi) ----------
uint8_t authFails = 0;
uint32_t authLockUntil = 0, authFailAt = 0;
bool webAuth() {
  if (!webPin.length()) return true;
  uint32_t now = millis();
  if (authLockUntil && (int32_t)(now - authLockUntil) < 0) { server.send(429, "text/plain", "LOCK"); return false; }
  if (server.arg("p") == webPin) { authFails = 0; return true; }
  if (server.arg("p").length() && now - authFailAt < 60000UL) authFails++;
  else if (server.arg("p").length()) authFails = 1;
  if (server.arg("p").length()) authFailAt = now;
  if (authFails >= 6) { authLockUntil = now + 60000UL; authFails = 0; }
  server.send(401, "text/plain", "PIN");
  return false;
}

// ---------- Trang web: xem page.h (PAGE2) va web2.h ----------

void webSetup() {
  server.on("/api/cmd", HTTP_POST, []() {
    if (!webAuth()) return;
    String line = server.arg("plain");
    StrOut o;
    processLine(line, o);
    server.send(200, "text/plain; charset=utf-8", o.s);
  });
  server.on("/api/state", HTTP_GET, []() {
    if (!webAuth()) return;
    StrOut o;
    processLine("INFO", o);
    processLine("NET", o);
    server.send(200, "text/plain; charset=utf-8", o.s);
  });
  server.on("/api/weather", HTTP_GET, []() {
    if (!webAuth()) return;
    String j = String("{\"ok\":") + (wx.ok ? "true" : "false") +
      ",\"t\":" + (wx.ok ? String(wx.t, 1) : String("null")) +
      ",\"feels\":" + (wx.ok ? String(wx.feels, 1) : String("null")) +
      ",\"hum\":" + String(wx.hum) + ",\"wind\":" + String(wx.wind, 1) +
      ",\"code\":" + String(wx.code) + ",\"day\":" + String(wx.isDay ? 1 : 0) +
      ",\"age\":" + String(wx.ok ? (millis() - wx.at) / 60000UL : 0) +
      ",\"busy\":" + (wxBusy ? "true" : "false") +
      ",\"failed\":" + (wxFailed ? "true" : "false") +
      ",\"lat\":" + String(geoLat, 5) + ",\"lon\":" + String(geoLon, 5) + "}";
    server.send(200, "application/json", j);
  });
  server.on("/api/files", HTTP_GET, []() {
    if (!webAuth()) return;
    String j = "[";
    File root = LittleFS.open("/");
    File f = root.openNextFile();
    bool first = true;
    while (f) {
      if (!f.isDirectory()) {
        String n = f.name();
        if (n.startsWith("/")) n = n.substring(1);
        if (!first) j += ",";
        first = false;
        j += "{\"n\":\"" + n + "\",\"s\":" + String((unsigned long)f.size()) + "}";
      }
      f = root.openNextFile();
    }
    j += "]";
    server.send(200, "application/json", j);
  });
  server.on("/api/put", HTTP_POST, []() {
    if (!webAuth()) return;
    String p = cleanPath(server.arg("n"));
    String body = server.arg("plain");
    if (!p.length()) { server.send(400, "text/plain", "ERR ten file"); return; }
    if (body.length() > 48000) { server.send(413, "text/plain", "ERR qua lon (toi da 48KB)"); return; }
    if ((size_t)(LittleFS.totalBytes() - LittleFS.usedBytes()) < body.length() + 4096) { server.send(507, "text/plain", "ERR day bo nho"); return; }
    File f = LittleFS.open(p, "w");
    if (!f) { server.send(500, "text/plain", "ERR mo file"); return; }
    size_t written = f.write((const uint8_t *)body.c_str(), body.length());
    f.close();
    if (written != body.length()) { LittleFS.remove(p); server.send(507, "text/plain", "ERR ghi file khong day du"); return; }
    if (p == "/notes.txt") loadNotes();
    if (p == "/todo.txt") loadTodos();
    if (screen == SC_RDLIST) refreshTxt();
    if (screen == SC_FILES) refreshFiles();
    showPopup("Da nhan file", p.substring(1));
    server.send(200, "text/plain", "OK PUT " + p + " " + String((unsigned long)written));
  });
  server.on("/f", HTTP_GET, []() {
    if (!webAuth()) return;
    String p = cleanPath(server.arg("n"));
    if (!p.length() || !LittleFS.exists(p)) { server.send(404, "text/plain", "khong thay file"); return; }
    File f = LittleFS.open(p, "r");
    server.streamFile(f, "text/plain; charset=utf-8");
    f.close();
  });
  server.onNotFound([]() { server.send(404, "text/plain", "404"); });
}

// ---------- Bluetooth Serial ----------
void buddyBtStart() {
#if ENABLE_BT
  if (SerialBT.begin("ESP32-Buddy")) btUp = true;
#endif
}

// ---------- Vong lap mang ----------
void netLoop() {
  uint32_t now = millis();
  if (wfState == WF_CONNECTING) {
    if (WiFi.status() == WL_CONNECTED) { wfState = WF_STA; onWifiUp(); }
    else if (now - wfT > 20000) {
      WiFi.disconnect(true);
      startAP();
      showPopup("WiFi", "Khong noi duoc, mo AP ESP32-Buddy");
    }
  } else if (wfState == WF_STA && WiFi.status() != WL_CONNECTED && now - wfRetry > 10000) {
    wfRetry = now;
    WiFi.reconnect();
  }
  if (!webStarted && (wfState == WF_STA || wfState == WF_AP)) { server.begin(); webStarted = true; }
  if (wfState == WF_STA || wfState == WF_AP) server.handleClient();
  if (wifiRestartPending && (int32_t)(now - wifiRestartAt) >= 0) wifiRestart();
  if (ntpFlag) {
    ntpFlag = false;
    applyTime((uint32_t)time(nullptr), 3, true);
    dirty = true;
  }
  static uint32_t lastWx = 0;
  if (wfState == WF_STA && now - lastWx > 1800000UL) { lastWx = now; wxReq = true; }
}
