// ============================================================
//  Tra cuu lenh Linux ngay tren thiet bi (khong can may tinh): ~150 lenh, tim theo ten / mo ta / nhom
//  Dinh dang: "nhom|lenh|mo ta|vi du"   (chu khong dau de hien thi tren OLED)
// ============================================================
#pragma once
#include "core.h"
#include "apps.h"

static const char *const CHEAT[] PROGMEM = {
  // --- file & thu muc ---
  "file|ls|Liet ke file|ls -lah   (-t theo gio, -S theo size)",
  "file|cd|Doi thu muc|cd ~  |  cd -  (quay lai)  |  cd ..",
  "file|pwd|Hien thu muc hien tai|pwd",
  "file|cp|Sao chep|cp -r thumuc dich/",
  "file|mv|Di chuyen / doi ten|mv cu.txt moi.txt",
  "file|rm|Xoa (KHONG co thung rac)|rm -ri thumuc   (-i hoi lai)",
  "file|mkdir|Tao thu muc|mkdir -p a/b/c",
  "file|rmdir|Xoa thu muc rong|rmdir ten",
  "file|touch|Tao file rong / doi gio sua|touch ghichu.txt",
  "file|ln|Tao lien ket|ln -s that tat   (symlink)",
  "file|tree|Hien cay thu muc|tree -L 2",
  "file|stat|Chi tiet file|stat file",
  "file|file|Doan loai file|file anh.bin",
  "file|du|Dung luong thu muc|du -sh * | sort -h",
  "file|df|Dung luong o dia|df -h",
  "file|find|Tim file|find . -name '*.png' -mtime -3",
  "file|fd|Tim file nhanh (fd-find)|fd ten",
  "file|locate|Tim file bang chi muc|locate ten  (sudo updatedb)",
  "file|chmod|Doi quyen|chmod +x run.sh  |  chmod 644 f",
  "file|chown|Doi chu so huu|sudo chown user:user file",
  "file|ncdu|Xem dung luong dang cay|ncdu /home",
  "file|rsync|Dong bo / sao luu|rsync -avh --progress a/ b/",
  "file|tar|Nen / giai nen tar|tar -czf a.tgz thu  |  tar -xf a.tgz",
  "file|zip|Nen zip|zip -r a.zip thu   |  unzip a.zip",
  "file|7z|Nen 7z|7z a x.7z thu  |  7z x x.7z",
  "file|trash|Bo vao thung rac (trash-cli)|trash-put file",
  "file|mount|Gan thiet bi|sudo mount /dev/sdb1 /mnt",
  "file|umount|Thao thiet bi|sudo umount /mnt",
  "file|lsblk|Liet ke o dia|lsblk -f",
  "file|dd|Ghi anh o dia (NGUY HIEM)|sudo dd if=a.iso of=/dev/sdX bs=4M status=progress",
  // --- noi dung / van ban ---
  "text|cat|In noi dung file|cat file  |  cat a b > c",
  "text|bat|cat dep co mau (bat)|bat file",
  "text|less|Xem file dai|less file   (/tim, q thoat)",
  "text|head|Dong dau|head -n 20 file",
  "text|tail|Dong cuoi / theo doi log|tail -f log",
  "text|grep|Tim trong noi dung|grep -rn 'chu' .   (-i bo qua hoa/thuong)",
  "text|rg|grep nhanh (ripgrep)|rg 'chu' --type py",
  "text|sed|Thay the chu|sed -i 's/cu/moi/g' file",
  "text|awk|Xu ly cot|awk '{print $1}' file",
  "text|cut|Cat cot|cut -d: -f1 /etc/passwd",
  "text|sort|Sap xep|sort -u file  (-n so, -r nguoc)",
  "text|uniq|Bo dong trung|sort f | uniq -c",
  "text|wc|Dem dong/tu|wc -l file",
  "text|tr|Doi/xoa ky tu|tr a-z A-Z",
  "text|diff|So sanh 2 file|diff -u a b",
  "text|nano|Soan van ban don gian|nano f  (Ctrl+O luu, Ctrl+X thoat)",
  "text|vim|Soan van ban vim|vim f  (i go, Esc, :wq luu, :q! bo)",
  "text|xargs|Truyen ket qua thanh doi so|find . -name '*.tmp' | xargs rm",
  "text|jq|Doc JSON|curl -s url | jq '.data[]'",
  "text|tee|Vua in vua ghi file|cmd | tee out.txt",
  "text|echo|In chu|echo $PATH",
  "text|column|Can cot|mount | column -t",
  "text|fzf|Tim mo (fuzzy)|history | fzf   |  Ctrl+R (fish)",
  // --- he thong ---
  "sys|uname|Thong tin kernel|uname -a",
  "sys|uptime|Thoi gian chay|uptime -p",
  "sys|free|Bo nho RAM|free -h",
  "sys|top|Tien trinh thoi gian thuc|top   (q thoat)",
  "sys|htop|top dep hon|htop   (F9 kill)",
  "sys|btop|Theo doi tong hop dep|btop",
  "sys|ps|Danh sach tien trinh|ps aux | grep ten",
  "sys|kill|Dung tien trinh|kill PID  |  kill -9 PID (ep)",
  "sys|pkill|Dung theo ten|pkill firefox",
  "sys|killall|Dung theo ten|killall ten",
  "sys|lscpu|Thong tin CPU|lscpu",
  "sys|lsusb|Thiet bi USB|lsusb",
  "sys|lspci|Thiet bi PCI (GPU...)|lspci -k",
  "sys|dmesg|Nhat ky kernel|sudo dmesg -w",
  "sys|journalctl|Nhat ky systemd|journalctl -b -p err   (-f theo doi)",
  "sys|systemctl|Quan ly dich vu|systemctl status|restart|enable ten",
  "sys|systemctl --user|Dich vu cua user|systemctl --user restart pipewire",
  "sys|sensors|Nhiet do / quat|sensors",
  "sys|nvidia-smi|Thong tin GPU NVIDIA|nvidia-smi",
  "sys|lsmod|Module kernel dang nap|lsmod | grep ten",
  "sys|hostnamectl|Ten may & he dieu hanh|hostnamectl",
  "sys|timedatectl|Gio he thong|timedatectl set-ntp true",
  "sys|date|Ngay gio|date '+%F %T'",
  "sys|cal|Lich thang|cal -3",
  "sys|env|Bien moi truong|env | sort",
  "sys|which|Duong dan lenh|which fish",
  "sys|whereis|Tim vi tri lenh|whereis ls",
  "sys|type|Lenh la gi|type ls",
  "sys|alias|Tao lenh tat|alias ll='ls -lah'",
  "sys|history|Lich su lenh|history | tail",
  "sys|watch|Chay lai moi N giay|watch -n 2 'free -h'",
  "sys|time|Do thoi gian chay|time lenh",
  "sys|nohup|Chay nen khong bi tat|nohup lenh &",
  "sys|tmux|Nhieu cua so terminal|tmux new -s a | Ctrl+b d  | tmux a",
  "sys|screen|Phien terminal|screen -S a  | Ctrl+a d",
  "sys|crontab|Hen gio chay|crontab -e   (m h d M w lenh)",
  "sys|shutdown|Tat / khoi dong lai|shutdown now | reboot",
  "sys|loginctl|Phien dang nhap|loginctl lock-session",
  // --- nguoi dung & quyen ---
  "user|sudo|Chay voi quyen root|sudo -i  (vao root)",
  "user|su|Doi nguoi dung|su - ten",
  "user|whoami|Ten nguoi dung|whoami",
  "user|id|UID & nhom|id",
  "user|passwd|Doi mat khau|passwd",
  "user|useradd|Them nguoi dung|sudo useradd -m ten",
  "user|usermod|Sua nguoi dung|sudo usermod -aG docker $USER",
  "user|groups|Nhom cua toi|groups",
  "user|w|Ai dang dang nhap|w",
  "user|last|Lich su dang nhap|last | head",
  // --- mang ---
  "net|ip|Dia chi / tuyen|ip -br a  |  ip r",
  "net|ping|Kiem tra ket noi|ping -c 4 1.1.1.1",
  "net|ss|Cong dang mo|ss -tulpn",
  "net|curl|Tai / goi HTTP|curl -L -O url  |  curl -I url",
  "net|wget|Tai file|wget -c url",
  "net|ssh|Dang nhap tu xa|ssh user@host -p 22",
  "net|ssh-keygen|Tao khoa SSH|ssh-keygen -t ed25519",
  "net|ssh-copy-id|Dua khoa len may|ssh-copy-id user@host",
  "net|scp|Chep qua SSH|scp f user@host:~/",
  "net|nmcli|Quan ly mang|nmcli dev wifi list | nmcli dev wifi connect SSID password P",
  "net|iwctl|WiFi (iwd)|iwctl station wlan0 scan; ... connect SSID",
  "net|dig|Tra DNS|dig +short ten.com",
  "net|nslookup|Tra DNS|nslookup ten.com",
  "net|traceroute|Duong di goi tin|traceroute ten.com  (hoac mtr)",
  "net|mtr|ping+traceroute|mtr ten.com",
  "net|nmap|Quet cong|nmap -sV host  (chi quet may minh)",
  "net|tailscale|VPN mesh|tailscale up | tailscale status",
  "net|python -m http.server|May chu web nhanh|python -m http.server 8000",
  "net|ufw|Tuong lua|sudo ufw enable | ufw allow 22",
  "net|nc|Netcat|nc -lvp 9000",
  // --- goi phan mem ---
  "pkg|pacman -S|Cai goi (Arch)|sudo pacman -S ten",
  "pkg|pacman -Syu|Cap nhat he thong|sudo pacman -Syu",
  "pkg|pacman -Rns|Go goi + phu thuoc|sudo pacman -Rns ten",
  "pkg|pacman -Ss|Tim goi|pacman -Ss ten",
  "pkg|pacman -Qi|Thong tin goi|pacman -Qi ten",
  "pkg|pacman -Qdtq|Goi mo coi|pacman -Qdtq | sudo pacman -Rns -",
  "pkg|paru|AUR helper|paru -S ten",
  "pkg|yay|AUR helper|yay -S ten",
  "pkg|checkupdates|Xem cap nhat (khong cai)|checkupdates",
  "pkg|apt|Cai goi (Debian)|sudo apt update && sudo apt install ten",
  "pkg|dnf|Cai goi (Fedora)|sudo dnf install ten",
  "pkg|flatpak|Ung dung flatpak|flatpak install flathub ten",
  "pkg|pip|Goi Python|pip install ten  (dung venv)",
  "pkg|npm|Goi Node|npm i ten",
  "pkg|cargo|Goi Rust|cargo install ten",
  // --- git ---
  "git|git status|Trang thai|git status -sb",
  "git|git add|Them vao commit|git add -p  |  git add .",
  "git|git commit|Luu thay doi|git commit -m 'noi dung'",
  "git|git push|Day len remote|git push -u origin main",
  "git|git pull|Keo ve|git pull --rebase",
  "git|git clone|Sao chep repo|git clone --depth 1 url",
  "git|git log|Lich su|git log --oneline --graph -20",
  "git|git diff|Xem khac biet|git diff --staged",
  "git|git branch|Nhanh|git switch -c ten  |  git branch -d ten",
  "git|git stash|Cat tam thay doi|git stash | git stash pop",
  "git|git restore|Huy sua file|git restore file",
  "git|git reset|Lui commit|git reset --soft HEAD~1",
  "git|git rebase|Rebase|git rebase -i HEAD~3",
  "git|git remote|Remote|git remote -v",
  // --- giao dien / Hyprland / am thanh ---
  "ui|hyprctl|Dieu khien Hyprland|hyprctl clients | hyprctl reload",
  "ui|hyprctl monitors|Man hinh|hyprctl monitors",
  "ui|grim|Chup man hinh Wayland|grim -g \"$(slurp)\" a.png",
  "ui|slurp|Chon vung man hinh|slurp",
  "ui|wl-copy|Chep vao clipboard|echo ab | wl-copy",
  "ui|wl-paste|Dan tu clipboard|wl-paste",
  "ui|wpctl|Am thanh PipeWire|wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+",
  "ui|pactl|Am thanh Pulse|pactl list short sinks",
  "ui|playerctl|Dieu khien nhac|playerctl play-pause | next",
  "ui|brightnessctl|Do sang|brightnessctl set 10%+",
  "ui|wlrctl|Chuot/phim Wayland|wlrctl pointer move 10 0",
  "ui|wtype|Go phim Wayland|wtype 'xin chao'",
  "ui|ydotool|Gia lap input (uinput)|sudo ydotoold & ydotool click 0xC0",
  "ui|xdg-open|Mo bang ung dung mac dinh|xdg-open file.pdf",
  "ui|notify-send|Gui thong bao|notify-send 'Tieu de' 'Noi dung'",
  "ui|fc-list|Liet ke font|fc-list | grep -i ten",
  "ui|qs|Quickshell|qs -c study  |  qs kill",
  // --- lap trinh / esp32 ---
  "dev|pio run|Bien dich PlatformIO|pio run  (-t upload nap)",
  "dev|pio run -t upload|Nap firmware|pio run -t upload",
  "dev|pio device monitor|Mo cong serial|pio device monitor -b 115200",
  "dev|python -m venv|Tao venv|python -m venv .venv && . .venv/bin/activate.fish",
  "dev|make|Bien dich|make -j$(nproc)",
  "dev|gcc|Bien dich C|gcc -O2 -o a a.c",
  "dev|docker|Container|docker ps | docker run --rm -it img",
  "dev|code|Mo VS Code|code .",
  "dev|ls /dev/tty*|Tim cong ESP32|ls /dev | grep -E 'ttyUSB|ttyACM'",
  "dev|usermod -aG uucp|Cap quyen cong serial (Arch)|sudo usermod -aG uucp $USER  (dang nhap lai)",
  // --- fish shell ---
  "fish|set -x|Dat bien moi truong|set -x EDITOR nano",
  "fish|abbr|Viet tat tu mo rong|abbr -a gs git status",
  "fish|funcsave|Luu ham|funcsave ten",
  "fish|fish_add_path|Them vao PATH|fish_add_path ~/.local/bin",
  "fish|Ctrl+R|Tim lich su|Ctrl+R  trong fish",
  "fish|!!|Lap lai lenh truoc (bash)|sudo !!   (fish: sudo $history[1])",
  // --- phim tat terminal ---
  "key|Ctrl+C|Dung lenh|Ctrl+C",
  "key|Ctrl+D|Thoat shell / EOF|Ctrl+D",
  "key|Ctrl+Z|Tam dung (bg/fg)|Ctrl+Z  roi  bg",
  "key|Ctrl+L|Xoa man hinh|Ctrl+L",
  "key|Ctrl+A|Ve dau dong|Ctrl+A   (Ctrl+E cuoi dong)",
  "key|Ctrl+W|Xoa tu truoc|Ctrl+W   (Ctrl+U xoa dong)",
};
static const int CHEAT_N = sizeof(CHEAT) / sizeof(CHEAT[0]);

String lowerAscii(String s) { s.toLowerCase(); return s; }
String cheatField(int idx, int f) {                 // f: 0 nhom, 1 lenh, 2 mo ta, 3 vi du
  String r = String(CHEAT[idx]);
  int st = 0;
  for (int k = 0; k < f; k++) { int p = r.indexOf('|', st); if (p < 0) return ""; st = p + 1; }
  int e = (f == 3) ? (int)r.length() : r.indexOf('|', st);
  if (e < 0) e = r.length();
  return r.substring(st, e);
}

std::vector<int16_t> chRes;                         // ket qua tim
String chQ;
int chSel = 0;
bool chTip = false;

void cheatFilter(const String &q) {
  chQ = q;
  chQ.trim();
  chRes.clear();
  String ql = lowerAscii(chQ);
  // moi tu cach nhau dau cach phai xuat hien (ten, nhom hoac mo ta)
  std::vector<String> w;
  int i = 0;
  while (i < (int)ql.length()) {
    int e = ql.indexOf(' ', i);
    if (e < 0) e = ql.length();
    if (e > i) w.push_back(ql.substring(i, e));
    i = e + 1;
  }
  for (int k = 0; k < CHEAT_N; k++) {
    if (w.empty()) { chRes.push_back(k); continue; }
    String hay = lowerAscii(String(CHEAT[k]));
    bool ok = true;
    for (size_t j = 0; j < w.size() && ok; j++) if (hay.indexOf(w[j]) < 0) ok = false;
    if (ok) chRes.push_back(k);
  }
  // uu tien: ten lenh bat dau bang tu khoa
  if (!w.empty()) {
    std::stable_sort(chRes.begin(), chRes.end(), [&](int16_t a, int16_t b) {
      bool pa = lowerAscii(cheatField(a, 1)).startsWith(w[0]);
      bool pb = lowerAscii(cheatField(b, 1)).startsWith(w[0]);
      return pa && !pb;
    });
  }
  chSel = 0;
}
void cheatSearchOpen(const String &q) {
  cheatFilter(q);
  go(SC_CHEAT);
}
String cheatDetail(int idx) {
  String d = cheatField(idx, 1) + "  [" + cheatField(idx, 0) + "]\n";
  d += cheatField(idx, 2) + "\n\n$ ";
  d += cheatField(idx, 3);
  return d;
}
void cheatTip() {                                   // meo ngau nhien
  int k = (int)(esp_random() % CHEAT_N);
  showPopup(cheatField(k, 1), cheatField(k, 2) + ": " + cheatField(k, 3));
}

void drawCheat() {
  String h = chQ.length() ? "? " + chQ : String("Lenh Linux");
  if (h.length() > 15) h = h.substring(0, 15);
  oled.setCursor(0, 1);
  oled.print(h);
  char b[24];
  snprintf(b, sizeof(b), "%d/%d", chRes.empty() ? 0 : chSel + 1, (int)chRes.size());
  oled.setCursor(128 - 6 * (int)strlen(b), 1);
  oled.print(b);
  oled.drawFastHLine(0, 10, 128, C_ON);
  if (chRes.empty()) {
    centerText("Khong thay lenh nao", 22, 1);
    centerText("Thu tu khoa khac", 34, 1);
    centerText("hoac hoi PC (man)", 46, 1);
    return;
  }
  std::vector<String> names, vals;
  for (size_t i = 0; i < chRes.size(); i++) { names.push_back(cheatField(chRes[i], 1)); vals.push_back(""); }
  drawRows(names, nullptr, chSel, 13, 3);
  int idx = chRes[chSel];
  String desc = cheatField(idx, 2);
  oled.drawFastHLine(0, 44, 128, C_ON);
  oled.setCursor(0, 47);
  oled.print(desc.substring(0, 21));
  oled.setCursor(0, 56);
  oled.print(String("$ ") + cheatField(idx, 3).substring(0, 19));
}
void handleCheat(int e) {
  int n = (int)chRes.size();
  if (e == EV_UP && n) chSel = (chSel + n - 1) % n;
  else if (e == EV_DOWN && n) chSel = (chSel + 1) % n;
  else if (e == EV_OK && n) openViewer(cheatField(chRes[chSel], 1), cheatDetail(chRes[chSel]));
  else if (e == EV_BACK) go(SC_MENU);
}
