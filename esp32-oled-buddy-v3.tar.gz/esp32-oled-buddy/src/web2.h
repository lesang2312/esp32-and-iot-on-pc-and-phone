// ============================================================
//  Web API v3 cho trang dien thoai (page.h)
//    GET  /            trang giao dien
//    GET  /api/pcs     toan bo trang thai (PC, DT, cam bien, cai dat) dang JSON
//    GET  /api/view    ket qua lenh/man moi nhat tu PC
//    GET  /api/cheat   tra cuu lenh Linux  (?q=tu khoa)
//    GET/POST /api/hooks   danh sach webhook (/hooks.txt)
// ============================================================
#pragma once
#include "core.h"
#include "net.h"
#include "pc.h"
#include "cheat.h"
#include "smart.h"
#include "page.h"

String jesc(const String &s) {
  String o;
  for (unsigned i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '"' || c == '\\') { o += '\\'; o += c; }
    else if (c == '\n') o += "\\n";
    else if ((uint8_t)c >= 32 && (uint8_t)c < 127) o += c;
  }
  return o;
}
String jnum(float v, int d = 1) { return isnan(v) ? String("null") : String(v, d); }

String buildPcsJson() {
  String j = "{";
  j += "\"fw\":\"" FW_VER "\",\"ip\":\"" + wfIp() + "\",\"heap\":" + String((unsigned)ESP.getFreeHeap()) + ",\"upe\":" + String((unsigned long)(millis() / 1000));
  j += ",\"link\":" + String(pcLinked() ? 1 : 0) + ",\"fresh\":" + String(pcxFresh() ? 1 : 0) + ",\"name\":\"" + jesc(pcName) + "\"";
  j += ",\"cpu\":" + String(pcx.cpu) + ",\"mem\":" + String(pcx.mem) + ",\"swap\":" + String(pcx.swap) + ",\"temp\":" + String(pcx.temp) + ",\"disk\":" + String(pcx.disk);
  j += ",\"bat\":" + String(pcx.bat) + ",\"chg\":" + String(pcx.chg) + ",\"bri\":" + String(pcx.bri) + ",\"vol\":" + String(pcx.vol) + ",\"mute\":" + String(pcx.mute > 0 ? 1 : 0);
  j += ",\"rx\":" + String(pcx.rx) + ",\"tx\":" + String(pcx.tx) + ",\"up\":" + String(pcx.upH) + ",\"load\":" + String(pcx.load10);
  j += ",\"win\":\"" + jesc(pcx.win) + "\",\"ws\":\"" + jesc(pcx.ws) + "\",\"media\":\"" + jesc(pcx.media) + "\",\"mstat\":\"" + jesc(pcx.mstat) + "\"";
  j += ",\"share\":\"" + jesc(pcShareUrl) + "\",\"find\":" + String((unsigned long)findSeq) + ",\"view\":" + String((unsigned long)viewSeq);
  j += ",\"sen\":{\"t\":" + jnum(senBestT()) + ",\"hum\":" + jnum(senHum, 0) + ",\"pres\":" + jnum(senPres, 0) + ",\"ldr\":" + String(senLdr) + ",\"vbat\":" + String(vbatPercent()) + "}";
  j += ",\"rules\":" + String((int)S.rules);
  j += ",\"set\":{\"invert\":" + String(S.invert ? 1 : 0) + ",\"flip\":" + String(S.flip ? 1 : 0) + ",\"h24\":" + String(S.h24 ? 1 : 0) + ",\"secs\":" + String(S.secs ? 1 : 0) +
       ",\"night\":" + String(S.night ? 1 : 0) + ",\"abr\":" + String(S.autoBr ? 1 : 0) + ",\"bright\":" + String((int)S.bright) + ",\"mspd\":" + String((int)S.mouseSpd) + "}";
  j += ",\"cmds\":[";
  for (size_t i = 0; i < pcCmdIds.size(); i++) {
    if (i) j += ",";
    j += "[\"" + jesc(pcCmdIds[i]) + "\",\"" + jesc(pcCmdNames[i]) + "\"]";
  }
  j += "]}";
  return j;
}

void webSetup2() {
  server.on("/", HTTP_GET, []() { server.send_P(200, "text/html; charset=utf-8", PAGE2); });
  server.on("/api/pcs", HTTP_GET, []() {
    if (!webAuth()) return;
    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "application/json", buildPcsJson());
  });
  server.on("/api/view", HTTP_GET, []() {
    if (!webAuth()) return;
    server.send(200, "application/json", "{\"seq\":" + String((unsigned long)viewSeq) + ",\"title\":\"" + jesc(viewTitleOut) + "\",\"text\":\"" + jesc(viewTextOut) + "\"}");
  });
  server.on("/api/cheat", HTTP_GET, []() {
    if (!webAuth()) return;
    cheatFilter(server.arg("q"));
    String j = "[";
    int k = 0;
    for (size_t i = 0; i < chRes.size() && k < 25; i++, k++) {
      if (k) j += ",";
      j += "[\"" + jesc(cheatField(chRes[i], 1)) + "\",\"" + jesc(cheatField(chRes[i], 2)) + "\",\"" + jesc(cheatField(chRes[i], 3)) + "\"]";
    }
    j += "]";
    server.send(200, "application/json", j);
  });
  server.on("/api/hooks", HTTP_GET, []() {
    if (!webAuth()) return;
    File f = LittleFS.open("/hooks.txt", "r");
    String t = f ? f.readString() : String("");
    if (f) f.close();
    server.send(200, "text/plain; charset=utf-8", t);
  });
  server.on("/api/hooks", HTTP_POST, []() {
    if (!webAuth()) return;
    String body = server.arg("plain");
    if (body.length() > 2000) { server.send(413, "text/plain", "ERR qua dai"); return; }
    hooksSave(body);
    server.send(200, "text/plain", "OK " + String((int)hooks.size()));
  });
}
