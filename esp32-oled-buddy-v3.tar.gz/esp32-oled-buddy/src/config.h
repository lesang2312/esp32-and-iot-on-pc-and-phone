// ============================================================
//  ESP32 OLED Buddy v3  -  cau hinh chung
// ============================================================
#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <esp_sntp.h>
#include <sys/time.h>
#include <time.h>
#include <vector>

// Bluetooth Serial (dien thoai gui lenh qua app "Serial Bluetooth Terminal").
// Neu bien dich loi / thieu flash: them  -DENABLE_BT=0  vao build_flags
#ifndef ENABLE_BT
#define ENABLE_BT 0
#endif
#if ENABLE_BT
#include <BluetoothSerial.h>
#endif

#define FW_VER "3.0"
#define OLED_ADDR 0x3C

// ---- Day noi ----
#define PIN_SDA 21     // OLED SDA
#define PIN_SCL 22     // OLED SCK
#define PIN_A 4        // Nut A = LEN (bam ngan) / CHON (giu)
#define PIN_B 18       // Nut B = XUONG (bam ngan) / QUAY LAI (giu)
#ifndef PIN_BUZZ
#define PIN_BUZZ -1    // chan coi bao (coi chu dong); -1 = khong co
#endif

// ---- Cam bien tuy chon (de -1 neu khong gan) ----
#ifndef PIN_LDR
#define PIN_LDR -1     // quang tro (LDR) noi cau chia ap vao chan ADC1, vd 34/35/36/39 -> tu chinh do sang
#endif
#ifndef PIN_VBAT
#define PIN_VBAT -1    // do pin Li-ion qua cau chia ap 2 dien tro bang nhau, chan ADC1 (vd 35)
#endif

#define C_ON SSD1306_WHITE
#define C_OFF SSD1306_BLACK

static inline int imin(int a, int b) { return a < b ? a : b; }
static inline int imax(int a, int b) { return a > b ? a : b; }
static inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Gom dau ra cua lenh vao String (dung cho Web API)
class StrOut : public Print {
 public:
  String s;
  size_t write(uint8_t c) override { s += (char)c; return 1; }
  size_t write(const uint8_t *b, size_t n) override { s.concat((const char *)b, (unsigned int)n); return n; }
};

// Su kien nut: A ngan = LEN, B ngan = XUONG, A giu = CHON, B giu = QUAY LAI
enum { EV_NONE, EV_UP, EV_DOWN, EV_OK, EV_BACK };

enum Screen {
  SC_HOME, SC_MENU, SC_NOTES, SC_RDLIST, SC_READER, SC_TODO,
  SC_STOPWATCH, SC_POMO, SC_COUNTDOWN, SC_ALARM,
  SC_DINO, SC_SNAKE, SC_FLAPPY, SC_PONG, SC_BREAK,
  SC_DICE, SC_COIN, SC_EIGHT, SC_REACT,
  SC_WEATHER, SC_PCMON, SC_NET, SC_EYES, SC_FILES, SC_SETTINGS, SC_INFO, SC_BTNTEST,
  // ---- v3 (them o cuoi de khong lam lech khoang SC_DINO..SC_BREAK cua game) ----
  SC_PCDASH, SC_PHONE, SC_MOUSE, SC_PRESENT, SC_MACROS, SC_EDITOR, SC_CMDS, SC_CHEAT, SC_HOOKS, SC_SENSORS, SC_RULES, SC_WIFISCAN
};

// Khai bao truoc (cac file .h goi cheo nhau)
void go(int sc);
void render();
void showPopup(const String &title, const String &text);
void processLine(String l, Print &out);
bool openReader(const String &path);
void loadNotes();
void loadTodos();
void wifiRestart();
void startRing(const String &title);
void ntpSync();
String wfIp();
void openViewer(const String &title, const String &text);
// Muc dich cua trinh soan van ban (editor.h)
enum { ED_NOTE, ED_TYPE, ED_SEARCH, ED_MAN, ED_WIFIPASS };
void edOpen(int purpose, const String &title, const String &init = "", int maxLen = 200);
void cheatSearchOpen(const String &q);
bool pcSend(const String &line);
bool pcLinked();
