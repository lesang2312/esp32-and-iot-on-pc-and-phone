// ============================================================
//  Cac man hinh "thong minh": man phu PC, dien thoai, chuot, trinh chieu, phim tat, lenh PC,
//  webhook (nha thong minh), cam bien, canh bao, quet WiFi.
// ============================================================
#pragma once
#include <algorithm>
#include "core.h"
#include "apps.h"
#include "net.h"
#include "pc.h"
#include "editor.h"
#include "cheat.h"

// ---------- ve dung chung ----------
void drawLinkDot(int x, int y) {                         // cham tron nhap nhay = dang noi PC
  if (pcLinked()) { oled.fillCircle(x, y, 2, C_ON); }
  else oled.drawCircle(x, y, 2, C_ON);
}
void drawHdr(const String &t, int page = -1, int pages = 0) {
  oled.setCursor(0, 1);
  oled.print(t);
  if (pages > 1) {
    for (int i = 0; i < pages; i++) {
      int x = 126 - (pages - i) * 7;
      if (i == page) oled.fillRect(x, 3, 5, 4, C_ON); else oled.drawRect(x, 3, 5, 4, C_ON);
    }
  } else drawLinkDot(122, 5);
  oled.drawFastHLine(0, 10, 128, C_ON);
}
void drawPct(int y, const char *label, int pct, int x0 = 26, int w = 78) {
  oled.setCursor(0, y);
  oled.print(label);
  oled.drawRoundRect(x0, y - 1, w, 9, 2, C_ON);
  if (pct >= 0) oled.fillRect(x0 + 2, y + 1, (int)((w - 4) * (long)clampi(pct, 0, 100) / 100), 5, C_ON);
  char b[16];
  if (pct >= 0) snprintf(b, sizeof(b), "%d", pct); else strcpy(b, "--");
  oled.setCursor(128 - 6 * (int)strlen(b), y);
  oled.print(b);
}
template <typename T>
void drawSpark(int x, int y, int w, int h, const T *hist, int n, int pos, int maxv) {
  if (maxv < 1) maxv = 1;
  for (int i = 0; i < w; i += 3) oled.drawPixel(x + i, y + h, C_ON);          // duong nen cham
  int px = x, py = y + h;
  for (int i = 0; i < n; i++) {
    int v = clampi((int)hist[(pos + i) % n], 0, maxv);
    int cx = x + (int)((long)i * (w - 1) / (n - 1));
    int cy = y + h - (int)((long)v * h / maxv);
    if (i) oled.drawLine(px, py, cx, cy, C_ON);
    px = cx; py = cy;
  }
}
void fmtRate(int kb, char *b, size_t n) {
  if (kb < 1000) snprintf(b, n, "%dK", kb);
  else snprintf(b, n, "%.1fM", kb / 1024.0f);
}
void drawBattery(int x, int y, int w, int h, int pct, bool chg) {
  oled.drawRoundRect(x, y, w, h, 3, C_ON);
  oled.fillRect(x + w, y + h / 3, 3, h / 3 + 1, C_ON);
  if (pct >= 0) oled.fillRect(x + 2, y + 2, (int)((w - 4) * (long)clampi(pct, 0, 100) / 100), h - 4, C_ON);
  if (chg) {                                              // tia set, ve mau dao
    int cx = x + w / 2, cy = y + h / 2;
    oled.drawLine(cx + 2, cy - 4, cx - 2, cy + 1, C_OFF);
    oled.drawLine(cx - 2, cy + 1, cx + 2, cy + 1, C_OFF);
    oled.drawLine(cx + 2, cy + 1, cx - 2, cy + 5, C_OFF);
    oled.drawLine(cx + 3, cy - 4, cx - 1, cy + 1, C_ON);
  }
}
void drawMarquee(const String &s, int x, int y, int cols, uint32_t speedMs = 280) {
  if ((int)s.length() <= cols) { oled.setCursor(x, y); oled.print(s); return; }
  int span = (int)s.length() + 4;
  int off = (int)((millis() / speedMs) % span);
  String pad = s + "    " + s;
  oled.setCursor(x, y);
  oled.print(pad.substring(off, off + cols));
}
void drawNoLink(const char *l1, const char *l2) {          // hoat anh cho ket noi PC
  int r = (millis() / 110) % 14;
  oled.drawCircle(64, 28, 4 + r, C_ON);
  if (r > 5) oled.drawCircle(64, 28, 4 + r - 5, C_ON);
  oled.fillRoundRect(54, 22, 20, 13, 2, C_ON);
  oled.fillRect(50, 37, 28, 3, C_ON);
  centerText(l1, 46, 1);
  centerText(l2, 55, 1);
}

// =====================================================================
//  1. Man hinh phu PC
// =====================================================================
int pcPage = 0;
const int PC_PAGES = 4;
bool pcOnline() { return pcLinked() && pcxFresh(); }

void drawPcDash() {
  const char *names[PC_PAGES] = {"PC  CPU/RAM", "PC  Mang", "PC  Nguon/Am", "PC  Dang chay"};
  drawHdr(names[pcPage], pcPage, PC_PAGES);
  if (!pcLinked()) { drawNoLink("Cho may tinh...", "chay: buddyd.py"); return; }
  if (!pcxFresh()) { drawNoLink("Dang cho du lieu", ""); return; }
  char b[24], b2[24];
  if (pcPage == 0) {
    oled.setCursor(0, 13);
    oled.printf("CPU %d%%", pcx.cpu);
    if (pcx.temp >= 0) { oled.setCursor(66, 13); oled.printf("%dC", pcx.temp); }
    oled.setCursor(92, 13);
    oled.printf("L%.1f", pcx.load10 / 10.0f);
    drawSpark(0, 22, 128, 12, cpuHist, HIST_N, histPos, 100);
    drawPct(38, "RAM", pcx.mem);
    oled.setCursor(0, 50);
    oled.printf("SWP %d%%", pcx.swap < 0 ? 0 : pcx.swap);
    oled.setCursor(52, 50);
    oled.printf("DSK %d%%", pcx.disk < 0 ? 0 : pcx.disk);
    oled.setCursor(0, 57);
    oled.printf("up %dh%02dm", pcx.upH / 3600, pcx.upH / 60 % 60);
    if (pcx.win.length()) { oled.setCursor(60, 57); oled.print(pcx.win.substring(0, 11)); }
  } else if (pcPage == 1) {
    int mx = 50;
    for (int i = 0; i < HIST_N; i++) { mx = imax(mx, rxHist[i]); mx = imax(mx, txHist[i]); }
    fmtRate(pcx.rx, b, sizeof(b));
    fmtRate(pcx.tx, b2, sizeof(b2));
    oled.setCursor(0, 13);
    oled.printf("v %s/s", b);
    oled.setCursor(70, 13);
    oled.printf("^ %s/s", b2);
    drawSpark(0, 23, 128, 15, rxHist, HIST_N, histPos, mx);
    drawSpark(0, 43, 128, 15, txHist, HIST_N, histPos, mx);
  } else if (pcPage == 2) {
    drawBattery(2, 14, 34, 16, pcx.bat, pcx.chg > 0);
    oled.setCursor(44, 14);
    if (pcx.bat >= 0) { oled.setTextSize(2); oled.printf("%d%%", pcx.bat); oled.setTextSize(1); }
    else oled.print("khong pin");
    oled.setCursor(44, 32 - 2);
    oled.print(pcx.bat < 0 ? "may ban" : (pcx.chg > 0 ? "dang sac" : "dung pin"));
    drawPct(36, pcx.mute > 0 ? "MUT" : "VOL", pcx.vol);
    drawPct(48, "SNG", pcx.bri);
    oled.setCursor(0, 58);
    oled.print("OK: tat/bat tieng");
  } else {
    oled.setCursor(0, 13);
    int pl = (pcx.mstat == "Playing");
    if (pl) {                                             // bieu tuong play + thanh nhac nhay
      oled.fillTriangle(2, 13, 2, 21, 9, 17, C_ON);
      for (int i = 0; i < 4; i++) { int hh = 2 + (int)((millis() / 90 + i * 5) % 7); oled.fillRect(14 + i * 4, 22 - hh, 3, hh, C_ON); }
    } else if (pcx.mstat.length()) { oled.fillRect(2, 13, 3, 9, C_ON); oled.fillRect(8, 13, 3, 9, C_ON); }
    else oled.print("- ");
    oled.setCursor(34, 14);
    oled.print(pcx.mstat.length() ? pcx.mstat : String("khong phat"));
    drawMarquee(pcx.media.length() ? pcx.media : String("(khong co nhac)"), 0, 25, 21);
    oled.drawFastHLine(0, 36, 128, C_ON);
    oled.setCursor(0, 40);
    oled.print("Cua so:");
    if (pcx.ws.length()) { oled.setCursor(128 - 6 * (3 + (int)pcx.ws.length()), 40); oled.printf("WS %s", pcx.ws.c_str()); }
    drawMarquee(pcx.win.length() ? pcx.win : String("-"), 0, 50, 21);
  }
}
void handlePcDash(int e) {
  if (e == EV_UP) pcPage = (pcPage + PC_PAGES - 1) % PC_PAGES;
  else if (e == EV_DOWN) pcPage = (pcPage + 1) % PC_PAGES;
  else if (e == EV_BACK) go(SC_MENU);
  else if (e == EV_OK) {
    if (pcPage == 3) pcSend("A playpause");
    else if (pcPage == 2) pcSend("A mute");
    else showPopup("May tinh", pcLinked() ? "Dang noi USB" : "Chua noi (buddyd.py)");
  }
}

// =====================================================================
//  2. Dien thoai (trang web mo tren dien thoai bao ve pin, nhan clipboard, tim may)
// =====================================================================
int phSel = 0;
const char *PH_ACT[3] = {"Tim dien thoai", "Clip DT -> PC", "Clip DT -> ghi chu"};
void drawPhone() {
  drawHdr("Dien thoai");
  if (!phoneFresh()) {
    int r = (millis() / 100) % 16;
    oled.drawCircle(64, 30, 3 + r, C_ON);
    oled.fillRoundRect(58, 22, 12, 18, 2, C_ON);
    centerText("Mo tren dien thoai:", 45, 1);
    String u = (wfIp().length() ? wfIp() : String("buddy.local"));
    centerText(u, 55, 1);
    return;
  }
  // hinh dien thoai + muc pin
  oled.drawRoundRect(4, 14, 24, 46, 4, C_ON);
  oled.drawFastHLine(11, 17, 10, C_ON);
  int ih = 36;
  if (phn.bat >= 0) {
    int fh = ih * phn.bat / 100;
    oled.fillRect(7, 20 + ih - fh, 18, fh, C_ON);
  }
  if (phn.chg) {
    int cx = 16, cy = 38;
    oled.drawLine(cx + 3, cy - 6, cx - 3, cy + 1, C_OFF);
    oled.drawLine(cx - 3, cy + 1, cx + 3, cy + 1, C_OFF);
    oled.drawLine(cx + 3, cy + 1, cx - 3, cy + 7, C_OFF);
  }
  oled.setCursor(34, 13);
  oled.print(phn.name.length() ? phn.name.substring(0, 15) : String("Dien thoai"));
  oled.setCursor(34, 23);
  oled.setTextSize(2);
  if (phn.bat >= 0) oled.printf("%d%%", phn.bat); else oled.print("--");
  oled.setTextSize(1);
  oled.setCursor(34, 40);
  oled.print(phn.chg ? "dang sac" : "dung pin");
  oled.fillRect(0, 52, 128, 12, C_ON);
  oled.setTextColor(C_OFF);
  oled.setCursor(3, 54);
  oled.print(String("> ") + PH_ACT[phSel]);
  oled.setTextColor(C_ON);
}
void handlePhone(int e) {
  if (e == EV_UP) phSel = (phSel + 2) % 3;
  else if (e == EV_DOWN) phSel = (phSel + 1) % 3;
  else if (e == EV_BACK) go(SC_MENU);
  else if (e == EV_OK) {
    if (phSel == 0) { findPhone = true; findSeq++; showPopup("Tim dien thoai", "Dang keu tren DT (mo trang web)"); }
    else if (!phn.clip.length()) showPopup("Clipboard DT", "Chua co. Gui tu trang web");
    else if (phSel == 1) {
      if (pcSend("CLIP " + phn.clip)) showPopup("Clipboard PC", "Da chep tu dien thoai");
      else showPopup("May tinh", "Chua noi PC");
    } else { addNote(phn.clip.substring(0, 200)); showPopup("Ghi chu", "Da luu tu clipboard DT"); }
  }
}

// =====================================================================
//  3. Chuot USB (qua daemon tren may tinh)
//     Mui ten tu xoay vong -> GIU B de di theo huong do. A doi cong cu: di, trai, phai, cuon, keo, thoat
// =====================================================================
const int MS_TOOLS = 7;
const char *MS_NAME[MS_TOOLS] = {"DI", "TRAI", "PHAI", "CUON v", "CUON ^", "KEO", "THOAT"};
const char *MS_HINT[MS_TOOLS] = {"giu B: di", "B: bam trai", "B: bam phai", "B: cuon xuong", "B: cuon len", "giu B: keo", "B: thoat"};
const uint8_t MS_SPD[5] = {2, 4, 7, 11, 16};
int msTool = 0, msAngle = 0;
uint32_t msRot = 0, msSend = 0, msHoldAt = 0, msScroll = 0;
bool msHeld = false, msDragDown = false;
float msAccX = 0, msAccY = 0;

void msRelease() {
  if (msDragDown) { pcSend("C lu"); msDragDown = false; }
}
void handleMouse(int e) {
  if (e == EV_BACK) { msRelease(); go(SC_MENU); return; }
  if (e == EV_UP) { msRelease(); msTool = (msTool + 1) % MS_TOOLS; return; }
  if (e != EV_DOWN) return;
  if (!pcLinked() && msTool != 6) { showPopup("May tinh", "Chua noi PC (buddyd.py)"); return; }
  switch (msTool) {
    case 0: break;                                           // di chuyen xu ly o inputTick
    case 1: pcSend("C l"); break;
    case 2: pcSend("C r"); break;
    case 3: pcSend("S 3"); msScroll = millis() + 350; break;
    case 4: pcSend("S -3"); msScroll = millis() + 350; break;
    case 5: pcSend("C ld"); msDragDown = true; break;
    case 6: msRelease(); go(SC_MENU); break;
  }
}
void mouseTick() {
  uint32_t now = millis();
  bool b = btns[1].pressed;
  if (!b) {
    if (msHeld) { msHeld = false; msRelease(); dirty = true; }
    if ((msTool == 0 || msTool == 5) && now - msRot >= 75) { msRot = now; msAngle = (msAngle + 1) % 24; dirty = true; }
    return;
  }
  if (!msHeld) { msHeld = true; msHoldAt = now; msAccX = msAccY = 0; }
  dirty = true;
  if ((msTool == 3 || msTool == 4) && now >= msScroll) {
    msScroll = now + 110;
    pcSend(msTool == 3 ? "S 2" : "S -2");
  }
  if ((msTool == 0 || msTool == 5) && now - msSend >= 25) {
    msSend = now;
    uint32_t held = now - msHoldAt;
    float sp = MS_SPD[clampi(S.mouseSpd, 0, 4)] * (held > 1800 ? 2.6f : (held > 700 ? 1.6f : 1.0f));
    float a = msAngle * (PI / 12.0f);
    msAccX += cosf(a) * sp;
    msAccY += sinf(a) * sp;
    int dx = (int)msAccX, dy = (int)msAccY;
    msAccX -= dx; msAccY -= dy;
    if (dx || dy) pcSend("M " + String(dx) + " " + String(dy));
  }
}
void drawMouse() {
  drawHdr("Chuot USB");
  oled.setCursor(70, 1);
  oled.printf("v%d", S.mouseSpd + 1);
  // la ban xoay
  int cx = 98, cy = 36, r = 24;
  oled.drawCircle(cx, cy, r, C_ON);
  for (int i = 0; i < 24; i++) {
    float a = i * PI / 12;
    int l = (i % 6 == 0) ? 5 : 2;
    oled.drawLine(cx + (int)(cosf(a) * (r - l)), cy + (int)(sinf(a) * (r - l)), cx + (int)(cosf(a) * r), cy + (int)(sinf(a) * r), C_ON);
  }
  bool aim = (msTool == 0 || msTool == 5);
  if (aim) {
    float a = msAngle * (PI / 12.0f);
    int x2 = cx + (int)(cosf(a) * (r - 7)), y2 = cy + (int)(sinf(a) * (r - 7));
    oled.drawLine(cx, cy, x2, y2, C_ON);
    oled.drawLine(cx + 1, cy, x2 + 1, y2, C_ON);
    float a1 = a + 2.5f, a2 = a - 2.5f;
    oled.fillTriangle(x2 + (int)(cosf(a) * 4), y2 + (int)(sinf(a) * 4), x2 + (int)(cosf(a1) * 4), y2 + (int)(sinf(a1) * 4),
                      x2 + (int)(cosf(a2) * 4), y2 + (int)(sinf(a2) * 4), C_ON);
    if (msHeld) oled.drawCircle(cx, cy, r - 3, C_ON);
  } else {
    oled.fillCircle(cx, cy, msHeld ? 10 : 7, C_ON);
    if (msTool == 1 || msTool == 2) { oled.fillRect(msTool == 1 ? cx - 14 : cx + 3, cy - 12, 11, 8, C_ON); }
  }
  // ten cong cu
  oled.setTextSize(2);
  oled.setCursor(0, 15);
  oled.print(MS_NAME[msTool]);
  oled.setTextSize(1);
  oled.setCursor(0, 33);
  oled.print(MS_HINT[msTool]);
  oled.setCursor(0, 43);
  oled.print("A: doi cong cu");
  for (int i = 0; i < MS_TOOLS; i++) {                           // thanh chon cong cu
    int x = 1 + i * 9;
    if (i == msTool) oled.fillRect(x, 55, 7, 7, C_ON); else oled.drawRect(x, 55, 7, 7, C_ON);
  }
  if (!pcLinked()) {
    oled.fillRect(0, 22, 62, 10, C_ON);
    oled.setTextColor(C_OFF);
    oled.setCursor(2, 24);
    oled.print("PC chua noi");
    oled.setTextColor(C_ON);
  }
}

// =====================================================================
//  4. Dieu khien trinh chieu / video / nhac
// =====================================================================
struct PresetMode { const char *name; const char *up; const char *down; const char *kind; };   // kind: K phim, A hanh dong
const PresetMode PR_MODES[] = {
  {"Slide", "Left", "Right", "K"}, {"Bat dau/Thoat", "F5", "Escape", "K"}, {"Trang", "Prior", "Next", "K"},
  {"Tua video", "Left", "Right", "K"}, {"Phat/Dung", "space", "space", "K"}, {"Nhac", "prev", "next", "A"},
  {"Am luong", "vol -5", "vol +5", "A"}, {"Man den", "b", "b", "K"}};
const int PR_N = sizeof(PR_MODES) / sizeof(PR_MODES[0]);
int prMode = 0, prCount = 1;
uint32_t prStart = 0, prFlash = 0;
void drawPresent() {
  drawHdr("Trinh chieu");
  const PresetMode &m = PR_MODES[prMode];
  oled.setCursor(0, 13);
  oled.print(m.name);
  uint32_t s = (millis() - prStart) / 1000;
  oled.setCursor(128 - 6 * 5, 13);
  oled.printf("%02u:%02u", (unsigned)(s / 60 % 100), (unsigned)(s % 60));
  if (prMode == 0) {
    oled.setTextSize(4);
    char b[8];
    snprintf(b, sizeof(b), "%d", prCount);
    oled.setCursor(64 - (int)strlen(b) * 12, 23);
    oled.print(b);
    oled.setTextSize(1);
  } else {
    centerText(String(m.up) + " / " + m.down, 28, 1);
    // mui ten lon
    oled.fillTriangle(8, 38, 24, 28, 24, 48, C_ON);
    oled.fillTriangle(120, 38, 104, 28, 104, 48, C_ON);
  }
  if (millis() - prFlash < 160) {                                // chop nhanh khi gui phim
    oled.drawRect(0, 22, 128, 32, C_ON);
    oled.drawRect(1, 23, 126, 30, C_ON);
  }
  oled.setCursor(0, 56);
  oled.print(pcLinked() ? "A<  B>  giu A: che do" : "PC chua noi!");
}
void presentSend(const PresetMode &m, bool up) {
  const char *k = up ? m.up : m.down;
  if (!pcSend(String(m.kind) + (m.kind[0] == 'K' ? " " : " ") + k)) { showPopup("May tinh", "Chua noi PC (buddyd.py)"); return; }
  prFlash = millis();
}
void handlePresent(int e) {
  const PresetMode &m = PR_MODES[prMode];
  if (e == EV_UP) { presentSend(m, true); if (prMode == 0 && prCount > 1) prCount--; }
  else if (e == EV_DOWN) { presentSend(m, false); if (prMode == 0) prCount++; }
  else if (e == EV_OK) { prMode = (prMode + 1) % PR_N; }
  else if (e == EV_BACK) go(SC_MENU);
}

// =====================================================================
//  5. Phim tat / hanh dong nhanh tren PC
// =====================================================================
struct Macro { const char *name; char kind; const char *arg; };
const Macro MACROS[] = {
  {"Sao chep  Ctrl+C", 'K', "ctrl+c"}, {"Dan  Ctrl+V", 'K', "ctrl+v"}, {"Cat  Ctrl+X", 'K', "ctrl+x"},
  {"Hoan tac  Ctrl+Z", 'K', "ctrl+z"}, {"Chon het  Ctrl+A", 'K', "ctrl+a"}, {"Luu  Ctrl+S", 'K', "ctrl+s"},
  {"Tim  Ctrl+F", 'K', "ctrl+f"}, {"Tab moi", 'K', "ctrl+t"}, {"Dong tab", 'K', "ctrl+w"},
  {"Doi cua so Alt+Tab", 'K', "alt+Tab"}, {"Dong cua so", 'K', "alt+F4"}, {"Toan man hinh F11", 'K', "F11"},
  {"Lam moi F5", 'K', "F5"}, {"Mo terminal", 'K', "ctrl+alt+t"}, {"Enter", 'K', "Return"}, {"Esc", 'K', "Escape"},
  {"Am luong +", 'A', "vol +5"}, {"Am luong -", 'A', "vol -5"}, {"Tat/bat tieng", 'A', "mute"},
  {"Phat / tam dung", 'A', "playpause"}, {"Bai ke", 'A', "next"}, {"Bai truoc", 'A', "prev"},
  {"Do sang +", 'A', "bri +10"}, {"Do sang -", 'A', "bri -10"},
  {"Chup man hinh", 'A', "shot"}, {"Khoa may", 'A', "lock"}, {"Tat man hinh", 'A', "dpms"}, {"Ngu (suspend)", 'A', "suspend"}};
const int MAC_N = sizeof(MACROS) / sizeof(MACROS[0]);
int macSel = 0;
void drawMacros() {
  drawHdr("Phim tat PC");
  std::vector<String> names;
  for (int i = 0; i < MAC_N; i++) names.push_back(MACROS[i].name);
  drawRows(names, nullptr, macSel, 13, 5);
}
void handleMacros(int e) {
  if (e == EV_UP) macSel = (macSel + MAC_N - 1) % MAC_N;
  else if (e == EV_DOWN) macSel = (macSel + 1) % MAC_N;
  else if (e == EV_BACK) go(SC_MENU);
  else if (e == EV_OK) {
    const Macro &m = MACROS[macSel];
    if (m.kind == 'A' && !strcmp(m.arg, "suspend")) { showPopup("Ngu", "Dung menu Lenh PC de ngu"); return; }
    if (pcSend(String(m.kind) + " " + m.arg)) showPopup("Da gui", m.name);
    else showPopup("May tinh", "Chua noi PC (buddyd.py)");
  }
}

// =====================================================================
//  6. Lenh PC cho phep (daemon gui danh sach, ket qua tra ve trinh doc)
// =====================================================================
int cmdSel = 0;
void drawCmds() {
  drawHdr("Chay lenh PC");
  if (!pcLinked()) { drawNoLink("Cho may tinh...", "chay: buddyd.py"); return; }
  if (pcCmdNames.empty()) { centerText("Chua co lenh nao", 24, 1); centerText("sua buddy-commands.json", 38, 1); return; }
  drawRows(pcCmdNames, nullptr, cmdSel, 13, 5);
}
void handleCmds(int e) {
  int n = (int)pcCmdNames.size();
  if (e == EV_UP && n) cmdSel = (cmdSel + n - 1) % n;
  else if (e == EV_DOWN && n) cmdSel = (cmdSel + 1) % n;
  else if (e == EV_BACK) go(SC_MENU);
  else if (e == EV_OK && n) {
    if (pcSend("R " + pcCmdIds[cmdSel])) showPopup("Dang chay", pcCmdNames[cmdSel]);
    else showPopup("May tinh", "Chua noi PC");
  }
}

// =====================================================================
//  7. Webhook / nha thong minh: file /hooks.txt, moi dong  ten|http://...
// =====================================================================
struct Hook { String name, url; };
std::vector<Hook> hooks;
int hkSel = 0;
volatile bool hookBusy = false, hookDone = false;
String hookMsg, hookArgUrl, hookArgName;

void hooksLoad() {
  hooks.clear();
  File f = LittleFS.open("/hooks.txt", "r");
  if (!f) return;
  while (f.available() && hooks.size() < 16) {
    String l = f.readStringUntil('\n');
    l.trim();
    int p = l.indexOf('|');
    if (p < 1 || p > 20 || !(l.startsWith("http", p + 1))) continue;
    hooks.push_back({sanitize(l.substring(0, p)), l.substring(p + 1)});
  }
  f.close();
}
void hooksSave(const String &text) {
  File f = LittleFS.open("/hooks.txt", "w");
  if (!f) return;
  f.print(text);
  f.close();
  hooksLoad();
}
void hookTask(void *) {
  String url = hookArgUrl, name = hookArgName;
  int code = -1;
  HTTPClient http;
  http.setTimeout(6000);
  bool ok = false;
  if (url.startsWith("https://")) {
    WiFiClientSecure sc;
    sc.setInsecure();                                         // chi dung cho webhook nha thong minh trong LAN; khong gui du lieu nhay cam
    ok = http.begin(sc, url);
    if (ok) code = http.GET();
    http.end();
  } else {
    WiFiClient c;
    ok = http.begin(c, url);
    if (ok) code = http.GET();
    http.end();
  }
  hookMsg = name + ": " + (code > 0 ? ("HTTP " + String(code)) : String("loi mang"));
  hookDone = true;
  hookBusy = false;
  vTaskDelete(nullptr);
}
bool hookRun(int i) {
  if (i < 0 || i >= (int)hooks.size()) return false;
  if (hookBusy) return false;
  if (wfState != WF_STA) return false;
  hookBusy = true;
  hookArgUrl = hooks[i].url;
  hookArgName = hooks[i].name;
  xTaskCreate(hookTask, "hook", 8192, nullptr, 1, nullptr);
  return true;
}
void drawHooks() {
  drawHdr("Webhook");
  if (hooks.empty()) {
    centerText("Chua co webhook", 18, 1);
    centerText("Them tren trang web:", 32, 1);
    centerText("tab Lenh > Webhook", 42, 1);
    return;
  }
  std::vector<String> names, vals;
  for (size_t i = 0; i < hooks.size(); i++) { names.push_back(hooks[i].name); vals.push_back(""); }
  drawRows(names, nullptr, hkSel, 13, 5);
  if (hookBusy) { oled.fillRect(90, 1, 38, 8, C_OFF); oled.setCursor(92, 1); oled.print("..."); }
}
void handleHooks(int e) {
  int n = (int)hooks.size();
  if (e == EV_UP && n) hkSel = (hkSel + n - 1) % n;
  else if (e == EV_DOWN && n) hkSel = (hkSel + 1) % n;
  else if (e == EV_BACK) go(SC_MENU);
  else if (e == EV_OK && n) {
    if (wfState != WF_STA) showPopup("Webhook", "Can WiFi co Internet/LAN");
    else if (hookRun(hkSel)) showPopup("Webhook", "Dang goi " + hooks[hkSel].name);
    else showPopup("Webhook", "Dang ban, thu lai");
  }
}

// =====================================================================
//  8. Cam bien
// =====================================================================
void drawSensors() {
  drawHdr("Cam bien");
  float t = senBestT();
  oled.setTextSize(2);
  oled.setCursor(0, 13);
  if (!isnan(t)) oled.printf("%.1fC", t); else oled.print("--");
  oled.setTextSize(1);
  oled.setCursor(66, 13);
  if (senKind == 1) oled.print("AHT20");
  else if (senKind == 2) oled.print("BMP280");
  else if (senKind == 3) oled.print("BME280");
  else oled.print("chip ESP");
  int y = 24;
  if (!isnan(senHum)) { oled.setCursor(66, y); oled.printf("Am %.0f%%", senHum); y += 9; }
  if (!isnan(senPres)) { oled.setCursor(66, y); oled.printf("%.0fhPa", senPres); y += 9; }
  if (senLdr >= 0 && y <= 33) { oled.setCursor(66, y); oled.printf("Sang %d%%", senLdr); y += 9; }
  int vp = vbatPercent();
  if (vp >= 0 && y <= 33) { oled.setCursor(66, y); oled.printf("Pin %d%%", vp); y += 9; }
  if (senKind == 0 && PIN_LDR < 0 && PIN_VBAT < 0) { oled.setCursor(66, 24); oled.print("Chip:"); oled.setCursor(66, 33); oled.printf("%.0fC", senChipT); }
  if (senHistN > 3) {
    int mn = 9999, mx = -9999;
    for (int i = 0; i < senHistN; i++) { mn = imin(mn, senHist[i]); mx = imax(mx, senHist[i]); }
    if (mx - mn < 20) { mn -= 10; mx += 10; }
    int n = senHistN, start = (senHistN < 60) ? 0 : senHistPos;
    int px = 0, py = 0;
    for (int i = 0; i < n; i++) {
      int v = senHist[(start + i) % 60];
      int cx = (int)((long)i * 127 / imax(1, n - 1));
      int cy = 60 - (int)((long)(v - mn) * 18 / (mx - mn));
      if (i) oled.drawLine(px, py, cx, cy, C_ON);
      px = cx; py = cy;
    }
    oled.setCursor(0, 56);
    oled.printf("%.0f", mn / 10.0f);
    oled.setCursor(110, 42);
    oled.printf("%.0f", mx / 10.0f);
  } else {
    centerText("dang do...", 50, 1);
  }
}
void handleSensors(int e) { if (e == EV_BACK || e == EV_OK) go(SC_MENU); }

// =====================================================================
//  9. Canh bao & tu dong
// =====================================================================
const int RUL_N = RL_N + 3;
int rulSel = 0;
void drawRules() {
  drawHdr("Canh bao & auto");
  std::vector<String> names, vals;
  for (int i = 0; i < RL_N; i++) { names.push_back(RULE_NAMES[i]); vals.push_back((S.rules & (1 << i)) ? "Bat" : "Tat"); }
  names.push_back("Sang theo LDR"); vals.push_back(PIN_LDR < 0 ? "-" : (S.autoBr ? "Bat" : "Tat"));
  names.push_back("Ban dem 23-6h"); vals.push_back(S.night ? "Bat" : "Tat");
  names.push_back("Toc do chuot"); vals.push_back(String(S.mouseSpd + 1) + "/5");
  drawRows(names, &vals, rulSel, 13, 5);
}
void handleRules(int e) {
  if (e == EV_UP) rulSel = (rulSel + RUL_N - 1) % RUL_N;
  else if (e == EV_DOWN) rulSel = (rulSel + 1) % RUL_N;
  else if (e == EV_BACK) { saveSettings(); go(SC_MENU); }
  else if (e == EV_OK) {
    if (rulSel < RL_N) S.rules ^= (1 << rulSel);
    else if (rulSel == RL_N) { if (PIN_LDR < 0) showPopup("Cam bien", "Chua gan LDR (PIN_LDR)"); else { S.autoBr = !S.autoBr; if (!S.autoBr) { effBright = -1; applyDisplay(); } } }
    else if (rulSel == RL_N + 1) { S.night = !S.night; if (!S.night) { effBright = -1; applyDisplay(); } }
    else S.mouseSpd = (S.mouseSpd + 1) % 5;
  }
}

// =====================================================================
//  10. Quet WiFi & nhap mat khau bang 2 nut
// =====================================================================
struct Ap { String ssid; int rssi; bool open; };
std::vector<Ap> aps;
int apSel = 0;
bool apScanned = false;
void wifiScanNow() {
  aps.clear();
  if (wfState == WF_AP || wfState == WF_OFF) WiFi.mode(WIFI_AP_STA);
  int n = WiFi.scanNetworks(false, false);
  for (int i = 0; i < n && aps.size() < 20; i++) {
    String s = sanitize(WiFi.SSID(i));
    if (!s.length()) continue;
    bool dup = false;
    for (size_t k = 0; k < aps.size(); k++) if (aps[k].ssid == s) dup = true;
    if (!dup) aps.push_back({s, WiFi.RSSI(i), WiFi.encryptionType(i) == WIFI_AUTH_OPEN});
  }
  WiFi.scanDelete();
  std::sort(aps.begin(), aps.end(), [](const Ap &a, const Ap &b) { return a.rssi > b.rssi; });
  apScanned = true;
  apSel = 0;
}
void drawWifiScan() {
  drawHdr("Quet WiFi");
  if (!apScanned) { centerText("Dang quet...", 28, 1); return; }
  if (aps.empty()) { centerText("Khong thay mang", 24, 1); centerText("OK: quet lai", 38, 1); return; }
  std::vector<String> names, vals;
  for (size_t i = 0; i < aps.size(); i++) {
    names.push_back(aps[i].ssid);
    int bars = aps[i].rssi > -55 ? 4 : (aps[i].rssi > -67 ? 3 : (aps[i].rssi > -78 ? 2 : 1));
    vals.push_back(String(aps[i].open ? "o" : "*") + String(bars));
  }
  drawRows(names, &vals, apSel, 13, 5);
}
void handleWifiScan(int e) {
  int n = (int)aps.size();
  if (e == EV_UP && n) apSel = (apSel + n - 1) % n;
  else if (e == EV_DOWN && n) apSel = (apSel + 1) % n;
  else if (e == EV_BACK) go(SC_NET);
  else if (e == EV_OK) {
    if (!n) { apScanned = false; dirty = true; render(); wifiScanNow(); return; }
    wifiSsid = aps[apSel].ssid;
    prefs.putString("ssid", wifiSsid);
    if (aps[apSel].open) { wifiPass = ""; prefs.putString("pass", ""); S.wifiOn = true; saveSettings(); scheduleWifiRestart(300); showPopup("WiFi", "Noi " + wifiSsid); go(SC_NET); }
    else edOpen(ED_WIFIPASS, wifiSsid, "", 63);
  }
}

// =====================================================================
//  Vao man hinh / vong lap input / hanh dong menu
// =====================================================================
void smartEnter(int sc) {
  switch (sc) {
    case SC_PCDASH: break;
    case SC_PHONE: phSel = 0; break;
    case SC_MOUSE: msTool = 0; msAngle = 0; msHeld = false; msDragDown = false; msScroll = 0; break;
    case SC_PRESENT: prStart = millis(); prCount = 1; break;
    case SC_MACROS: macSel = 0; break;
    case SC_CMDS: cmdSel = 0; if (pcLinked()) pcSend("CMDS"); break;
    case SC_HOOKS: hooksLoad(); hkSel = 0; break;
    case SC_CHEAT: break;
    case SC_RULES: rulSel = 0; break;
    case SC_WIFISCAN: apScanned = false; aps.clear(); break;
  }
}
void smartTick() {
  edTick();
  if (screen == SC_MOUSE) mouseTick();
  if (screen == SC_WIFISCAN && !apScanned) { dirty = true; render(); wifiScanNow(); dirty = true; }
  if (hookDone) { hookDone = false; showPopup("Webhook", hookMsg); }
}

// ID hanh dong trong menu (target >= 100)
enum { MA_TYPE = 100, MA_NOTE, MA_SEARCH, MA_MAN, MA_TIP, MA_LOCK, MA_CLIPPC, MA_WIFIPASS, MA_ALLCMD };
void menuAction(int id) {
  switch (id) {
    case MA_TYPE: edOpen(ED_TYPE, "Go len PC", "", 120); break;
    case MA_NOTE: edOpen(ED_NOTE, "Ghi chu moi", "", 200); break;
    case MA_SEARCH: edOpen(ED_SEARCH, "Tim lenh", "", 30); break;
    case MA_MAN: edOpen(ED_MAN, "man/tldr PC", "", 30); break;
    case MA_TIP: cheatTip(); break;
    case MA_ALLCMD: cheatFilter(""); go(SC_CHEAT); break;
    case MA_LOCK: if (pcSend("A lock")) showPopup("May tinh", "Da khoa may"); else showPopup("May tinh", "Chua noi PC"); break;
    case MA_WIFIPASS: edOpen(ED_WIFIPASS, wifiSsid.length() ? wifiSsid : String("WiFi pass"), "", 63); break;
    case MA_CLIPPC: {
      if (!phn.clip.length()) showPopup("Clipboard DT", "Chua co");
      else if (pcSend("CLIP " + phn.clip)) showPopup("Clipboard PC", "Da chep");
      else showPopup("May tinh", "Chua noi PC");
      break;
    }
  }
}
