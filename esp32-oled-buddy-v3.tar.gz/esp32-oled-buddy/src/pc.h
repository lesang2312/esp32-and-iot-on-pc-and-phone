// ============================================================
//  Lien ket voi may tinh (chuong trinh nen buddyd.py qua cap USB) va dien thoai (qua trang web)
//
//  PC -> ESP (lenh thuong, moi lenh 1 dong):
//    HELLO <ten>            PC bao "toi dang nghe"; cu 5 giay gui lai 1 lan. Het 20 giay thi coi nhu mat ket noi
//    PCS2 k=v<TAB>k=v...    thong so may tinh: cpu mem swap temp disk bat chg bri vol mute rx tx up load win ws media mstat
//    CMDS id:ten;id:ten     danh sach lenh PC cho phep chay (menu "Chay lenh PC")
//    VIEWB <tieu de> / VIEWA <doan chu> / VIEWE   ket qua lenh / trang man: mo tren trinh doc (dau xuong dong = ky tu 0x1F)
//  ESP -> PC (in ra Serial, dau dong la '@', chi gui khi dang co ket noi):
//    @M dx dy | @C l|r|m|d|ld|lu | @S n | @K ctrl+c | @T chu | @CLIP chu | @A vol 5 | @R id | @MAN lenh
// ============================================================
#pragma once
#include "core.h"
#include "apps.h"
#include "net.h"

// ---------- ket noi ----------
uint32_t pcHelloAt = 0;
bool pcEverLinked = false;
bool pcWasLinked = false;
String pcName;
String pcShareUrl;                       // dia chi trang nhan file tren PC (share.py), de nut "Gui len PC" tren trang dien thoai
bool pcLinked() { return pcHelloAt != 0 && millis() - pcHelloAt < 20000UL; }

bool pcSend(const String &line) {
  if (!pcLinked()) return false;
  Serial.print('@');
  Serial.println(line);
  return true;
}

// ---------- thong so may tinh ----------
struct PcX {
  uint32_t at;
  int cpu, mem, swap, temp, disk, bat, chg, bri, vol, mute, rx, tx, upH, load10;
  String win, ws, media, mstat;
};
PcX pcx = {0, -1, -1, -1, -1, -1, -1, 0, -1, -1, 0, 0, 0, 0, -1, "", "", "", ""};
bool pcxFresh() { return pcx.at != 0 && millis() - pcx.at < 15000UL; }

#define HIST_N 64
uint16_t rxHist[HIST_N], txHist[HIST_N];
uint8_t cpuHist[HIST_N];
int histPos = 0;
void histPush() {
  rxHist[histPos] = (uint16_t)clampi(pcx.rx, 0, 65535);
  txHist[histPos] = (uint16_t)clampi(pcx.tx, 0, 65535);
  cpuHist[histPos] = (uint8_t)clampi(pcx.cpu, 0, 100);
  histPos = (histPos + 1) % HIST_N;
}

String asciiOnly(const String &s, unsigned maxLen) {
  String o;
  for (unsigned i = 0; i < s.length() && o.length() < maxLen; i++) {
    uint8_t u = (uint8_t)s[i];
    if (u >= 32 && u < 127) o += (char)u;
    else if (u == '\t') o += ' ';
  }
  return o;
}

void parsePcs2(const String &arg) {
  int i = 0, n = (int)arg.length();
  while (i < n) {
    int e = arg.indexOf('\t', i);
    if (e < 0) e = n;
    String kv = arg.substring(i, e);
    int eq = kv.indexOf('=');
    if (eq > 0) {
      String k = kv.substring(0, eq), v = kv.substring(eq + 1);
      int iv = (int)v.toInt();
      if (k == "cpu") pcx.cpu = iv;
      else if (k == "mem") pcx.mem = iv;
      else if (k == "swap") pcx.swap = iv;
      else if (k == "temp") pcx.temp = iv;
      else if (k == "disk") pcx.disk = iv;
      else if (k == "bat") pcx.bat = iv;
      else if (k == "chg") pcx.chg = iv;
      else if (k == "bri") pcx.bri = iv;
      else if (k == "vol") pcx.vol = iv;
      else if (k == "mute") pcx.mute = iv;
      else if (k == "rx") pcx.rx = iv;
      else if (k == "tx") pcx.tx = iv;
      else if (k == "up") pcx.upH = iv;
      else if (k == "load") pcx.load10 = iv;
      else if (k == "win") pcx.win = asciiOnly(v, 40);
      else if (k == "ws") pcx.ws = asciiOnly(v, 8);
      else if (k == "media") pcx.media = asciiOnly(v, 60);
      else if (k == "mstat") pcx.mstat = asciiOnly(v, 12);
      else if (k == "share") pcShareUrl = asciiOnly(v, 60);
    }
    i = e + 1;
  }
  pcx.at = millis();
  if (pcx.at == 0) pcx.at = 1;
  if (pcx.cpu >= 0) pcs.cpu = pcx.cpu;                 // cap nhat luon thanh "May tinh" cu va man hinh chinh
  if (pcx.mem >= 0) pcs.mem = pcx.mem;
  pcs.at = pcx.at;
  histPush();
  dirty = true;
}

// ---------- lenh PC cho phep chay ----------
std::vector<String> pcCmdIds, pcCmdNames;
void parseCmds(const String &arg) {
  pcCmdIds.clear();
  pcCmdNames.clear();
  int i = 0, n = (int)arg.length();
  while (i < n && pcCmdIds.size() < 40) {
    int e = arg.indexOf(';', i);
    if (e < 0) e = n;
    String item = arg.substring(i, e);
    int c = item.indexOf(':');
    if (c > 0) {
      pcCmdIds.push_back(item.substring(0, c));
      pcCmdNames.push_back(asciiOnly(item.substring(c + 1), 24));
    }
    i = e + 1;
  }
}

// ---------- ket qua dai (lenh, man): PC gui tung doan ----------
String viewTitleIn, viewBufIn, viewTitleOut, viewTextOut;
uint32_t viewSeq = 0;
void viewBegin(const String &t) { viewTitleIn = asciiOnly(t, 14); viewBufIn = ""; }
void viewAppend(const String &chunk) {
  for (unsigned i = 0; i < chunk.length() && viewBufIn.length() < 9000; i++) {
    uint8_t c = (uint8_t)chunk[i];
    if (c == 0x1F) viewBufIn += '\n';
    else if (c >= 32 && c < 127) viewBufIn += (char)c;
  }
}
void viewEnd() {
  viewTitleOut = viewTitleIn;
  viewTextOut = viewBufIn;
  viewSeq++;
  if (!viewTextOut.length()) viewTextOut = "(khong co ket qua)";
  openViewer(viewTitleOut.length() ? viewTitleOut : String("Ket qua"), viewTextOut);
}

// ---------- dien thoai (trang web tren dien thoai bao ve) ----------
struct Phone { uint32_t at; int bat; int chg; String name; String clip; uint32_t clipAt; };
Phone phn = {0, -1, 0, "", "", 0};
bool phoneFresh() { return phn.at != 0 && millis() - phn.at < 120000UL; }
bool findPhone = false;                 // ESP bao: "tim dien thoai" -> trang web tren dien thoai se keu / rung
uint32_t findSeq = 0;

void parsePhone(const String &arg) {
  int i = 0, n = (int)arg.length();
  while (i < n) {
    int e = arg.indexOf(' ', i);
    if (e < 0) e = n;
    String kv = arg.substring(i, e);
    int eq = kv.indexOf('=');
    if (eq > 0) {
      String k = kv.substring(0, eq), v = kv.substring(eq + 1);
      if (k == "bat") phn.bat = clampi((int)v.toInt(), 0, 100);
      else if (k == "chg") phn.chg = (int)v.toInt();
      else if (k == "name") { v.replace("_", " "); phn.name = asciiOnly(v, 20); }
    }
    i = e + 1;
  }
  phn.at = millis();
  if (phn.at == 0) phn.at = 1;
  dirty = true;
}

// ---------- coi bao (neu co PIN_BUZZ) ----------
uint32_t buzzUntil = 0;
void beep(uint32_t ms) {
  if (PIN_BUZZ >= 0) { digitalWrite(PIN_BUZZ, HIGH); buzzUntil = millis() + ms; }
}

// ---------- cam bien (chip, AHT20, BMP280/BME280, quang tro, pin) ----------
float senChipT = NAN, senExtT = NAN, senHum = NAN, senPres = NAN;
int senLdr = -1;                        // 0..100 (sang)
int senVbatMv = -1;
uint8_t senKind = 0;                    // 0 khong co, 1 AHT20, 2 BMP280, 3 BME280
uint8_t senAddr = 0;
int16_t senHist[60];                    // nhiet do x10, moi 30 giay
int senHistN = 0, senHistPos = 0;

bool i2cPing(uint8_t a) { Wire.beginTransmission(a); return Wire.endTransmission() == 0; }
bool i2cReadReg(uint8_t a, uint8_t reg, uint8_t *buf, uint8_t n) {
  Wire.beginTransmission(a);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)a, (int)n) != n) return false;
  for (uint8_t i = 0; i < n; i++) buf[i] = Wire.read();
  return true;
}
bool i2cWriteReg(uint8_t a, uint8_t reg, uint8_t v) {
  Wire.beginTransmission(a);
  Wire.write(reg);
  Wire.write(v);
  return Wire.endTransmission() == 0;
}

struct BmpCal { uint16_t t1; int16_t t2, t3; uint16_t p1; int16_t p2, p3, p4, p5, p6, p7, p8, p9; } bmp;

void sensorsBegin() {
  if (i2cPing(0x38)) { senKind = 1; senAddr = 0x38; }
  else {
    uint8_t cand[2] = {0x76, 0x77};
    for (int k = 0; k < 2 && !senKind; k++) {
      uint8_t id = 0;
      if (i2cPing(cand[k]) && i2cReadReg(cand[k], 0xD0, &id, 1) && (id == 0x58 || id == 0x60)) {
        uint8_t c[24];
        if (!i2cReadReg(cand[k], 0x88, c, 24)) continue;
        bmp.t1 = (uint16_t)(c[0] | (c[1] << 8));  bmp.t2 = (int16_t)(c[2] | (c[3] << 8));  bmp.t3 = (int16_t)(c[4] | (c[5] << 8));
        bmp.p1 = (uint16_t)(c[6] | (c[7] << 8));  bmp.p2 = (int16_t)(c[8] | (c[9] << 8));  bmp.p3 = (int16_t)(c[10] | (c[11] << 8));
        bmp.p4 = (int16_t)(c[12] | (c[13] << 8)); bmp.p5 = (int16_t)(c[14] | (c[15] << 8)); bmp.p6 = (int16_t)(c[16] | (c[17] << 8));
        bmp.p7 = (int16_t)(c[18] | (c[19] << 8)); bmp.p8 = (int16_t)(c[20] | (c[21] << 8)); bmp.p9 = (int16_t)(c[22] | (c[23] << 8));
        i2cWriteReg(cand[k], 0xF5, 0xA0);     // standby 1s, loc tat
        i2cWriteReg(cand[k], 0xF4, 0x27);     // nhiet x1, ap suat x1, che do lien tuc
        senKind = (id == 0x58) ? 2 : 3;
        senAddr = cand[k];
      }
    }
  }
  if (PIN_LDR >= 0) pinMode(PIN_LDR, INPUT);
  if (PIN_VBAT >= 0) pinMode(PIN_VBAT, INPUT);
}

uint32_t senTrigAt = 0;                 // AHT20: thoi diem bat dau do, doc ket qua sau ~90 ms
void sensorsTick() {
  uint32_t now = millis();
  static uint32_t last = 0, lastHist = 0;
  if (senKind == 1 && senTrigAt != 0 && now - senTrigAt >= 90) {
    senTrigAt = 0;
    uint8_t b[7];
    if (i2cReadReg(0x38, 0x71, b, 1) && (b[0] & 0x80) == 0) {
      Wire.requestFrom(0x38, 7);
      for (int i = 0; i < 7 && Wire.available(); i++) b[i] = Wire.read();
      uint32_t h = ((uint32_t)b[1] << 12) | ((uint32_t)b[2] << 4) | (b[3] >> 4);
      uint32_t t = ((uint32_t)(b[3] & 0x0F) << 16) | ((uint32_t)b[4] << 8) | b[5];
      senHum = h * 100.0f / 1048576.0f;
      senExtT = t * 200.0f / 1048576.0f - 50.0f;
    }
  }
  if (now - last < 2000) return;
  last = now;
  senChipT = temperatureRead();
  if (PIN_LDR >= 0) senLdr = 100 - (int)(analogRead(PIN_LDR) * 100L / 4095);    // nhieu sang -> dien ap thap (LDR phia tren); doi neu cam nguoc
  if (PIN_VBAT >= 0) senVbatMv = (int)analogReadMilliVolts(PIN_VBAT) * 2;
  if (senKind == 1) {
    uint8_t cmd[3] = {0xAC, 0x33, 0x00};
    Wire.beginTransmission(0x38);
    Wire.write(cmd, 3);
    if (Wire.endTransmission() == 0) senTrigAt = now ? now : 1;
  } else if (senKind >= 2) {
    uint8_t d[6];
    if (i2cReadReg(senAddr, 0xF7, d, 6)) {
      int32_t adcP = ((int32_t)d[0] << 12) | ((int32_t)d[1] << 4) | (d[2] >> 4);
      int32_t adcT = ((int32_t)d[3] << 12) | ((int32_t)d[4] << 4) | (d[5] >> 4);
      if (adcT != 0x80000) {
        double v1 = (adcT / 16384.0 - bmp.t1 / 1024.0) * bmp.t2;
        double v2 = ((adcT / 131072.0 - bmp.t1 / 8192.0) * (adcT / 131072.0 - bmp.t1 / 8192.0)) * bmp.t3;
        double tf = v1 + v2;
        senExtT = (float)(tf / 5120.0);
        double a1 = tf / 2.0 - 64000.0;
        double a2 = a1 * a1 * bmp.p6 / 32768.0;
        a2 = a2 + a1 * bmp.p5 * 2.0;
        a2 = a2 / 4.0 + bmp.p4 * 65536.0;
        a1 = (bmp.p3 * a1 * a1 / 524288.0 + bmp.p2 * a1) / 524288.0;
        a1 = (1.0 + a1 / 32768.0) * bmp.p1;
        if (a1 != 0.0 && adcP != 0x80000) {
          double p = 1048576.0 - adcP;
          p = (p - a2 / 4096.0) * 6250.0 / a1;
          a1 = bmp.p9 * p * p / 2147483648.0;
          a2 = p * bmp.p8 / 32768.0;
          p = p + (a1 + a2 + bmp.p7) / 16.0;
          senPres = (float)(p / 100.0);          // hPa
        }
      }
    }
  }
  if (now - lastHist >= 30000UL || senHistN == 0) {
    lastHist = now;
    float t = !isnan(senExtT) ? senExtT : senChipT;
    if (!isnan(t)) {
      senHist[senHistPos] = (int16_t)(t * 10);
      senHistPos = (senHistPos + 1) % 60;
      if (senHistN < 60) senHistN++;
    }
  }
}
float senBestT() { return !isnan(senExtT) ? senExtT : senChipT; }
int vbatPercent() {                       // Li-ion: 3.3V = 0%, 4.2V = 100% (xap xi)
  if (senVbatMv < 0) return -1;
  return clampi((senVbatMv - 3300) * 100 / 900, 0, 100);
}

// Tu chinh do sang: ban dem uu tien, khong thi theo quang tro, khong thi theo cai dat
void brightTick() {
  static uint32_t last = 0;
  uint32_t now = millis();
  if (now - last < 3000) return;
  last = now;
  int target = -1;
  if (S.night && haveTime()) {
    struct tm t;
    getTm(t);
    if (t.tm_hour >= 23 || t.tm_hour < 6) target = 0;
  }
  if (target < 0 && S.autoBr && senLdr >= 0) target = clampi(senLdr / 21, 0, 4);
  if (target != effBright) { effBright = target; applyDisplay(); dirty = true; }
}

// ---------- canh bao thong minh ----------
enum { RL_CPU, RL_RAM, RL_PCBAT, RL_PHBAT, RL_TEMP, RL_LINK, RL_N };
const char *RULE_NAMES[RL_N] = {"PC: CPU > 90%", "PC: RAM > 90%", "PC: pin < 20%", "DT: pin < 15%", "ESP: nong > 75C", "PC: mat ket noi"};
uint32_t ruleLast[RL_N] = {0, 0, 0, 0, 0, 0};
int cpuHigh = 0;
void alertRule(int r, const String &title, const String &text) {
  if (!(S.rules & (1 << r))) return;
  uint32_t now = millis();
  if (ruleLast[r] != 0 && now - ruleLast[r] < 300000UL) return;       // moi canh bao toi da 5 phut 1 lan
  ruleLast[r] = now ? now : 1;
  showPopup(title, text);
  beep(400);
}
void rulesCheck() {
  if (pcxFresh()) {
    cpuHigh = (pcx.cpu > 90) ? cpuHigh + 1 : 0;
    if (cpuHigh >= 5) alertRule(RL_CPU, "Canh bao PC", "CPU cao " + String(pcx.cpu) + "% trong 10 giay");
    if (pcx.mem > 90) alertRule(RL_RAM, "Canh bao PC", "RAM day " + String(pcx.mem) + "%");
    if (pcx.bat >= 0 && pcx.bat < 20 && !pcx.chg) alertRule(RL_PCBAT, "Pin PC yeu", String(pcx.bat) + "% - cam sac");
  }
  if (phoneFresh() && phn.bat >= 0 && phn.bat < 15 && !phn.chg) alertRule(RL_PHBAT, "Pin dien thoai", String(phn.bat) + "% - cam sac");
  if (!isnan(senChipT) && senChipT > 75.0f) alertRule(RL_TEMP, "ESP32 nong", String(senChipT, 0) + " do C");
}

// ---------- vong lap nhe, goi moi vong loop() ----------
void pcTick() {
  uint32_t now = millis();
  if (buzzUntil && (int32_t)(now - buzzUntil) >= 0) { buzzUntil = 0; if (PIN_BUZZ >= 0 && !ringing) digitalWrite(PIN_BUZZ, LOW); }
  bool linked = pcLinked();
  if (linked != pcWasLinked) {
    pcWasLinked = linked;
    dirty = true;
    if (linked) { pcEverLinked = true; showPopup("May tinh", "Da noi PC (USB)"); }
    else if (pcEverLinked) { alertRule(RL_LINK, "May tinh", "Mat ket noi PC"); }
  }
  static uint32_t lastRule = 0;
  if (now - lastRule >= 2000) { lastRule = now; rulesCheck(); }
  sensorsTick();
  brightTick();
}
