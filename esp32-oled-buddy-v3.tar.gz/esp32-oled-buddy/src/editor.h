// ============================================================
//  Soan van ban bang 2 nut (cung dung de nhap tu khoa tim kiem, mat khau WiFi...)
//  A (D4)  bam: ky tu ke tiep (GIU de chay nhanh)
//  B (D18) bam: CHON ky tu dang sang  |  GIU B: huy ky tu vua chon va mo MENU soan
//  Cuoi vong ky tu co "<-" (xoa) va ">>" (doi bang: abc / ABC / so / ky hieu / tu thuong dung)
// ============================================================
#pragma once
#include "core.h"
#include "apps.h"
#include "net.h"
#include "pc.h"

String edBuf, edTitle, edPrevBuf;
int edPurpose = ED_NOTE, edMax = 200, edSet = 0, edIdx = 0, edBack = SC_MENU;
bool edMenu = false, edLastCommit = false;
int edMenuSel = 0;
uint32_t edLastAt = 0, edRepeatAt = 0;
std::vector<String> edRing;
std::vector<int> edMenuIds;

const char *ED_SETS[4] = {"abcdefghijklmnopqrstuvwxyz ", "ABCDEFGHIJKLMNOPQRSTUVWXYZ ", "0123456789.,:;/-_+=*#@", "!?'\"()[]{}<>&|~$%^\\`"};
const char *ED_WORDS[] = {"sudo ", "ls ", "cd ", "git ", "pacman -S ", "grep ", "cat ", "nano ", "systemctl ", "ssh ", ".txt", "http://", "~/", " && ", " | ", " > ", "--help", "-h"};
const int ED_WORDS_N = sizeof(ED_WORDS) / sizeof(ED_WORDS[0]);
const char *ED_SET_LABEL[5] = {"ab", "AB", "12", "#!", "wd"};

enum { EDM_CONTINUE, EDM_DONE, EDM_NEWLINE, EDM_CLEAR, EDM_SAVEFILE, EDM_TYPEPC, EDM_TYPEENTER, EDM_CLIPPC, EDM_QUIT };
const char *EDM_NAMES[] = {"Tiep tuc", "Xong", "Xuong dong", "Xoa het", "Luu file .txt", "Go tren PC", "Go + Enter", "Chep vao clipboard PC", "Thoat"};

void edBuildRing() {
  edRing.clear();
  if (edSet < 4) {
    for (const char *p = ED_SETS[edSet]; *p; p++) edRing.push_back(String(*p));
  } else {
    for (int i = 0; i < ED_WORDS_N; i++) edRing.push_back(String(ED_WORDS[i]));
  }
  edRing.push_back("\x01" "DEL");
  edRing.push_back("\x01" "SET");
  if (edIdx >= (int)edRing.size()) edIdx = 0;
}

void edOpen(int purpose, const String &title, const String &init, int maxLen) {
  edPurpose = purpose;
  edTitle = title;
  edBuf = init;
  edMax = maxLen;
  edSet = 0;
  edIdx = 0;
  edMenu = false;
  edLastCommit = false;
  edBack = (screen == SC_EDITOR) ? edBack : screen;
  edMenuIds.clear();
  edMenuIds.push_back(EDM_CONTINUE);
  edMenuIds.push_back(EDM_DONE);
  if (purpose == ED_NOTE) { edMenuIds.push_back(EDM_SAVEFILE); edMenuIds.push_back(EDM_TYPEPC); edMenuIds.push_back(EDM_CLIPPC); edMenuIds.push_back(EDM_NEWLINE); }
  if (purpose == ED_TYPE) { edMenuIds.push_back(EDM_TYPEENTER); edMenuIds.push_back(EDM_CLIPPC); edMenuIds.push_back(EDM_NEWLINE); }
  edMenuIds.push_back(EDM_CLEAR);
  edMenuIds.push_back(EDM_QUIT);
  edBuildRing();
  go(SC_EDITOR);
}

const char *edDoneLabel() {
  switch (edPurpose) {
    case ED_NOTE: return "Luu ghi chu";
    case ED_TYPE: return "Go tren PC";
    case ED_SEARCH: return "Tim lenh";
    case ED_MAN: return "Hoi PC (man)";
    case ED_WIFIPASS: return "Luu & ket noi";
  }
  return "Xong";
}

void edStep(int d) {
  int n = (int)edRing.size();
  edIdx = (edIdx + d + n) % n;
}

void edAppend(const String &t) {
  if ((int)edBuf.length() + (int)t.length() <= edMax) edBuf += t;
}

void edTypeToPc(bool enter) {
  if (!pcLinked()) { showPopup("May tinh", "Chua noi PC (chay buddyd.py)"); return; }
  int i = 0, n = (int)edBuf.length();
  while (i <= n) {
    int e = edBuf.indexOf('\n', i);
    if (e < 0) e = n;
    String line = edBuf.substring(i, e);
    if (line.length()) pcSend("T " + line);
    if (e < n) pcSend("K Return");
    i = e + 1;
  }
  if (enter) pcSend("K Return");
  showPopup("Da go tren PC", String((int)edBuf.length()) + " ky tu");
}

void edDone() {
  String t = edBuf;
  switch (edPurpose) {
    case ED_NOTE: {
      String one = t;
      one.replace("\n", " ");
      one = sanitize(one);
      if (!one.length()) { showPopup("Soan van ban", "Chua co chu"); return; }
      addNote(one);
      showPopup("Da luu ghi chu", one);
      go(SC_MENU);
      break;
    }
    case ED_TYPE: edTypeToPc(false); go(edBack); break;
    case ED_SEARCH: cheatSearchOpen(t); break;
    case ED_MAN: {
      String q = t;
      q.trim();
      if (!q.length()) { go(edBack); break; }
      if (!pcSend("MAN " + q)) showPopup("May tinh", "Chua noi PC (chay buddyd.py)");
      else showPopup("Hoi PC", "Dang tra " + q.substring(0, 12));
      go(edBack);
      break;
    }
    case ED_WIFIPASS: {
      if (t.length() != 0 && (t.length() < 8 || t.length() > 63)) { showPopup("WiFi", "Mat khau can 8-63 ky tu"); return; }
      wifiPass = t;
      prefs.putString("pass", wifiPass);
      S.wifiOn = true;
      saveSettings();
      scheduleWifiRestart(300);
      showPopup("WiFi", "Dang ket noi lai...");
      go(SC_NET);
      break;
    }
  }
}

void edSaveFile() {
  char name[72];
  if (haveTime()) {
    struct tm tt;
    getTm(tt);
    snprintf(name, sizeof(name), "/soan-%04d%02d%02d-%02d%02d.txt", tt.tm_year + 1900, tt.tm_mon + 1, tt.tm_mday, tt.tm_hour, tt.tm_min);
  } else {
    snprintf(name, sizeof(name), "/soan-%lu.txt", (unsigned long)(millis() / 1000));
  }
  File f = LittleFS.open(name, "w");
  if (!f) { showPopup("Loi", "Khong ghi duoc file"); return; }
  f.print(edBuf);
  f.close();
  showPopup("Da luu file", String(name + 1));
}

void edMenuAction(int id) {
  switch (id) {
    case EDM_CONTINUE: edMenu = false; break;
    case EDM_DONE: edDone(); edMenu = false; break;
    case EDM_NEWLINE: edAppend("\n"); edMenu = false; break;
    case EDM_CLEAR: edBuf = ""; edMenu = false; break;
    case EDM_SAVEFILE: edSaveFile(); edMenu = false; break;
    case EDM_TYPEPC: edTypeToPc(false); edMenu = false; break;
    case EDM_TYPEENTER: edTypeToPc(true); edMenu = false; break;
    case EDM_CLIPPC: {
      String t = edBuf;
      t.replace("\n", "\x1F");
      if (pcSend("CLIP " + t)) showPopup("Clipboard PC", "Da chep " + String((int)edBuf.length()) + " ky tu");
      else showPopup("May tinh", "Chua noi PC (chay buddyd.py)");
      edMenu = false;
      break;
    }
    case EDM_QUIT: edMenu = false; go(edBack); break;
  }
}

void handleEditor(int e) {
  uint32_t now = millis();
  if (edMenu) {
    int n = (int)edMenuIds.size();
    if (e == EV_UP) edMenuSel = (edMenuSel + 1) % n;
    else if (e == EV_DOWN) { int id = edMenuIds[edMenuSel]; edLastCommit = false; edMenuAction(id); }
    return;                                                // giu B trong menu: bo qua (chon "Tiep tuc" de dong)
  }
  if (e == EV_UP) { edStep(1); edLastCommit = false; }
  else if (e == EV_DOWN) {
    const String &it = edRing[edIdx];
    edPrevBuf = edBuf;
    if (it.length() && it[0] == 1) {
      if (it == "\x01" "DEL") { if (edBuf.length()) edBuf.remove(edBuf.length() - 1); }
      else { edSet = (edSet + 1) % 5; edIdx = 0; edBuildRing(); }
      edLastCommit = false;
    } else {
      edAppend(it);
      edLastCommit = true;
      edLastAt = now;
    }
  } else if (e == EV_BACK) {                              // giu B: hoan tac ky tu vua chon + mo menu
    if (edLastCommit && now - edLastAt < 1500) { edBuf = edPrevBuf; }
    edLastCommit = false;
    edMenu = true;
    edMenuSel = 0;
  }
}

void edTick() {                                           // giu A de chay nhanh qua cac ky tu
  if (screen != SC_EDITOR || edMenu) return;
  Btn &a = btns[0];
  uint32_t now = millis();
  if (!a.pressed) return;
  uint32_t held = now - a.tDown;
  if (held > 380 && now - edRepeatAt > (held > 1600 ? 40UL : 85UL)) { edRepeatAt = now; edStep(1); dirty = true; }
}

String edLabel(const String &it) {
  if (it.length() && it[0] == 1) return it == "\x01" "DEL" ? String("<-") : String(ED_SET_LABEL[(edSet + 1) % 5]);
  return it;
}

void drawEditor() {
  oled.setCursor(0, 1);
  String ti = edTitle;
  if (ti.length() > 12) ti = ti.substring(0, 12);
  oled.print(ti);
  char b[24];
  snprintf(b, sizeof(b), "%d/%d", (int)edBuf.length(), edMax);
  oled.setCursor(128 - 6 * (int)strlen(b), 1);
  oled.print(b);
  oled.drawFastHLine(0, 10, 128, C_ON);

  if (edMenu) {
    std::vector<String> names;
    for (size_t i = 0; i < edMenuIds.size(); i++) names.push_back(edMenuIds[i] == EDM_DONE ? String(edDoneLabel()) : String(EDM_NAMES[edMenuIds[i]]));
    drawRows(names, nullptr, edMenuSel, 13, 5);
    return;
  }

  // vung chu: 3 dong cuoi cua noi dung (cat cung 21 cot)
  std::vector<String> lines;
  String cur;
  for (unsigned i = 0; i < edBuf.length(); i++) {
    char c = edBuf[i];
    if (c == '\n') { lines.push_back(cur); cur = ""; }
    else { cur += c; if ((int)cur.length() >= 21) { lines.push_back(cur); cur = ""; } }
  }
  lines.push_back(cur);
  int from = imax(0, (int)lines.size() - 3);
  for (int k = 0; k < 3 && from + k < (int)lines.size(); k++) {
    oled.setCursor(0, 13 + k * 9);
    oled.print(lines[from + k]);
    if (from + k == (int)lines.size() - 1 && (millis() / 400) % 2 == 0) oled.print('_');
  }

  // dai chon ky tu: 7 o, o giua duoc to sang
  int n = (int)edRing.size();
  for (int k = -3; k <= 3; k++) {
    int idx = ((edIdx + k) % n + n) % n;
    String lb = edLabel(edRing[idx]);
    if (lb.length() > 2) lb = lb.substring(0, 2);
    int x = 64 + k * 18;
    if (k == 0) {
      oled.fillRoundRect(x - 9, 41, 18, 13, 3, C_ON);
      oled.setTextColor(C_OFF);
    } else oled.setTextColor(C_ON);
    oled.setCursor(x - (int)lb.length() * 3, 44);
    oled.print(lb);
  }
  oled.setTextColor(C_ON);
  String full = edLabel(edRing[edIdx]);
  if (edRing[edIdx].length() && edRing[edIdx][0] == 1) {
    full = (edRing[edIdx] == "\x01" "DEL") ? String("xoa ky tu") : String("doi bang: ") + ED_SET_LABEL[(edSet + 1) % 5];
  } else if (full == " ") full = "dau cach";
  oled.setCursor(0, 56);
  oled.print("A>  B:chon  ");
  oled.print(full.substring(0, 9));
}
