// ============================================================
//  Trang web tren dien thoai (http://buddy.local): bang dieu khien, touchpad, ban phim, soan thao,
//  lenh PC, tra cuu lenh, webhook, cai dat. Giao dien toi, hieu ung muot, dung nhu mot ung dung.
// ============================================================
#pragma once
#include <Arduino.h>

const char PAGE2[] PROGMEM = R"HTML(<!doctype html><html lang=vi><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no"><meta name=theme-color content="#0b0d17">
<title>ESP32 Buddy</title>
<style>
:root{--bg:#0b0d17;--c1:#151827;--c2:#1d2136;--ln:#2a2f4a;--tx:#e6e9ff;--dim:#8b91b5;--ac:#8b7cff;--ac2:#4fd1ff;--ok:#3ddc97;--bad:#ff6b8b;--warn:#ffc857}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overscroll-behavior:none}
body{padding:0 14px calc(92px + env(safe-area-inset-bottom));max-width:560px;margin:0 auto;background:radial-gradient(900px 420px at 80% -10%,#2a2160 0,transparent 60%),radial-gradient(700px 380px at -10% 10%,#12354a 0,transparent 55%),var(--bg);background-attachment:fixed;min-height:100vh}
h1{font-size:20px;margin:0;display:flex;align-items:center;gap:10px}
header{display:flex;justify-content:space-between;align-items:center;padding:calc(14px + env(safe-area-inset-top)) 2px 8px}
.chips{display:flex;gap:6px;flex-wrap:wrap}
.chip{display:flex;align-items:center;gap:6px;font-size:12px;padding:5px 10px;border-radius:99px;background:var(--c1);border:1px solid var(--ln);color:var(--dim);transition:.3s}
.chip i{width:8px;height:8px;border-radius:50%;background:#555b7a;display:block}
.chip.on{color:var(--tx);border-color:#3a4a7a}.chip.on i{background:var(--ok);box-shadow:0 0 0 0 var(--ok);animation:pulse 2s infinite}
@keyframes pulse{0%{box-shadow:0 0 0 0 #3ddc9788}70%{box-shadow:0 0 0 8px #3ddc9700}100%{box-shadow:0 0 0 0 #3ddc9700}}
.card{background:linear-gradient(160deg,#1a1e33cc,#12152499);backdrop-filter:blur(10px);border:1px solid var(--ln);border-radius:20px;padding:14px;margin:12px 0;animation:up .5s both}
.card h3{margin:0 0 10px;font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--dim);font-weight:600}
@keyframes up{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.tab{display:none}.tab.on{display:block}
.rings{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;text-align:center}
.ring{position:relative}.ring svg{width:100%;max-width:84px;transform:rotate(-90deg)}
.ring circle{fill:none;stroke-width:3.2;stroke-linecap:round}.ring .bg{stroke:#262b46}
.ring .fg{stroke:url(#gr);transition:stroke-dasharray .9s cubic-bezier(.2,.8,.2,1)}
.ring b{position:absolute;left:0;right:0;top:50%;transform:translateY(-62%);font-size:17px}.ring small{display:block;color:var(--dim);font-size:11px;margin-top:-4px}
.kv{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;color:var(--dim);font-size:13px;margin-top:10px}.kv b{color:var(--tx);font-weight:600}
.np{display:flex;align-items:center;gap:12px;margin-top:12px;padding:10px 12px;background:#0f1220;border-radius:14px;border:1px solid var(--ln)}
.eq{display:flex;gap:3px;align-items:flex-end;height:22px}.eq i{width:4px;background:linear-gradient(var(--ac2),var(--ac));border-radius:2px;height:4px;transition:height .2s}
.eq.go i{animation:eq .9s ease-in-out infinite}.eq.go i:nth-child(2){animation-delay:.2s}.eq.go i:nth-child(3){animation-delay:.4s}.eq.go i:nth-child(4){animation-delay:.1s}
@keyframes eq{0%,100%{height:4px}50%{height:22px}}
.np div.t{flex:1;min-width:0}.np .t b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.np .t span{color:var(--dim);font-size:12px}
button,.btn{font:inherit;color:var(--tx);background:var(--c2);border:1px solid var(--ln);border-radius:14px;padding:10px 14px;cursor:pointer;transition:transform .12s,background .2s,box-shadow .2s;user-select:none;touch-action:manipulation}
button:active{transform:scale(.94)}button.p{background:linear-gradient(135deg,var(--ac),#5b8cff);border:0;font-weight:700;color:#fff;box-shadow:0 6px 20px #6a5cff44}
button.s{padding:8px 11px;font-size:13px}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.row>*{flex:1}.row.n>*{flex:none}
input,textarea,select{width:100%;font:inherit;color:var(--tx);background:#0f1220;border:1px solid var(--ln);border-radius:14px;padding:11px 12px;outline:0;transition:border .2s}
input:focus,textarea:focus{border-color:var(--ac)}textarea{resize:vertical}
#pad{height:230px;border-radius:22px;background:repeating-linear-gradient(45deg,#12162a,#12162a 14px,#141934 14px,#141934 28px);border:1px solid var(--ln);position:relative;overflow:hidden;touch-action:none;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:13px;text-align:center}
#pad .rp{position:absolute;border-radius:50%;background:#8b7cff55;transform:scale(0);animation:rp .6s ease-out forwards;pointer-events:none}
@keyframes rp{to{transform:scale(1);opacity:0}}
.keys{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:8px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
nav{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(12px + env(safe-area-inset-bottom));width:min(540px,calc(100% - 24px));display:grid;grid-template-columns:repeat(5,1fr);background:#141831ee;backdrop-filter:blur(16px);border:1px solid var(--ln);border-radius:26px;padding:6px;z-index:5;box-shadow:0 10px 40px #0009}
nav button{background:none;border:0;padding:8px 0 6px;font-size:11px;color:var(--dim);position:relative;z-index:1;border-radius:20px}nav button span{display:block;font-size:20px;line-height:1.1}nav button.on{color:#fff}
#ind{position:absolute;left:6px;top:6px;bottom:6px;width:calc((100% - 12px)/5);background:linear-gradient(135deg,#4a3fbf,#2f6bd8);border-radius:20px;transition:transform .35s cubic-bezier(.3,1.3,.5,1);z-index:0}
.list>div{display:flex;gap:8px;align-items:center;padding:9px 0;border-bottom:1px solid var(--ln)}.list>div:last-child{border:0}.list span{flex:1;min-width:0;word-break:break-word}
code{background:#0b0e1c;border:1px solid var(--ln);border-radius:8px;padding:2px 6px;font:12px ui-monospace,monospace;color:var(--ac2);word-break:break-all}
pre{background:#0b0e1c;border:1px solid var(--ln);border-radius:14px;padding:10px;white-space:pre-wrap;word-break:break-word;font:12px ui-monospace,monospace;max-height:320px;overflow:auto;margin:8px 0 0}
#toast{position:fixed;left:50%;top:calc(14px + env(safe-area-inset-top));transform:translate(-50%,-80px);background:#232846;border:1px solid var(--ac);border-radius:16px;padding:10px 16px;z-index:20;transition:transform .4s cubic-bezier(.3,1.4,.5,1);max-width:90%;box-shadow:0 10px 30px #000a}
#toast.on{transform:translate(-50%,0)}
#find{position:fixed;inset:0;background:radial-gradient(circle,#ff6b8bee,#7a1d3aff);z-index:30;display:none;align-items:center;justify-content:center;flex-direction:column;gap:18px;font-size:26px;font-weight:800;animation:fl .6s infinite alternate}
@keyframes fl{to{filter:brightness(1.5)}}
.sw{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--ln)}.sw:last-child{border:0}
.sw input{display:none}.sw i{width:46px;height:26px;border-radius:99px;background:#2b3050;position:relative;transition:.25s;flex:none}.sw i:after{content:"";position:absolute;left:3px;top:3px;width:20px;height:20px;border-radius:50%;background:#fff;transition:.25s}.sw input:checked+i{background:var(--ok)}.sw input:checked+i:after{transform:translateX(20px)}
.wx{display:flex;justify-content:space-between;align-items:center}.wx .t{font-size:40px;font-weight:800}.wx .i{font-size:50px}
canvas{width:100%;image-rendering:pixelated;border-radius:10px;background:#000;border:1px solid var(--ln)}
</style></head><body>
<svg width=0 height=0 style=position:absolute><defs><linearGradient id=gr x1=0 y1=0 x2=1 y2=1><stop offset=0 stop-color=#8b7cff /><stop offset=1 stop-color=#4fd1ff /></linearGradient></defs></svg>
<header><h1>📟 Buddy <small style="font-weight:400;color:var(--dim);font-size:12px" id=fw></small></h1>
<div class=chips><div class=chip id=cW><i></i>WiFi</div><div class=chip id=cP><i></i>PC</div></div></header>

<section class="tab on" id=t-home>
<div class=card><h3>Máy tính <span id=pcn style="text-transform:none;letter-spacing:0"></span></h3>
<div class=rings id=rings></div>
<div class=kv><span>🌡 <b id=pT>--</b></span><span>💽 <b id=pD>--</b></span><span>⬇ <b id=pRx>--</b></span><span>⬆ <b id=pTx>--</b></span><span>⏱ <b id=pU>--</b></span></div>
<div class=np><div class=eq id=eq><i></i><i></i><i></i><i></i></div><div class=t><b id=pM>Chưa phát nhạc</b><span id=pW>—</span></div></div>
<div class=row><button onclick="A('prev')">⏮</button><button class=p onclick="A('playpause')">⏯</button><button onclick="A('next')">⏭</button><button onclick="A('mute')">🔇</button><button onclick="A('lock')">🔒</button></div>
<div id=pcOff style="display:none;color:var(--dim);font-size:13px;margin-top:10px">PC chưa nối. Cắm cáp USB và chạy <code>buddyd.py</code> (hoặc bật “Buddy” trong shell).</div></div>
<div class=card><h3>Thời tiết</h3><div class=wx><div><div class=t id=wt>--°</div><div id=wc>…</div><div style="color:var(--dim);font-size:12px" id=wa></div></div><div class=i id=wi>⛅</div></div>
<div class=kv><span>💧 <b id=wh>--</b></span><span>🌬 <b id=ww>--</b></span><span id=wu></span></div></div>
<div class=card><h3>ESP32 &amp; cảm biến</h3><div class=kv style="margin:0"><span>🌡 <b id=sT>--</b></span><span>💧 <b id=sH>--</b></span><span>🧭 <b id=sP>--</b></span><span>☀ <b id=sL>--</b></span><span>🔋 <b id=sB>--</b></span></div><pre id=st style="max-height:90px"></pre></div>
</section>

<section class=tab id=t-pad>
<div class=card><h3>Touchpad</h3><div id=pad>Chạm = chuột trái · 2 ngón chạm = chuột phải<br>2 ngón kéo = cuộn<span id=padl></span></div>
<div class=keys style="grid-template-columns:repeat(3,1fr)"><button onclick="Cl('l')">Trái</button><button onclick="Cl('m')">Giữa</button><button onclick="Cl('r')">Phải</button></div>
<div class=row style="align-items:center"><span style="flex:none;color:var(--dim);font-size:13px">Độ nhạy</span><input type=range id=gain min=.6 max=4 step=.1 value=1.6 style="padding:0"></div></div>
<div class=card><h3>Bàn phím → PC</h3><input id=kt placeholder="Gõ tiếng Việt có dấu cũng được…" autocomplete=off>
<div class=row><button class=p onclick="Ty(0)">Gõ</button><button onclick="Ty(1)">Gõ + Enter</button><button onclick="CpPc()">Chép clipboard</button></div>
<div class=keys><button onclick="K('Escape')">Esc</button><button onclick="K('Tab')">Tab</button><button onclick="K('BackSpace')">⌫</button><button onclick="K('Return')">⏎</button>
<button onclick="K('Left')">◀</button><button onclick="K('Up')">▲</button><button onclick="K('Down')">▼</button><button onclick="K('Right')">▶</button>
<button onclick="K('ctrl+c')">Copy</button><button onclick="K('ctrl+v')">Paste</button><button onclick="K('alt+Tab')">Alt+Tab</button><button onclick="K('super')">Super</button></div></div>
<div class=card><h3>Trình chiếu &amp; âm lượng</h3><div class=grid2><button class=p style="padding:18px" onclick="K('Left')">◀ Trước</button><button class=p style="padding:18px" onclick="K('Right')">Sau ▶</button></div>
<div class=row><button onclick="K('F5')">▶ F5</button><button onclick="K('Escape')">Esc</button><button onclick="K('b')">Màn đen</button></div>
<div class=row><button onclick="A('vol -5')">🔉 −</button><button onclick="A('vol +5')">🔊 +</button><button onclick="A('bri -10')">🔅 −</button><button onclick="A('bri +10')">🔆 +</button></div></div>
</section>

<section class=tab id=t-edit>
<div class=card><h3>Soạn nhanh</h3><textarea id=t rows=4 placeholder="Nội dung…"></textarea>
<div class=row><button class=p onclick="note()">Ghi chú ESP</button><button onclick="msg()">Popup ESP</button></div>
<div class=row><button onclick="Ty2()">Gõ lên PC</button><button onclick="CpPc2()">Clipboard PC</button><button onclick="phClip()">DT → ESP</button></div></div>
<div class=card><h3>Gửi file</h3><div class=row><button class=p onclick="location.href=shareUrl()" id=toPc>📤 Gửi lên PC</button><button onclick="$('f').click()">📟 Gửi lên ESP (.txt)</button></div>
<input type=file id=f accept=".txt,.md,.log" style=display:none onchange=up()><div class=list id=fl style="margin-top:6px"></div></div>
<div class=card><h3>Ảnh nền OLED</h3><canvas id=cv width=128 height=64></canvas>
<div class=row><button onclick="$('wf').click()">Chọn ảnh</button><label class=sw style="flex:none;border:0;padding:0;gap:8px"><span>Dither</span><input type=checkbox id=wd checked onchange=wallDraw()><i></i></label></div>
<input type=file id=wf accept=image/* style=display:none onchange=wallLoad()><input type=range id=wth min=40 max=220 value=128 oninput=wallDraw() style="padding:0;margin-top:8px">
<div class=row><button class=p onclick=wallSend()>Gửi làm hình nền</button><button onclick="wInv=!wInv;wallDraw()">Đảo màu</button></div></div>
</section>

<section class=tab id=t-cmd>
<div class=card><h3>Lệnh trên PC</h3><div class=list id=cmds><div style="color:var(--dim)">Chưa có (PC chưa nối)</div></div><pre id=vout style="display:none"></pre></div>
<div class=card><h3>Tra cứu lệnh Linux</h3><input id=cq placeholder="vd: dung luong, git, wifi, grep…" oninput=cheatDeb()><div class=list id=ch></div>
<div class=row><input id=mq placeholder="man / tldr trên PC: tên lệnh" style="flex:2"><button class=p onclick=man()>Hỏi PC</button></div></div>
<div class=card><h3>Webhook nhà thông minh</h3><div class=list id=hk></div><textarea id=hkt rows=3 placeholder="tên|http://url — mỗi dòng 1 webhook" style="margin-top:8px"></textarea><div class=row><button onclick=hkSave()>Lưu danh sách</button></div></div>
</section>

<section class=tab id=t-set>
<div class=card><h3>Hiển thị &amp; tự động</h3><div id=sws></div>
<div class=row style="align-items:center"><span style="flex:none;color:var(--dim)">Độ sáng</span><input type=range id=sbr min=0 max=4 value=2 style="padding:0" onchange="cmd('SET bright '+this.value)"></div>
<div class=row style="align-items:center"><span style="flex:none;color:var(--dim)">Tốc độ chuột</span><input type=range id=smp min=0 max=4 value=2 style="padding:0" onchange="cmd('SET mspd '+this.value)"></div></div>
<div class=card><h3>Cảnh báo thông minh</h3><div id=rls></div></div>
<div class=card><h3>Báo thức / hẹn giờ</h3><div class=row><input id=al type=time><button onclick="if($('al').value)cmd('ALARM '+$('al').value+' on')">Đặt</button><button onclick="cmd('ALARM off')">Tắt</button></div>
<div class=row><input id=tm type=number min=1 placeholder="phút"><button onclick="cmd('TIMER '+($('tm').value||10))">Đếm ngược</button></div></div>
<div class=card><h3>WiFi &amp; vị trí thời tiết</h3><input id=ss placeholder="Tên WiFi"><input id=pw type=password placeholder="Mật khẩu" style="margin-top:8px"><div class=row><button onclick="cmd('WIFI '+$('ss').value+'\t'+$('pw').value)">Lưu &amp; kết nối</button></div>
<div class=row><input id=lat type=number step=any placeholder="Vĩ độ"><input id=lon type=number step=any placeholder="Kinh độ"><button onclick=geo()>Lưu</button></div></div>
<div class=card><h3>Điện thoại</h3><div class=kv style="margin:0"><span>🔋 <b id=mb>--</b></span><span id=mbs style="color:var(--dim)">Gửi pin cho ESP mỗi 30 giây</span></div><div class=row><button onclick=phSend()>Gửi ngay</button><button onclick="cmd('FIND')">Tìm điện thoại (thử)</button></div></div>
</section>

<nav><div id=ind></div>
<button id=n-home class=on onclick="tab('home')"><span>🏠</span>Tổng quan</button><button id=n-pad onclick="tab('pad')"><span>🖱</span>Điều khiển</button><button id=n-edit onclick="tab('edit')"><span>✍️</span>Soạn</button><button id=n-cmd onclick="tab('cmd')"><span>⌨️</span>Lệnh</button><button id=n-set onclick="tab('set')"><span>⚙️</span>Cài đặt</button></nav>
<div id=toast></div><div id=find><div>📱 Tôi ở đây!</div><button class=p onclick=findStop()>Đã thấy</button></div>
<script>
const $=i=>document.getElementById(i);
const S=s=>s.replace(/\r\n?/g,'\n').replace(/\t/g,' ').normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').replace(/[^\x20-\x7e\n]/g,'?');
const U=s=>encodeURIComponent(s).replace(/[!'()*]/g,c=>'%'+c.charCodeAt(0).toString(16).toUpperCase());
let PIN='';try{PIN=localStorage.pin||''}catch(e){}let pl=null,skip=0;
async function F(u,o){const g=()=>fetch(u+(u.indexOf('?')<0?'?':'&')+'p='+encodeURIComponent(PIN),o);let r=await g();
 if(r.status===401||r.status===429){if(r.status===429){toast('Sai PIN nhiều lần, thử lại sau 1 phút');return r}if(Date.now()<skip)return r;
  if(!pl)pl=new Promise(res=>{const v=prompt('Nhập PIN (xem trên OLED: Menu › Mạng & BT › PIN trang web)');if(v!==null){PIN=v.trim();try{localStorage.pin=PIN}catch(e){}}else skip=Date.now()+60000;pl=null;res()});await pl;r=await g()}return r}
let tt;function toast(t){const e=$('toast');e.textContent=t;e.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>e.classList.remove('on'),2200)}
async function cmd(c,q){try{const r=await F('/api/cmd',{method:'POST',body:c});const x=(await r.text()).trim();if(!q)toast(x||'OK');return x}catch(e){toast('Mất kết nối ESP32');return 'ERR net'}}
const tabs=['home','pad','edit','cmd','set'];
function tab(n){tabs.forEach(t=>{$('t-'+t).classList.toggle('on',t===n);$('n-'+t).classList.toggle('on',t===n)});$('ind').style.transform='translateX('+tabs.indexOf(n)*100+'%)';try{localStorage.tab=n}catch(e){}if(n==='cmd'){cheat();hkLoad()}if(n==='edit')ls()}
// ---- vong tron so lieu ----
const RG=[['cpu','CPU'],['mem','RAM'],['bat','Pin'],['vol','Âm']];
$('rings').innerHTML=RG.map(r=>'<div class=ring><svg viewBox="0 0 36 36"><circle class=bg cx=18 cy=18 r=15.9155 /><circle class=fg id=g_'+r[0]+' cx=18 cy=18 r=15.9155 stroke-dasharray="0 100" /></svg><b id=v_'+r[0]+'>--</b><small>'+r[1]+'</small></div>').join('');
function ring(k,v){const g=$('g_'+k),t=$('v_'+k);if(v==null||v<0){g.style.strokeDasharray='0 100';t.textContent='--';return}g.style.strokeDasharray=v+' '+(100-v);t.textContent=v+'%'}
const rate=k=>k==null?'--':(k<1000?k+' K/s':(k/1024).toFixed(1)+' M/s');
// ---- trang thai ----
let P={},lastFind=-1,view=0;
async function poll(){if(pad.touch)return;try{const j=await (await F('/api/pcs')).json();P=j;
 $('cW').classList.add('on');$('cP').classList.toggle('on',!!j.link);$('cP').lastChild.textContent=j.link?(j.fresh?'PC':'PC…'):'PC';$('fw').textContent='v'+j.fw;
 const ok=j.link&&j.fresh;$('pcOff').style.display=ok?'none':'block';$('pcn').textContent=ok?'· '+(j.name||''):'';
 ring('cpu',ok?j.cpu:-1);ring('mem',ok?j.mem:-1);ring('bat',ok?j.bat:-1);ring('vol',ok?(j.mute?0:j.vol):-1);
 $('pT').textContent=ok&&j.temp>=0?j.temp+'°C':'--';$('pD').textContent=ok&&j.disk>=0?j.disk+'%':'--';$('pRx').textContent=ok?rate(j.rx):'--';$('pTx').textContent=ok?rate(j.tx):'--';
 $('pU').textContent=ok?Math.floor(j.up/3600)+'h'+String(Math.floor(j.up/60)%60).padStart(2,'0'):'--';
 $('pM').textContent=ok&&j.media?j.media:'Chưa phát nhạc';$('pW').textContent=ok&&j.win?('Cửa sổ: '+j.win+(j.ws?' · WS '+j.ws:'')):'—';$('eq').classList.toggle('go',ok&&j.mstat==='Playing');
 const s=j.sen||{};$('sT').textContent=s.t!=null?s.t.toFixed(1)+'°C':'--';$('sH').textContent=s.hum!=null?Math.round(s.hum)+'%':'--';$('sP').textContent=s.pres!=null?Math.round(s.pres)+' hPa':'--';$('sL').textContent=s.ldr>=0?s.ldr+'%':'--';$('sB').textContent=s.vbat>=0?s.vbat+'%':'--';
 $('st').textContent='heap '+Math.round(j.heap/1024)+'KB · up '+Math.floor(j.upe/60)+'p · '+(j.ip||'');
 if(j.find!==lastFind){if(lastFind>=0&&j.find>0)findStart();lastFind=j.find}
 if(j.share&&!P._s){P._s=1}
 if(!$('cmds').dataset.n||$('cmds').dataset.n!=(j.cmds||[]).length)renderCmds(j.cmds||[]);
 renderSw(j);
 }catch(e){$('cW').classList.remove('on')}}
function A(a){cmd('ACT '+a,1).then(x=>{if(x.startsWith('ERR'))toast(x.indexOf('linked')>0?'PC chưa nối':x);else toast('Đã gửi')})}
function K(k){cmd('KEY '+k,1).then(x=>{if(x.startsWith('ERR'))toast(x.indexOf('linked')>0?'PC chưa nối':x)})}
function Cl(b){cmd('CLICK '+b,1)}
function shareUrl(){if(P.share)return P.share;toast('PC chưa chạy chia sẻ file');return '#'}
// ---- touchpad ----
const pad={x:0,y:0,t:0,n:0,mv:0,ax:0,ay:0,sc:0,busy:0,touch:0};
const gain=()=>+$('gain').value;
const pe=$('pad');
function rip(x,y){const r=document.createElement('div');r.className='rp';const b=pe.getBoundingClientRect();r.style.cssText='left:'+(x-b.left-40)+'px;top:'+(y-b.top-40)+'px;width:80px;height:80px';pe.appendChild(r);setTimeout(()=>r.remove(),650)}
pe.addEventListener('touchstart',e=>{e.preventDefault();pad.touch=1;const t=e.touches;pad.n=Math.max(pad.n,t.length);if(t.length===1){pad.x=t[0].clientX;pad.y=t[0].clientY;pad.t=Date.now();pad.mv=0;pad.n=1;rip(pad.x,pad.y)}else pad.y=(t[0].clientY+t[1].clientY)/2},{passive:false});
pe.addEventListener('touchmove',e=>{e.preventDefault();const t=e.touches;if(t.length===1&&pad.n===1){const dx=t[0].clientX-pad.x,dy=t[0].clientY-pad.y;pad.x=t[0].clientX;pad.y=t[0].clientY;pad.mv+=Math.abs(dx)+Math.abs(dy);const g=gain()*(1+Math.min(1.5,Math.hypot(dx,dy)/25));pad.ax+=dx*g;pad.ay+=dy*g}else if(t.length>=2){const y=(t[0].clientY+t[1].clientY)/2;pad.sc+=-(y-pad.y)/16;pad.mv+=Math.abs(y-pad.y);pad.y=y}},{passive:false});
pe.addEventListener('touchend',e=>{e.preventDefault();if(e.touches.length===0){if(Date.now()-pad.t<230&&pad.mv<10)Cl(pad.n>=2?'r':'l');pad.n=0;pad.touch=0}},{passive:false});
setInterval(()=>{if(pad.busy)return;let dx=Math.round(pad.ax),dy=Math.round(pad.ay),sc=Math.trunc(pad.sc),c='';
 if(dx||dy){pad.ax-=dx;pad.ay-=dy;c='MOUSE '+Math.max(-120,Math.min(120,dx))+' '+Math.max(-120,Math.min(120,dy))}else if(sc){pad.sc-=sc;c='SCROLL '+sc}
 if(c){pad.busy=1;cmd(c,1).finally(()=>pad.busy=0)}},40);
// ---- ban phim / clipboard ----
function Ty(en){const v=$('kt').value;if(!v)return;cmd('TYPEU '+U(v),1).then(x=>{if(x.startsWith('ERR'))toast('PC chưa nối');else{if(en)K('Return');toast('Đã gõ');$('kt').value=''}})}
function CpPc(){cmd('CLIPU '+U($('kt').value),1).then(x=>toast(x.startsWith('ERR')?'PC chưa nối':'Đã chép'))}
function Ty2(){cmd('TYPEU '+U($('t').value),1).then(x=>toast(x.startsWith('ERR')?'PC chưa nối':'Đã gõ'))}
function CpPc2(){cmd('CLIPU '+U($('t').value),1).then(x=>toast(x.startsWith('ERR')?'PC chưa nối':'Đã chép'))}
function phClip(){cmd('PHNCLIP '+S($('t').value).replace(/\n/g,' '))}
function note(){cmd('NOTE '+S($('t').value).replace(/\n/g,' '))}
function msg(){cmd('MSG '+S($('t').value).replace(/\n/g,' '))}
// ---- file ----
async function up(){const f=$('f').files[0];if(!f)return;const n=f.name.replace(/[^A-Za-z0-9._-]/g,'_');const r=await F('/api/put?n='+encodeURIComponent(n),{method:'POST',body:S(await f.text())});toast(await r.text());ls()}
async function ls(){const j=await (await F('/api/files')).json();const d=$('fl');d.innerHTML='';j.forEach(x=>{const r=document.createElement('div');r.innerHTML='<span></span>';r.firstChild.textContent=x.n+' · '+x.s+' B';
 const b=(t,fn)=>{const e=document.createElement('button');e.className='s';e.textContent=t;e.onclick=fn;r.appendChild(e)};
 b('Đọc',()=>cmd('OPEN '+x.n));b('Xem',()=>window.open('/f?n='+encodeURIComponent(x.n)+'&p='+encodeURIComponent(PIN)));b('Xóa',async()=>{if(confirm('Xóa '+x.n+'?')){await cmd('DEL '+x.n);ls()}});d.appendChild(r)})}
// ---- anh nen ----
let wImg=null,wInv=false,wHex='';
function wallLoad(){const f=$('wf').files[0];if(!f)return;const i=new Image();i.onload=()=>{wImg=i;wallDraw()};i.src=URL.createObjectURL(f)}
function wallDraw(){const c=$('cv'),x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,128,64);if(!wImg)return;
 const s=Math.max(128/wImg.width,64/wImg.height),w=wImg.width*s,h=wImg.height*s;x.drawImage(wImg,(128-w)/2,(64-h)/2,w,h);
 const d=x.getImageData(0,0,128,64),g=new Float32Array(8192);for(let i=0;i<8192;i++)g[i]=.299*d.data[i*4]+.587*d.data[i*4+1]+.114*d.data[i*4+2];
 const th=+$('wth').value,dith=$('wd').checked,bits=new Uint8Array(1024);
 for(let y=0;y<64;y++)for(let X=0;X<128;X++){const i=y*128+X,o=g[i],n=o>th?255:0,er=o-n;if(dith){if(X<127)g[i+1]+=er*7/16;if(y<63){if(X>0)g[i+127]+=er*3/16;g[i+128]+=er*5/16;if(X<127)g[i+129]+=er/16}}
  let on=n>0;if(wInv)on=!on;if(on)bits[y*16+(X>>3)]|=0x80>>(X&7);const k=on?255:0;d.data[i*4]=d.data[i*4+1]=d.data[i*4+2]=k;d.data[i*4+3]=255}
 x.putImageData(d,0,0);wHex=Array.from(bits,b=>b.toString(16).padStart(2,'0')).join('')}
function wallSend(){if(!wHex){toast('Chọn ảnh trước');return}cmd('WALL '+wHex)}
// ---- lenh PC / tra cuu ----
function renderCmds(c){const d=$('cmds');d.dataset.n=c.length;d.innerHTML='';if(!c.length){d.innerHTML='<div style="color:var(--dim)">Chưa có (PC chưa nối)</div>';return}
 c.forEach(x=>{const r=document.createElement('div');r.innerHTML='<span></span>';r.firstChild.textContent=x[1];const b=document.createElement('button');b.className='s p';b.textContent='Chạy';b.onclick=()=>runv('RUN '+x[0]);r.appendChild(b);d.appendChild(r)})}
async function runv(c){const o=$('vout');o.style.display='block';o.textContent='Đang chạy…';const s0=P.view||0;const x=await cmd(c,1);if(x.startsWith('ERR')){o.textContent=x;return}
 for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,500));const v=await (await F('/api/view')).json();if(v.seq!==s0){o.textContent=(v.title?'$ '+v.title+'\n':'')+v.text;return}}o.textContent='(chưa có kết quả)'}
function man(){const q=$('mq').value.trim();if(q)runv('MAN '+q)}
let cd;function cheatDeb(){clearTimeout(cd);cd=setTimeout(cheat,250)}
async function cheat(){const q=$('cq').value;const j=await (await F('/api/cheat?q='+U(q))).json();const d=$('ch');d.innerHTML='';
 j.forEach(x=>{const r=document.createElement('div');r.style.flexWrap='wrap';r.innerHTML='<span><b></b> <small style="color:var(--dim)"></small><br><code></code></span>';const s=r.firstChild;s.querySelector('b').textContent=x[0];s.querySelector('small').textContent=x[1];s.querySelector('code').textContent=x[2];
 const b=document.createElement('button');b.className='s';b.textContent='Gõ lên PC';b.onclick=()=>{cmd('TYPEU '+U(x[2].split('  ')[0].replace(/^\$ /,'')),1).then(r=>toast(r.startsWith('ERR')?'PC chưa nối':'Đã gõ'))};r.appendChild(b);d.appendChild(r)})}
// ---- webhook ----
async function hkLoad(){const t=await (await F('/api/hooks')).text();$('hkt').value=t;const d=$('hk');d.innerHTML='';t.split('\n').filter(l=>l.indexOf('|')>0).forEach((l,i)=>{const r=document.createElement('div');r.innerHTML='<span></span>';r.firstChild.textContent=l.split('|')[0];const b=document.createElement('button');b.className='s p';b.textContent='Gọi';b.onclick=()=>cmd('HOOK '+i);r.appendChild(b);d.appendChild(r)})}
async function hkSave(){await F('/api/hooks',{method:'POST',body:$('hkt').value});toast('Đã lưu');hkLoad()}
// ---- cai dat ----
const SW=[['invert','Đảo màu OLED'],['flip','Xoay màn 180°'],['h24','Đồng hồ 24h'],['secs','Hiện giây'],['night','Ban đêm (23h–6h) tối nhất'],['abr','Tự chỉnh sáng theo LDR']];
const RN=['PC: CPU > 90%','PC: RAM > 90%','PC: pin < 20%','Điện thoại: pin < 15%','ESP nóng > 75°C','Mất kết nối PC'];
let swInit=0;
function sw(id,label,on,fn){const l=document.createElement('label');l.className='sw';l.innerHTML='<span></span><input type=checkbox><i></i>';l.firstChild.textContent=label;const c=l.querySelector('input');c.checked=on;c.onchange=()=>fn(c.checked);return l}
function renderSw(j){if(swInit)return;swInit=1;const a=$('sws');SW.forEach(s=>a.appendChild(sw(s[0],s[1],!!j.set[s[0]],v=>cmd('SET '+s[0]+' '+(v?1:0),1))));
 $('sbr').value=j.set.bright;$('smp').value=j.set.mspd;
 const r=$('rls');RN.forEach((n,i)=>r.appendChild(sw('r'+i,n,!!(j.rules&(1<<i)),v=>{P.rules=v?(P.rules|(1<<i)):(P.rules&~(1<<i));cmd('RULES '+P.rules,1)})))}
function alarmx(){}
function wxIcon(c){if(c===0)return '☀️';if(c<=2)return '🌤️';if(c===3)return '☁️';if(c===45||c===48)return '🌫️';if(c>=95)return '⛈️';if((c>=71&&c<=77)||(c>=85&&c<=86))return '❄️';if((c>=51&&c<=67)||(c>=80&&c<=82))return '🌧️';return '☁️'}
function wxText(c){if(c===0)return 'Trời quang';if(c<=2)return 'Ít mây';if(c===3)return 'Nhiều mây';if(c===45||c===48)return 'Sương mù';if(c>=51&&c<=57)return 'Mưa phùn';if(c>=61&&c<=67)return 'Mưa';if(c>=71&&c<=77)return 'Tuyết';if(c>=80&&c<=82)return 'Mưa rào';if(c>=95)return 'Dông bão';return 'Thời tiết'}
function geo(){const a=Number($('lat').value),b=Number($('lon').value);if(!Number.isFinite(a)||!Number.isFinite(b)||a<-90||a>90||b<-180||b>180){toast('Tọa độ không hợp lệ');return}cmd('GEO '+a+' '+b).then(()=>setTimeout(wx,3000))}
function wx(){F('/api/weather').then(r=>r.json()).then(w=>{$('wt').textContent=w.ok?Math.round(w.t)+'°':'--°';$('wc').textContent=w.ok?wxText(w.code):(w.busy?'Đang cập nhật…':'Chưa có dữ liệu');$('wi').textContent=wxIcon(w.code);$('wa').textContent=w.ok?'Cảm nhận '+Math.round(w.feels)+'°C':'Cần WiFi có Internet';$('wh').textContent=w.ok?w.hum+'%':'--';$('ww').textContent=w.ok?Math.round(w.wind)+' km/h':'--';$('wu').textContent=w.ok?w.age+' phút trước':'';if(!$('lat').value)$('lat').value=w.lat;if(!$('lon').value)$('lon').value=w.lon}).catch(()=>{})}
// ---- pin dien thoai + tim dien thoai ----
let bat=null;
async function phSend(){let b=-1,c=0;try{if(!bat&&navigator.getBattery)bat=await navigator.getBattery();if(bat){b=Math.round(bat.level*100);c=bat.charging?1:0;$('mb').textContent=b+'%'+(c?' ⚡':'')}else $('mb').textContent='không hỗ trợ'}catch(e){}
 if(b>=0)cmd('PHN bat='+b+' chg='+c+' name='+S((navigator.userAgentData&&navigator.userAgentData.platform)||'Dien_thoai').replace(/ /g,'_'),1)}
let fa=null,ft=0;
function findStart(){$('find').style.display='flex';if(navigator.vibrate)navigator.vibrate([400,200,400,200,400]);try{fa=fa||new (window.AudioContext||window.webkitAudioContext)();const o=fa.createOscillator(),g=fa.createGain();o.connect(g);g.connect(fa.destination);o.type='square';o.frequency.value=880;g.gain.value=.25;o.start();
 let n=0;ft=setInterval(()=>{o.frequency.value=n++%2?880:1320;if(navigator.vibrate)navigator.vibrate(300)},350);window._fo=o}catch(e){}setTimeout(findStop,40000)}
function findStop(){$('find').style.display='none';clearInterval(ft);try{window._fo&&window._fo.stop()}catch(e){}window._fo=null;cmd('FIND off',1)}
document.addEventListener('touchstart',()=>{try{fa=fa||new (window.AudioContext||window.webkitAudioContext)()}catch(e){}},{once:true});
// ---- khoi dong ----
try{if(localStorage.tab)tab(localStorage.tab)}catch(e){}
poll();wx();ls();phSend();setInterval(poll,2000);setInterval(wx,120000);setInterval(phSend,30000);
</script></body></html>)HTML";
