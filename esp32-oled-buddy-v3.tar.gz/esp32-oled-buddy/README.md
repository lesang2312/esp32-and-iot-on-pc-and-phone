# ESP32 OLED Buddy v3 — màn phụ + điều khiển PC + trợ lý Linux

ESP32 + OLED SSD1306 128x64 (I2C) + 2 nút. PlatformIO. Bản này biến nó thành một "thiết bị phụ" nối sâu với **máy tính (qua USB)** và **điện thoại (qua WiFi)**.

## Nối dây
| Linh kiện | Chân |
|---|---|
| OLED SDA / SCL / VCC / GND | D21 / D22 / 3V3 / GND |
| Nút A | D4 và GND |
| Nút B | D18 và GND |
| Còi (tuỳ chọn) | `PIN_BUZZ` trong `src/config.h` |
| Quang trở LDR (tuỳ chọn, tự chỉnh sáng) | `PIN_LDR` = chân ADC1 (34/35/36/39), cầu chia áp với 10k |
| Đo pin Li-ion (tuỳ chọn) | `PIN_VBAT` = chân ADC1, 2 điện trở bằng nhau |
| Cảm biến AHT20 hoặc BMP280/BME280 (tuỳ chọn) | cắm chung SDA/SCL, tự nhận |

## Nạp
    pio run -t upload
**Đóng `pio device monitor` và tắt/nhả cổng của buddyd trước khi nạp** (shell: tab 🎛 PC → "Nhả cổng USB", hoặc `buddy.py daemon pause`).

## Nút bấm
| Thao tác | Việc |
|---|---|
| A bấm | LÊN | B bấm | XUỐNG |
| A giữ ~0,6s | CHỌN | B giữ ~0,6s | QUAY LẠI |
| Màn chuột, soạn chữ, game | sự kiện tức thì khi bấm; thoát bằng giữ B (soạn/game) hoặc **giữ cả hai nút 0,7s** (chuột) |

## Menu mới
**Màn hình phụ PC** (4 trang, LÊN/XUỐNG đổi trang): CPU+RAM có đồ thị, mạng ↓↑ có đồ thị, pin/âm lượng/độ sáng, nhạc đang phát + cửa sổ đang mở. OK = phát/dừng nhạc hoặc tắt tiếng. Màn hình không tự tắt khi đang nối PC.
**Điều khiển PC >** Chuột USB · Gõ bàn phím · Trình chiếu/nhạc · Phím tắt (28 mục) · Chạy lệnh PC · Khóa máy · Clipboard điện thoại→PC · Webhook nhà thông minh.
**Lệnh Linux >** Tra lệnh (≈190 lệnh, tìm theo tên/mô tả, **chạy ngay trên ESP32 không cần PC**) · Meo ngẫu nhiên · Hỏi PC `man`/`tldr` · Chạy lệnh PC.
**Điện thoại** pin điện thoại, clipboard, nút "Tìm điện thoại" (trang web kêu + rung).
**Soạn văn bản** bàn phím 2 nút: A chạy vòng ký tự (giữ A = chạy nhanh), B chọn; vòng có `<-` xóa và đổi bảng (abc / ABC / số / ký hiệu / từ hay dùng như `sudo `, `git `). Giữ B: hoàn tác ký tự vừa chọn + mở menu: Lưu ghi chú · Lưu file .txt · Gõ lên PC · Clipboard PC. Dùng chung để nhập từ khóa, mật khẩu WiFi.
**Cảm biến** nhiệt độ chip / AHT20 / BMP280 + đồ thị 30 phút, LDR, pin. **Cảnh báo & auto**: CPU>90%, RAM>90%, pin PC<20%, pin điện thoại<15%, ESP nóng, mất kết nối PC; tự chỉnh sáng theo LDR; ban đêm 23h–6h tối nhất; tốc độ chuột.
**Mạng & BT**: Quét WiFi (chọn mạng + nhập mật khẩu ngay trên thiết bị), PIN trang web.

### Chuột USB
Mũi tên tự xoay vòng; **giữ B để đi theo hướng mũi tên** (giữ lâu thì nhanh dần). A đổi công cụ: Đi · Trái · Phải · Cuộn↓ · Cuộn↑ · Kéo (giữ chuột trái) · Thoát. Cần `buddyd.py` đang chạy.

## Trang web trên điện thoại — `http://buddy.local` (hoặc IP)
Lần đầu hỏi **PIN** (xem trên OLED: Menu › Mạng & BT › PIN trang web; mặc định ngẫu nhiên 4 số mỗi thiết bị). Sai 6 lần bị khóa 1 phút.
5 tab: **Tổng quan** (vòng CPU/RAM/pin/âm, nhạc, thời tiết, cảm biến) · **Điều khiển** (touchpad: chạm = trái, 2 ngón chạm = phải, 2 ngón kéo = cuộn; bàn phím tiếng Việt có dấu gõ thẳng lên PC; trình chiếu; âm lượng/sáng) · **Soạn** (ghi chú, gửi file lên ESP32 hoặc nút **📤 Gửi lên PC**, ảnh nền OLED chuyển sẵn trên trình duyệt) · **Lệnh** (lệnh PC, tra cứu lệnh Linux + "Gõ lên PC", man/tldr, webhook) · **Cài đặt**.
Điện thoại tự báo pin cho ESP32 mỗi 30 giây (Chrome Android; iPhone không hỗ trợ API này).

## Phía máy tính
    python3 tools/buddyd.py           # chạy nền; shell Quickshell tự quản lý (tab 🎛 PC)
- Đẩy CPU/RAM/swap/nhiệt/đĩa/pin/độ sáng/âm lượng/mạng/nhạc/cửa sổ mỗi 2 giây; đồng bộ giờ, Pomodoro, việc cần làm.
- **Chuột/phím**: ưu tiên `/dev/uinput` (mượt):
      echo 'KERNEL=="uinput", GROUP="input", MODE="0660"' | sudo tee /etc/udev/rules.d/99-uinput.rules
      echo uinput | sudo tee /etc/modules-load.d/uinput.conf; sudo usermod -aG input $USER   # rồi đăng nhập lại
  Không có thì dùng `wlrctl` (chuột Wayland), `wtype` (phím/chữ, có dấu), `xdotool` (X11), `ydotool`.
- **Lệnh PC chỉ chạy lệnh trong danh sách**: mặc định chỉ lệnh đọc (uname, free, df, ip, top, sensors, journal…). Thêm lệnh của bạn: sao chép `tools/buddy-commands.example.json` → `~/.config/quickshell/study/buddy-commands.json`. Không chạy qua shell.
- `man`/`tldr` tra trên PC, kết quả hiện trên OLED (bỏ dấu, ≤ 6000 ký tự).
- Hành động nhanh: âm lượng (wpctl/pactl), nhạc (playerctl), độ sáng (brightnessctl), khóa máy, chụp màn hình (grim).
- Tự thoát khi shell đóng (stdin), khi SIGTERM, hoặc sau 90s không thấy ESP32 (`--idle-exit`). `buddy.py` tự dùng chung cổng qua `$XDG_RUNTIME_DIR/buddyd-<uid>.sock`.

## buddy.py (dòng lệnh)
`buddy.py help`. Mới: `mouse dx dy`, `click l|r|m|d`, `scroll n`, `key ctrl+c`, `type chữ`, `act vol +5|mute|playpause|lock|shot`, `cmds`, `run <id>`, `man <lệnh>`, `cheat <từ khóa>`, `set bright 3`, `hooks`, `hook 0`, `find`, `pin`, `daemon status|stop|pause|resume`.

## Webhook
Thêm trên trang web (tab Lệnh) hoặc ghi `/hooks.txt` trong ESP32: mỗi dòng `tên|http://địa-chỉ`. Menu › Điều khiển PC › Webhook nhà: OK để gọi (GET). HTTPS không kiểm tra chứng chỉ — chỉ dùng với dịch vụ nhà/ LAN.

## Bảo mật (đọc kỹ)
- Trang web điều khiển cả PC nên **bắt buộc PIN**. Đừng để PIN rỗng. Đổi PIN: `buddy.py pin 123456` / `pin new` / `pin off`.
- Lệnh `HELLO/PCS2/VIEW*/PIN` chỉ nhận qua cáp USB, không nhận từ WiFi.
- Chữ gõ lên PC gõ vào cửa sổ đang focus: cẩn thận khi đang mở terminal.
- ESP32 chỉ gửi *yêu cầu*; daemon mới là chỗ quyết định cái gì được chạy (danh sách cho phép ở phía PC).

## Giới hạn đã biết
- OLED chỉ hiện ASCII: chữ tiếng Việt bị bỏ dấu (riêng gõ từ điện thoại lên PC giữ nguyên dấu).
- Bluetooth tắt mặc định (`-DENABLE_BT=0`) vì làm đầy flash.
- Firmware mới chỉ được kiểm tra cú pháp + chạy thử logic với giả lập; **chưa build bằng PlatformIO thật hay thử trên board** — nếu `pio run` báo lỗi, gửi nguyên văn lỗi để sửa.
