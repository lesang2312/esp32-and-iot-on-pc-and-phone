#!/usr/bin/env python3
"""buddyd - chương trình nền nối ESP32 OLED Buddy với máy tính Linux (chỉ dùng thư viện chuẩn Python 3).

Nó giữ cổng USB và làm các việc sau:
  * đẩy thông số máy (CPU, RAM, pin, âm lượng, độ sáng, mạng, nhạc, cửa sổ…) sang màn OLED mỗi 2 giây
  * nhận từ ESP32: di chuột, bấm chuột, cuộn, gõ phím / chữ, chép clipboard, chạy lệnh trong danh sách cho phép,
    tra man/tldr, các hành động (âm lượng, nhạc, độ sáng, khóa máy, chụp màn hình)
  * mở ổ cắm Unix ($XDG_RUNTIME_DIR/buddyd.sock) để buddy.py dùng chung cổng USB

Cách chạy:  buddyd.py            (chạy nền, in sự kiện JSON ra stdout để shell đọc)
            buddyd.py --idle-exit 90   thoát nếu 90 giây không thấy ESP32 (shell sẽ khởi động lại khi cắm lại)
            BUDDY_BACKEND=dry buddyd.py   chỉ ghi nhật ký, không điều khiển thật (thử nghiệm)
Tự thoát khi: stdin bị đóng (shell tắt), nhận SIGTERM/SIGINT, hoặc lệnh `quit` trên stdin.
Lệnh trên stdin:  quit | pause | resume | pomo <trạng thái> <còn lại> <hôm nay> | share <url> | msg <chữ> | note <chữ>

Chuột/phím: ưu tiên /dev/uinput (mượt, cần quyền - xem README), sau đó wlrctl / ydotool / xdotool (chuột),
            wtype / xdotool / uinput (phím và chữ; chữ có dấu cần wtype hoặc xdotool).
Lệnh PC: chỉ chạy các lệnh khai trong ~/.config/quickshell/study/buddy-commands.json (mặc định chỉ các lệnh đọc).
"""
import argparse
import glob
import hashlib
import json
import os
import queue
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import termios
import threading
import time
import tty
import unicodedata
import select
import fcntl
from urllib.parse import unquote

HOME = os.path.expanduser("~")
CONF_DIR = os.path.join(HOME, ".config/quickshell/study")
CACHE_DIR = os.path.join(HOME, ".cache/qs-study")
CMD_FILE = os.path.join(CONF_DIR, "buddy-commands.json")
TODO_JSON = os.path.join(CONF_DIR, "todo.json")
SHARE_URL_FILE = os.path.join(CACHE_DIR, "buddy-share.url")
HOST_FILE = os.path.join(CONF_DIR, "buddy.host")
SOCK = os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", "buddyd-%d.sock" % os.getuid())
BACKEND = os.environ.get("BUDDY_BACKEND", "auto").lower()
VERSION = "3.0"

# Lệnh mặc định: chỉ đọc thông tin, không thay đổi hệ thống
DEFAULT_COMMANDS = {
    "uname":   {"name": "Thong tin he thong", "cmd": ["uname", "-a"]},
    "uptime":  {"name": "Uptime", "cmd": ["uptime"]},
    "free":    {"name": "RAM (free -h)", "cmd": ["free", "-h"]},
    "df":      {"name": "O dia (df -h)", "cmd": ["df", "-h", "-x", "tmpfs", "-x", "devtmpfs"], "lines": 14},
    "ip":      {"name": "Dia chi IP", "cmd": ["ip", "-br", "addr"]},
    "topcpu":  {"name": "Top CPU", "cmd": ["ps", "-eo", "pid,pcpu,pmem,comm", "--sort=-pcpu"], "lines": 12},
    "topmem":  {"name": "Top RAM", "cmd": ["ps", "-eo", "pid,pcpu,pmem,comm", "--sort=-pmem"], "lines": 12},
    "sensors": {"name": "Nhiet do (sensors)", "cmd": ["sensors"], "lines": 24},
    "lsblk":   {"name": "Cac o dia (lsblk)", "cmd": ["lsblk", "-o", "NAME,SIZE,TYPE,MOUNTPOINT"], "lines": 16},
    "ports":   {"name": "Cong dang mo (ss)", "cmd": ["ss", "-tulpn"], "lines": 20},
    "errors":  {"name": "Loi he thong (journal)", "cmd": ["journalctl", "-p", "err", "-b", "--no-pager", "-n", "20"], "lines": 22},
    "updates": {"name": "Goi can cap nhat", "cmd": ["checkupdates"], "lines": 20},
    "wifi":    {"name": "WiFi (nmcli)", "cmd": ["nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL", "dev", "wifi"], "lines": 12},
    "usb":     {"name": "Thiet bi USB", "cmd": ["lsusb"], "lines": 14},
    "date":    {"name": "Ngay gio", "cmd": ["date", "+%A %d/%m/%Y %H:%M:%S"]},
}

NO_ACCENT = {"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-", "…": "...", "•": "*", " ": " "}


def strip_accents(s):
    for k, v in NO_ACCENT.items():
        s = s.replace(k, v)
    s = s.replace("đ", "d").replace("Đ", "D")
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c))


def ascii_line(s, n=None):
    s = "".join(c if 32 <= ord(c) < 127 else " " for c in strip_accents(s)).strip()
    return s[:n] if n else s


def ascii_text(s):
    s = strip_accents(s.replace("\r\n", "\n").replace("\r", "\n"))
    s = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", s)       # mã màu terminal
    s = re.sub(r".\x08", "", s)                          # định dạng đậm của man (a\bb)
    out = []
    for c in s:
        if c == "\n":
            out.append(c)
        elif c == "\t":
            out.append("  ")
        elif 32 <= ord(c) < 127:
            out.append(c)
        elif ord(c) >= 128:
            out.append("?")
    return "".join(out)


class Out:
    """Sự kiện JSON (mỗi dòng 1 sự kiện) cho shell đọc."""
    lock = threading.Lock()

    @classmethod
    def ev(cls, **kw):
        with cls.lock:
            try:
                sys.stdout.write(json.dumps(kw, ensure_ascii=False) + "\n")
                sys.stdout.flush()
            except (BrokenPipeError, OSError, ValueError):
                pass


def log(*a):
    sys.stderr.write(" ".join(str(x) for x in a) + "\n")
    sys.stderr.flush()


def run(cmd, timeout=3, inp=None):
    try:
        r = subprocess.run(cmd, input=inp, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout
    except (OSError, subprocess.SubprocessError):
        return 1, ""


# =====================================================================  cổng serial
def find_port():
    p = os.environ.get("BUDDY_PORT")
    if p:
        return p if os.path.exists(p) else None
    for pat in ("/dev/serial/by-id/*", "/dev/ttyUSB*", "/dev/ttyACM*"):
        found = sorted(glob.glob(pat))
        if found:
            return found[0]
    return None


class Port:
    def __init__(self, path, on_event):
        self.path = path
        self.on_event = on_event
        self.fd = os.open(path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        tty.setraw(self.fd)
        a = termios.tcgetattr(self.fd)
        a[2] = (a[2] | termios.CLOCAL | termios.CREAD) & ~termios.HUPCL
        a[4] = a[5] = termios.B115200
        termios.tcsetattr(self.fd, termios.TCSANOW, a)
        self.buf = b""
        self.replies = queue.Queue()
        self.cmd_lock = threading.RLock()
        self.dead = False
        self.t = threading.Thread(target=self._reader, daemon=True)
        self.t.start()

    def _reader(self):
        while not self.dead:
            try:
                r, _, _ = select.select([self.fd], [], [], 0.5)
                if not r:
                    continue
                chunk = os.read(self.fd, 4096)
                if not chunk:
                    self.dead = True
                    break
            except BlockingIOError:
                continue
            except OSError:
                self.dead = True
                break
            self.buf += chunk
            while True:
                i = self.buf.find(b"\n")
                if i < 0:
                    break
                line, self.buf = self.buf[:i], self.buf[i + 1:]
                s = line.decode("ascii", "ignore").strip()
                if not s:
                    continue
                if s.startswith("@"):
                    try:
                        self.on_event(s[1:])
                    except Exception as e:           # lỗi xử lý sự kiện không được làm chết luồng đọc
                        log("event error:", e)
                else:
                    self.replies.put(s)
            if len(self.buf) > 20000:
                self.buf = b""

    def write(self, data):
        view = memoryview(data)
        while view:
            try:
                _, w, _ = select.select([], [self.fd], [], 2)
                if not w:
                    self.dead = True
                    return False
                n = os.write(self.fd, view[:256])
            except BlockingIOError:
                continue
            except OSError:
                self.dead = True
                return False
            view = view[n:]
            time.sleep(0.003)
        return True

    def command(self, line, until=None, timeout=6, reply=True):
        with self.cmd_lock:
            while not self.replies.empty():
                try:
                    self.replies.get_nowait()
                except queue.Empty:
                    break
            if not self.write(line.encode("ascii", "ignore") + b"\n"):
                return []
            if not reply:
                return []
            out, end = [], time.time() + timeout
            while time.time() < end and not self.dead:
                try:
                    l = self.replies.get(timeout=0.3)
                except queue.Empty:
                    continue
                out.append(l)
                if until is not None:
                    if l == until:
                        break
                elif l.startswith(("OK", "ERR")) or l == "PONG":
                    break
            return out

    def close(self):
        self.dead = True
        try:
            os.close(self.fd)
        except OSError:
            pass


# =====================================================================  số liệu máy tính
class Stats:
    def __init__(self):
        self.cur = {}
        self.prev_cpu = None
        self.prev_net = None
        self.prev_t = None
        self.has = {k: shutil.which(k) for k in ("wpctl", "pactl", "playerctl", "hyprctl", "brightnessctl")}
        self.hwmon = self._find_temp()
        self.bat = (glob.glob("/sys/class/power_supply/BAT*") or [None])[0]
        self.bl = (glob.glob("/sys/class/backlight/*") or [None])[0]

    @staticmethod
    def _read(path, default=""):
        try:
            with open(path) as f:
                return f.read().strip()
        except OSError:
            return default

    def _find_temp(self):
        best = None
        for d in sorted(glob.glob("/sys/class/hwmon/hwmon*")):
            n = self._read(d + "/name")
            if n in ("k10temp", "coretemp", "zenpower", "cpu_thermal", "acpitz") and os.path.exists(d + "/temp1_input"):
                if n in ("k10temp", "coretemp", "zenpower"):
                    return d + "/temp1_input"
                best = best or d + "/temp1_input"
        return best or ("/sys/class/thermal/thermal_zone0/temp" if os.path.exists("/sys/class/thermal/thermal_zone0/temp") else None)

    def collect(self):
        d = {}
        now = time.time()
        # CPU
        try:
            p = [int(x) for x in self._read("/proc/stat").splitlines()[0].split()[1:9]]
            idle, total = p[3] + p[4], sum(p)
            if self.prev_cpu:
                di, dt = idle - self.prev_cpu[0], total - self.prev_cpu[1]
                d["cpu"] = max(0, min(100, round(100 * (1 - di / dt)))) if dt > 0 else 0
            self.prev_cpu = (idle, total)
        except (ValueError, IndexError):
            pass
        # RAM / swap
        mi = {}
        for l in self._read("/proc/meminfo").splitlines():
            k, _, v = l.partition(":")
            try:
                mi[k] = int(v.split()[0])
            except (ValueError, IndexError):
                pass
        if mi.get("MemTotal"):
            d["mem"] = round(100 * (1 - mi.get("MemAvailable", 0) / mi["MemTotal"]))
        if mi.get("SwapTotal"):
            d["swap"] = round(100 * (1 - mi.get("SwapFree", 0) / mi["SwapTotal"]))
        else:
            d["swap"] = 0
        # nhiệt độ
        if self.hwmon:
            try:
                v = int(self._read(self.hwmon))
                d["temp"] = round(v / 1000)
            except ValueError:
                pass
        # đĩa
        try:
            u = shutil.disk_usage("/")
            d["disk"] = round(100 * u.used / u.total)
        except OSError:
            pass
        # pin
        if self.bat:
            try:
                d["bat"] = int(self._read(self.bat + "/capacity"))
                d["chg"] = 1 if self._read(self.bat + "/status") in ("Charging", "Full") else 0
            except ValueError:
                pass
        # độ sáng
        if self.bl:
            try:
                d["bri"] = round(100 * int(self._read(self.bl + "/brightness")) / max(1, int(self._read(self.bl + "/max_brightness"))))
            except ValueError:
                pass
        # âm lượng
        if self.has["wpctl"]:
            rc, o = run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"])
            m = re.search(r"([0-9.]+)", o)
            if rc == 0 and m:
                d["vol"] = round(float(m.group(1)) * 100)
                d["mute"] = 1 if "MUTED" in o else 0
        elif self.has["pactl"]:
            rc, o = run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"])
            m = re.search(r"(\d+)%", o)
            if rc == 0 and m:
                d["vol"] = int(m.group(1))
                rc, o = run(["pactl", "get-sink-mute", "@DEFAULT_SINK@"])
                d["mute"] = 1 if "yes" in o else 0
        # mạng KB/s
        try:
            rx = tx = 0
            for l in self._read("/proc/net/dev").splitlines()[2:]:
                name, _, rest = l.partition(":")
                if name.strip() == "lo":
                    continue
                f = rest.split()
                rx += int(f[0])
                tx += int(f[8])
            if self.prev_net and self.prev_t:
                dt = max(0.2, now - self.prev_t)
                d["rx"] = max(0, round((rx - self.prev_net[0]) / 1024 / dt))
                d["tx"] = max(0, round((tx - self.prev_net[1]) / 1024 / dt))
            self.prev_net = (rx, tx)
        except (ValueError, IndexError):
            pass
        self.prev_t = now
        try:
            d["up"] = int(float(self._read("/proc/uptime").split()[0]))
            d["load"] = round(float(self._read("/proc/loadavg").split()[0]) * 10)
        except (ValueError, IndexError):
            pass
        # cửa sổ đang mở + workspace (Hyprland)
        if self.has["hyprctl"] and os.environ.get("HYPRLAND_INSTANCE_SIGNATURE"):
            rc, o = run(["hyprctl", "activewindow", "-j"])
            if rc == 0 and o.strip():
                try:
                    j = json.loads(o)
                    d["win"] = ascii_line(j.get("class") or j.get("title") or "", 40)
                    d["ws"] = str((j.get("workspace") or {}).get("id", ""))
                except ValueError:
                    pass
        # nhạc
        if self.has["playerctl"]:
            rc, o = run(["playerctl", "status"])
            st = o.strip() if rc == 0 else ""
            d["mstat"] = ascii_line(st, 12)
            if st:
                rc, o = run(["playerctl", "metadata", "--format", "{{artist}} - {{title}}"])
                t = ascii_line(o, 60) if rc == 0 else ""
                d["media"] = t.strip(" -")
        self.cur = d
        return d

    def line(self, share=""):
        parts = []
        for k, v in self.cur.items():
            parts.append("%s=%s" % (k, str(v).replace("\t", " ").replace("\n", " ")))
        if share:
            parts.append("share=" + ascii_line(share, 60))
        return "PCS2 " + "\t".join(parts)


# =====================================================================  điều khiển chuột / phím
KEYMAP = {"escape": 1, "esc": 1, "return": 28, "enter": 28, "backspace": 14, "tab": 15, "space": 57, "left": 105, "right": 106,
          "up": 103, "down": 108, "home": 102, "end": 107, "prior": 104, "pageup": 104, "page_up": 104, "next": 109, "pagedown": 109,
          "page_down": 109, "delete": 111, "insert": 110, "super": 125, "win": 125, "logo": 125, "ctrl": 29, "control": 29, "alt": 56,
          "shift": 42, "minus": 12, "equal": 13, "comma": 51, "period": 52, "slash": 53, "print": 99}
for _i, _c in enumerate("qwertyuiop"):
    KEYMAP[_c] = 16 + _i
for _i, _c in enumerate("asdfghjkl"):
    KEYMAP[_c] = 30 + _i
for _i, _c in enumerate("zxcvbnm"):
    KEYMAP[_c] = 44 + _i
for _i, _c in enumerate("1234567890"):
    KEYMAP[_c] = 2 + _i
for _i in range(1, 11):
    KEYMAP["f%d" % _i] = 58 + _i
KEYMAP["f11"], KEYMAP["f12"] = 87, 88
MODS = {"ctrl": "ctrl", "control": "ctrl", "alt": "alt", "shift": "shift", "super": "super", "win": "super", "logo": "super", "meta": "alt"}
_US = [("`1234567890-=", 41), ("qwertyuiop[]\\", 16), ("asdfghjkl;'", 30), ("zxcvbnm,./", 44)]
_US_SH = ["~!@#$%^&*()_+", "QWERTYUIOP{}|", "ASDFGHJKL:\"", "ZXCVBNM<>?"]
ASCII_KEYS = {" ": (57, False), "\n": (28, False), "\t": (15, False)}
for (row, base), srow in zip(_US, _US_SH):
    for i, ch in enumerate(row):
        ASCII_KEYS[ch] = (base + i, False)
        ASCII_KEYS[srow[i]] = (base + i, True)

REL_X, REL_Y, REL_WHEEL = 0, 1, 8
BTN = {"l": 0x110, "r": 0x111, "m": 0x112}


class Uinput:
    """Thiết bị chuột + bàn phím ảo qua /dev/uinput (không cần thư viện ngoài)."""

    def __init__(self):
        self.fd = os.open("/dev/uinput", os.O_WRONLY | os.O_NONBLOCK)
        io = lambda n, v: fcntl.ioctl(self.fd, n, v)
        UI_SET_EVBIT, UI_SET_KEYBIT, UI_SET_RELBIT = 0x40045564, 0x40045565, 0x40045566
        io(UI_SET_EVBIT, 1)
        io(UI_SET_EVBIT, 2)
        io(UI_SET_EVBIT, 0)
        for c in range(1, 249):
            io(UI_SET_KEYBIT, c)
        for c in (0x110, 0x111, 0x112):
            io(UI_SET_KEYBIT, c)
        for r in (REL_X, REL_Y, REL_WHEEL):
            io(UI_SET_RELBIT, r)
        setup = struct.pack("<HHHH80sI", 0x03, 0x1209, 0xB0DD, 1, b"ESP32 Buddy virtual input", 0)
        fcntl.ioctl(self.fd, 0x405C5503, setup)
        fcntl.ioctl(self.fd, 0x5501)
        time.sleep(0.15)

    def _ev(self, t, c, v):
        os.write(self.fd, struct.pack("@llHHi", 0, 0, t, c, v))

    def _syn(self):
        self._ev(0, 0, 0)

    def move(self, dx, dy):
        if dx:
            self._ev(2, REL_X, dx)
        if dy:
            self._ev(2, REL_Y, dy)
        self._syn()

    def button(self, b, down):
        self._ev(1, BTN[b], 1 if down else 0)
        self._syn()

    def wheel(self, n):
        self._ev(2, REL_WHEEL, -n)                     # n dương = cuộn xuống; REL_WHEEL dương = cuộn lên
        self._syn()

    def key(self, code, down):
        self._ev(1, code, 1 if down else 0)
        self._syn()

    def combo(self, spec):
        codes = []
        for part in spec.split("+"):
            c = KEYMAP.get(part.lower())
            if c is None:
                return False
            codes.append(c)
        for c in codes:
            self.key(c, True)
            time.sleep(0.004)
        for c in reversed(codes):
            self.key(c, False)
            time.sleep(0.004)
        return True

    def text(self, s):
        for ch in s:
            k = ASCII_KEYS.get(ch)
            if not k:
                continue
            if k[1]:
                self.key(42, True)
            self.key(k[0], True)
            self.key(k[0], False)
            if k[1]:
                self.key(42, False)
            time.sleep(0.003)

    def close(self):
        try:
            fcntl.ioctl(self.fd, 0x5502)
            os.close(self.fd)
        except OSError:
            pass


class Injector:
    """Chọn công cụ có sẵn cho từng việc; ở chế độ dry chỉ ghi nhật ký."""

    def __init__(self):
        self.dry = BACKEND == "dry"
        self.has = {k: shutil.which(k) for k in ("wlrctl", "ydotool", "xdotool", "wtype", "wl-copy", "xclip", "xsel", "grim", "hyprctl",
                                                 "loginctl", "playerctl", "wpctl", "pactl", "brightnessctl", "notify-send", "man", "tldr")}
        self.uin = None
        self.wayland = bool(os.environ.get("WAYLAND_DISPLAY"))
        if not self.dry and BACKEND in ("auto", "uinput") and os.access("/dev/uinput", os.W_OK):
            try:
                self.uin = Uinput()
            except OSError as e:
                log("uinput không dùng được:", e)
        self.ptr = "dry" if self.dry else ("uinput" if self.uin else next((t for t in ("wlrctl", "ydotool", "xdotool") if self.has[t]), None))
        keys_order = ("wtype", "xdotool") if self.wayland else ("xdotool", "wtype")
        self.kbd = "dry" if self.dry else next((t for t in keys_order if self.has[t]), "uinput" if self.uin else ("ydotool" if self.has["ydotool"] else None))
        if self.kbd == "wtype" and not self.wayland:
            self.kbd = "uinput" if self.uin else self.kbd
        self.clip = "dry" if self.dry else next((t for t in ("wl-copy", "xclip", "xsel") if self.has[t]), None)
        self.mdx = self.mdy = 0
        self.last_flush = 0

    def describe(self):
        return {"pointer": self.ptr, "keys": self.kbd, "clipboard": self.clip}

    def _x(self, cmd):
        if self.dry:
            Out.ev(ev="inject", cmd=cmd)
            return
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, start_new_session=True)
        except OSError:
            pass

    # ---- chuột ----
    def move(self, dx, dy):
        self.mdx += dx
        self.mdy += dy

    def flush_move(self):
        dx, dy, self.mdx, self.mdy = self.mdx, self.mdy, 0, 0
        if not (dx or dy):
            return
        if self.ptr == "dry":
            Out.ev(ev="inject", what="move", dx=dx, dy=dy)
        elif self.ptr == "uinput":
            self.uin.move(dx, dy)
        elif self.ptr == "wlrctl":
            self._x(["wlrctl", "pointer", "move", str(dx), str(dy)])
        elif self.ptr == "ydotool":
            self._x(["ydotool", "mousemove", "-x", str(dx), "-y", str(dy)])
        elif self.ptr == "xdotool":
            self._x(["xdotool", "mousemove_relative", "--", str(dx), str(dy)])

    def click(self, b):
        self.flush_move()
        name = {"l": "left", "r": "right", "m": "middle"}
        if b == "d":
            self.click("l")
            time.sleep(0.06)
            self.click("l")
            return
        if b in ("ld", "lu"):
            down = b == "ld"
            if self.ptr == "dry":
                Out.ev(ev="inject", what="button", btn="l", down=down)
            elif self.ptr == "uinput":
                self.uin.button("l", down)
            elif self.ptr == "ydotool":
                self._x(["ydotool", "click", "0x40" if down else "0x80"])
            elif self.ptr == "xdotool":
                self._x(["xdotool", "mousedown" if down else "mouseup", "1"])
            return
        if b not in name:
            return
        if self.ptr == "dry":
            Out.ev(ev="inject", what="click", btn=b)
        elif self.ptr == "uinput":
            self.uin.button(b, True)
            time.sleep(0.02)
            self.uin.button(b, False)
        elif self.ptr == "wlrctl":
            self._x(["wlrctl", "pointer", "click", name[b]])
        elif self.ptr == "ydotool":
            self._x(["ydotool", "click", {"l": "0xC0", "r": "0xC1", "m": "0xC2"}[b]])
        elif self.ptr == "xdotool":
            self._x(["xdotool", "click", {"l": "1", "m": "2", "r": "3"}[b]])

    def scroll(self, n):
        self.flush_move()
        if not n:
            return
        if self.ptr == "dry":
            Out.ev(ev="inject", what="scroll", n=n)
        elif self.ptr == "uinput":
            self.uin.wheel(n)
        elif self.ptr == "wlrctl":
            self._x(["wlrctl", "pointer", "scroll", str(n * 15), "0"])
        elif self.ptr == "ydotool":
            self._x(["ydotool", "mousemove", "-w", "--", "0", str(-n)])
        elif self.ptr == "xdotool":
            for _ in range(min(abs(n), 20)):
                self._x(["xdotool", "click", "5" if n > 0 else "4"])

    # ---- phím / chữ ----
    def key(self, spec):
        if not re.fullmatch(r"[A-Za-z0-9_+\-]{1,40}", spec):
            return
        parts = spec.split("+")
        if self.kbd == "dry":
            Out.ev(ev="inject", what="key", key=spec)
        elif self.kbd == "wtype":
            args = ["wtype"]
            mods = [MODS[p.lower()] for p in parts[:-1] if p.lower() in MODS]
            wm = {"ctrl": "ctrl", "alt": "alt", "shift": "shift", "super": "logo"}
            for m in mods:
                args += ["-M", wm[m]]
            last = parts[-1]
            if last.lower() in MODS and not mods:
                args += ["-P", wm[MODS[last.lower()]], "-p", wm[MODS[last.lower()]]]
            elif len(last) == 1:
                args += [last]
            else:
                args += ["-k", last]
            for m in reversed(mods):
                args += ["-m", wm[m]]
            self._x(args)
        elif self.kbd == "xdotool":
            self._x(["xdotool", "key", spec.replace("super", "Super_L")])
        elif self.kbd == "uinput":
            self.uin.combo(spec)
        elif self.kbd == "ydotool":
            codes = [KEYMAP.get(p.lower()) for p in parts]
            if all(codes):
                seq = ["%d:1" % c for c in codes] + ["%d:0" % c for c in reversed(codes)]
                self._x(["ydotool", "key"] + seq)

    def type_text(self, s):
        s = s[:400]
        if not s:
            return
        if self.kbd == "dry":
            Out.ev(ev="inject", what="type", text=s)
        elif self.kbd == "wtype":
            self._x(["wtype", "-d", "4", "--", s])
        elif self.kbd == "xdotool":
            self._x(["xdotool", "type", "--delay", "6", "--", s])
        elif self.kbd == "uinput":
            self.uin.text(strip_accents(s))
        elif self.kbd == "ydotool":
            self._x(["ydotool", "type", "--", strip_accents(s)])

    def copy(self, s):
        s = s[:2000]
        if self.clip == "dry":
            Out.ev(ev="inject", what="clip", text=s)
            return
        cmd = {"wl-copy": ["wl-copy"], "xclip": ["xclip", "-selection", "clipboard"], "xsel": ["xsel", "-b", "-i"]}.get(self.clip)
        if cmd:
            try:
                p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
                p.stdin.write(s.encode("utf-8"))
                p.stdin.close()
            except OSError:
                pass

    # ---- hành động nhanh ----
    def action(self, name, arg=""):
        arg = arg.strip()
        if self.dry:
            Out.ev(ev="inject", what="action", name=name, arg=arg)
            return
        m = re.fullmatch(r"([+-]?)(\d{1,3})", arg)
        step = int(m.group(2)) if m else 5
        sign = m.group(1) if m else "+"
        if name == "vol":
            if self.has["wpctl"]:
                self._x(["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", "%d%%%s" % (step, "-" if sign == "-" else "+")])
            elif self.has["pactl"]:
                self._x(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%s%d%%" % ("-" if sign == "-" else "+", step)])
        elif name == "mute":
            if self.has["wpctl"]:
                self._x(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"])
            elif self.has["pactl"]:
                self._x(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"])
        elif name in ("playpause", "next", "prev"):
            self._x(["playerctl", {"playpause": "play-pause", "next": "next", "prev": "previous"}[name]])
        elif name == "bri" and self.has["brightnessctl"]:
            self._x(["brightnessctl", "set", "%d%%%s" % (step, "-" if sign == "-" else "+")])
        elif name == "lock":
            self._x(["loginctl", "lock-session"])
        elif name == "dpms" and self.has["hyprctl"]:
            self._x(["hyprctl", "dispatch", "dpms", "off"])
        elif name == "shot" and self.has["grim"]:
            d = os.path.join(HOME, "Pictures/Screenshots")
            os.makedirs(d, exist_ok=True)
            f = os.path.join(d, time.strftime("buddy-%Y%m%d-%H%M%S.png"))
            self._x(["grim", f])
            if self.has["notify-send"]:
                self._x(["notify-send", "-a", "Buddy", "Da chup man hinh", f])

    def close(self):
        if self.uin:
            self.uin.close()


# =====================================================================  lệnh PC cho phép + tra cứu
def load_commands():
    cmds = dict(DEFAULT_COMMANDS)
    try:
        with open(CMD_FILE, encoding="utf-8") as f:
            user = json.load(f)
        if isinstance(user, dict):
            if user.pop("_replace_defaults", False):
                cmds = {}
            for k, v in user.items():
                if re.fullmatch(r"[A-Za-z0-9_-]{1,20}", k) and isinstance(v, dict) and isinstance(v.get("cmd"), list) and v["cmd"]:
                    cmds[k] = {"name": str(v.get("name", k))[:24], "cmd": [str(x) for x in v["cmd"]],
                               "lines": int(v.get("lines", 30)), "timeout": int(v.get("timeout", 8))}
    except (OSError, ValueError):
        pass
    return {k: v for k, v in cmds.items() if shutil.which(v["cmd"][0])}


def clip_lines(text, n):
    lines = text.splitlines()
    if len(lines) > n:
        lines = lines[:n] + ["... (con %d dong)" % (len(lines) - n)]
    return "\n".join(lines)


# =====================================================================  daemon
class Daemon:
    def __init__(self, args):
        self.args = args
        self.stop = threading.Event()
        self.paused = False
        self.port = None
        self.port_path = None
        self.inj = Injector()
        self.stats = Stats()
        self.cmds = load_commands()
        self.events = queue.Queue(maxsize=400)
        self.pomo = None
        self.share = ""
        self.todo_hash = None
        self.pending_msgs = queue.Queue()
        self.last_act_ev = 0
        self.state = "waiting"
        self.last_device = time.time()
        self.fw = ""

    # ---- gửi kết quả dài sang ESP32 ----
    def send_view(self, title, text):
        p = self.port
        if not p or p.dead:
            return
        text = ascii_text(text).strip("\n")
        if len(text) > 6000:
            text = text[:6000] + "\n..."
        text = text.replace("\n", "\x1f")
        p.command("VIEWB " + ascii_line(title, 14), reply=False)
        carry = ""
        for i in range(0, len(text), 300):
            chunk = carry + text[i:i + 300]
            stripped = chunk.rstrip(" ")
            carry = " " * (len(chunk) - len(stripped))
            if stripped:
                p.command("VIEWA " + stripped, reply=False)
            time.sleep(0.02)
        p.command("VIEWE", timeout=3)

    def send_cmds(self):
        if self.port and not self.port.dead:
            items = ";".join("%s:%s" % (k, ascii_line(v["name"], 24).replace(";", ",").replace(":", " ")) for k, v in self.cmds.items())
            self.port.command("CMDS " + items, timeout=3)

    # ---- xử lý sự kiện từ ESP32 (luồng worker) ----
    def on_event(self, line):
        try:
            self.events.put_nowait(line)
        except queue.Full:
            pass

    def worker(self):
        while not self.stop.is_set():
            try:
                line = self.events.get(timeout=0.02)
            except queue.Empty:
                self.inj.flush_move()
                continue
            try:
                self.handle(line)
            except Exception as e:
                log("handle error:", repr(e), line[:60])
            if self.events.empty() or time.time() - self.inj.last_flush > 0.008:
                self.inj.flush_move()
                self.inj.last_flush = time.time()

    def note_activity(self, kind):
        now = time.time()
        if now - self.last_act_ev > 1.0:
            self.last_act_ev = now
            Out.ev(ev="act", kind=kind)

    def handle(self, line):
        cmd, _, arg = line.partition(" ")
        if cmd == "M":
            try:
                dx, dy = (int(x) for x in arg.split()[:2])
            except ValueError:
                return
            self.inj.move(max(-200, min(200, dx)), max(-200, min(200, dy)))
            self.note_activity("mouse")
        elif cmd == "C":
            self.inj.click(arg.strip())
            self.note_activity("click")
        elif cmd == "S":
            try:
                self.inj.scroll(max(-50, min(50, int(arg))))
            except ValueError:
                pass
            self.note_activity("scroll")
        elif cmd == "K":
            self.inj.key(arg.strip())
            self.note_activity("key")
        elif cmd == "T":
            self.inj.type_text(arg)
            self.note_activity("type")
        elif cmd == "TU":
            self.inj.type_text(unquote(arg.strip())[:400])
            self.note_activity("type")
        elif cmd == "CLIP":
            self.inj.copy(arg)
        elif cmd == "CLIPU":
            self.inj.copy(unquote(arg.strip()))
        elif cmd == "A":
            name, _, a = arg.partition(" ")
            if re.fullmatch(r"[a-z]{2,12}", name):
                self.inj.action(name, a)
                self.note_activity("action")
        elif cmd == "R":
            cid = arg.strip()
            if cid in self.cmds:
                threading.Thread(target=self.run_command, args=(cid,), daemon=True).start()
        elif cmd == "MAN":
            threading.Thread(target=self.lookup, args=(arg.strip(),), daemon=True).start()
        elif cmd == "CMDS":
            self.cmds = load_commands()
            self.send_cmds()

    def run_command(self, cid):
        spec = self.cmds[cid]
        Out.ev(ev="run", id=cid)
        try:
            r = subprocess.run(spec["cmd"], capture_output=True, text=True, timeout=spec.get("timeout", 8), stdin=subprocess.DEVNULL)
            out = (r.stdout or "") + (("\n" + r.stderr) if r.stderr.strip() and not r.stdout.strip() else "")
            if not out.strip():
                out = "(khong co ket qua, ma thoat %d)" % r.returncode
        except subprocess.TimeoutExpired:
            out = "(het thoi gian cho)"
        except OSError as e:
            out = "(loi: %s)" % e.strerror
        self.send_view(spec["name"], clip_lines(out, spec.get("lines", 30)))

    def lookup(self, q):
        if not re.fullmatch(r"[A-Za-z0-9_.+\-]{1,30}( [A-Za-z0-9_.+\-]{1,30})?", q):
            self.send_view("man", "Ten lenh khong hop le")
            return
        name = q.split()[0]
        text = ""
        if self.inj.has.get("tldr"):
            rc, o = run(["tldr"] + q.split(), timeout=6)
            if rc == 0 and o.strip():
                text = o
        if not text and self.inj.has.get("man"):
            env = dict(os.environ, MANWIDTH="21", MAN_KEEP_FORMATTING="", PAGER="cat", LC_ALL="C")
            try:
                r = subprocess.run(["man", "-P", "cat"] + q.split(), capture_output=True, text=True, timeout=6, env=env, stdin=subprocess.DEVNULL)
                if r.returncode == 0:
                    text = r.stdout
            except (OSError, subprocess.SubprocessError):
                pass
        if not text:
            rc, o = run(["whatis", name], timeout=3)
            text = o if rc == 0 and o.strip() else "Khong co trang man/tldr cho '%s'" % q
        text = re.sub(r"\n{3,}", "\n\n", ascii_text(text))
        self.send_view(q, clip_lines(text, 120))

    # ---- đồng bộ việc cần làm ----
    def sync_todos(self):
        try:
            with open(TODO_JSON, encoding="utf-8") as f:
                items = json.load(f)
        except (OSError, ValueError):
            return
        parts = []
        for x in items[:30]:
            t = ascii_line(str(x.get("title", ""))).replace("|", "/")[:60]
            if t:
                parts.append("%d:%s" % (1 if x.get("done") else 0, t))
        payload = "|".join(parts)
        h = hashlib.md5(payload.encode()).hexdigest()
        if h != self.todo_hash and self.port:
            r = self.port.command("TODOSET " + payload)
            if r and r[-1].startswith("OK"):
                self.todo_hash = h

    def read_share(self):
        if not self.share:
            try:
                with open(SHARE_URL_FILE) as f:
                    return f.read().strip()
            except OSError:
                return ""
        return self.share

    # ---- vòng chính ----
    def set_state(self, s, **kw):
        if s != self.state:
            self.state = s
            Out.ev(ev="state", state=s, **kw)

    def ready(self, p):
        end = time.time() + 9
        while time.time() < end and not p.dead and not self.stop.is_set():
            r = p.command("PING", timeout=0.8)
            if "PONG" in r:
                return True
        return False

    def link_loop(self):
        while not self.stop.is_set():
            if self.paused:
                self.set_state("paused")
                time.sleep(0.5)
                continue
            path = find_port()
            if not path:
                self.set_state("waiting")
                if self.args.idle_exit and time.time() - self.last_device > self.args.idle_exit:
                    Out.ev(ev="exit", reason="idle")
                    self.stop.set()
                    return
                time.sleep(1.5)
                continue
            self.last_device = time.time()
            try:
                p = Port(path, self.on_event)
            except PermissionError:
                Out.ev(ev="error", error="perm", port=path)
                self.set_state("error")
                time.sleep(4)
                continue
            except OSError:
                time.sleep(2)
                continue
            if not self.ready(p):
                p.close()
                time.sleep(2)
                continue
            self.port, self.port_path = p, path
            off = time.localtime().tm_gmtoff or 0
            p.command("TIME %d %d" % (int(time.time()), off))
            r = p.command("HELLO " + ascii_line(socket.gethostname(), 18))
            m = re.search(r"v([0-9.]+)", " ".join(r))
            self.fw = m.group(1) if m else ""
            self.send_cmds()
            self.todo_hash = None
            self.set_state("connected", port=path, fw=self.fw, **{"inject": self.inj.describe()})
            self.session(p)
            self.port = None
            p.close()
            self.set_state("lost")
            time.sleep(1.5)

    def session(self, p):
        t_hello = t_stats = t_todo = 0
        threading.Thread(target=self.stats_loop, args=(p,), daemon=True).start()
        while not self.stop.is_set() and not p.dead and not self.paused:
            now = time.time()
            if now - t_hello > 4:
                t_hello = now
                p.command("HELLO " + ascii_line(socket.gethostname(), 18), timeout=2)
            if now - t_stats > 2:
                t_stats = now
                if self.stats.cur:
                    p.command(self.stats.line(self.read_share()), timeout=2)
                    Out.ev(ev="stats", **self.stats.cur)
                if self.pomo:
                    p.command("PCSTAT %d %d %s %s %s" % (self.stats.cur.get("cpu", 0), self.stats.cur.get("mem", 0), *self.pomo), timeout=2)
            if now - t_todo > 30:
                t_todo = now
                self.sync_todos()
            try:
                msg = self.pending_msgs.get(timeout=0.3)
                p.command(msg, timeout=3)
            except queue.Empty:
                pass

    def stats_loop(self, p):
        while not self.stop.is_set() and not p.dead:
            try:
                self.stats.collect()
            except Exception as e:
                log("stats error:", e)
            for _ in range(20):
                if self.stop.is_set() or p.dead:
                    return
                time.sleep(0.1)

    # ---- ổ cắm Unix cho buddy.py ----
    def serve(self):
        try:
            os.unlink(SOCK)
        except OSError:
            pass
        srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            srv.bind(SOCK)
        except OSError as e:
            log("không mở được ổ cắm:", e)
            return
        os.chmod(SOCK, 0o600)
        srv.listen(4)
        srv.settimeout(0.5)
        while not self.stop.is_set():
            try:
                c, _ = srv.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self.client, args=(c,), daemon=True).start()
        srv.close()
        try:
            os.unlink(SOCK)
        except OSError:
            pass

    def client(self, c):
        try:
            c.settimeout(30)
            f = c.makefile("rwb")
            for raw in f:
                try:
                    req = json.loads(raw.decode("utf-8"))
                except ValueError:
                    break
                if req.get("status"):
                    resp = {"ok": True, "state": self.state, "port": self.port_path, "fw": self.fw, "version": VERSION,
                            "inject": self.inj.describe(), "stats": self.stats.cur}
                elif req.get("stop"):
                    resp = {"ok": True}
                    self.stop.set()
                elif req.get("pause") is not None:
                    self.paused = bool(req["pause"])
                    if self.paused and self.port:
                        self.port.dead = True
                    resp = {"ok": True}
                elif "line" in req and self.port and not self.port.dead:
                    line = str(req["line"])
                    if len(line) > 2300 or "\n" in line:
                        resp = {"error": "line"}
                    else:
                        lines = self.port.command(line, until=req.get("until"), timeout=float(req.get("timeout", 6)))
                        resp = {"lines": lines}
                else:
                    resp = {"error": "no-device"}
                f.write((json.dumps(resp) + "\n").encode("utf-8"))
                f.flush()
        except (OSError, ValueError):
            pass
        finally:
            try:
                c.close()
            except OSError:
                pass

    # ---- stdin từ shell ----
    def stdin_loop(self):
        try:
            for l in sys.stdin:
                l = l.strip()
                cmd, _, arg = l.partition(" ")
                if cmd == "quit":
                    break
                elif cmd == "pause":
                    self.paused = True
                    if self.port:
                        self.port.dead = True
                elif cmd == "resume":
                    self.paused = False
                elif cmd == "pomo":
                    p = arg.split()
                    self.pomo = tuple(re.sub(r"\D", "", x) or "0" for x in p[:3]) if len(p) >= 3 else None
                elif cmd == "share":
                    self.share = arg.strip()
                elif cmd == "msg" and arg:
                    self.pending_msgs.put("MSG " + ascii_line(arg, 120))
                elif cmd == "note" and arg:
                    self.pending_msgs.put("NOTE " + ascii_line(arg, 200))
        except (OSError, ValueError):
            pass
        self.stop.set()                                   # stdin đóng = shell đã tắt -> dọn dẹp và thoát

    def main(self):
        signal.signal(signal.SIGTERM, lambda *a: self.stop.set())
        signal.signal(signal.SIGINT, lambda *a: self.stop.set())
        signal.signal(signal.SIGHUP, lambda *a: self.stop.set())
        Out.ev(ev="start", version=VERSION, inject=self.inj.describe(), commands=len(self.cmds))
        threading.Thread(target=self.worker, daemon=True).start()
        threading.Thread(target=self.serve, daemon=True).start()
        if not self.args.no_stdin and not sys.stdin.isatty():
            threading.Thread(target=self.stdin_loop, daemon=True).start()
        try:
            self.link_loop()
        finally:
            self.stop.set()
            if self.port:
                self.port.close()
            self.inj.close()
            try:
                os.unlink(SOCK)
            except OSError:
                pass
            Out.ev(ev="exit", reason="stopped")


def main():
    ap = argparse.ArgumentParser(description="Chương trình nền cho ESP32 OLED Buddy")
    ap.add_argument("--idle-exit", type=int, default=0, help="thoát nếu không thấy ESP32 trong N giây (0 = chạy mãi)")
    ap.add_argument("--no-stdin", action="store_true", help="không đọc lệnh từ stdin")
    ap.add_argument("--status", action="store_true", help="hỏi trạng thái của daemon đang chạy")
    ap.add_argument("--stop", action="store_true", help="tắt daemon đang chạy")
    a = ap.parse_args()
    if a.status or a.stop:
        try:
            s = socket.socket(socket.AF_UNIX)
            s.settimeout(3)
            s.connect(SOCK)
            s.sendall((json.dumps({"status": True} if a.status else {"stop": True}) + "\n").encode())
            print(s.makefile().readline().strip())
        except OSError:
            print(json.dumps({"ok": False, "state": "not-running"}))
            sys.exit(1)
        return
    # tránh chạy 2 bản
    try:
        s = socket.socket(socket.AF_UNIX)
        s.settimeout(1)
        s.connect(SOCK)
        s.close()
        log("buddyd đã chạy rồi")
        Out.ev(ev="exit", reason="already-running")
        sys.exit(2)
    except OSError:
        pass
    Daemon(a).main()


if __name__ == "__main__":
    main()
