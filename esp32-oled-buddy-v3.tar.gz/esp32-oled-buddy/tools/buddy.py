#!/usr/bin/env python3
"""Gửi dữ liệu sang ESP32 OLED Buddy qua cáp USB hoặc WiFi (chỉ dùng thư viện chuẩn Python 3).

Chữ / hình
  note <chữ>            ghi chú (lưu trong ESP32)        msg <chữ>   popup tạm thời
  wall <ảnh>            đặt nền 128x64 (cần Pillow hoặc ImageMagick)
File .txt
  put <file> [tên]      gửi file văn bản (tự bỏ dấu tiếng Việt)
  puttext <tên|-> <chữ> tạo file từ đoạn chữ (tên '-' = tự đặt theo giờ)
  get <tên> [nơi lưu]   tải file từ ESP32 về (mặc định ~/Downloads)
  ls | rm <tên> | open <tên>   liệt kê / xoá / mở để đọc trên màn OLED
Thông minh
  sync [cpu mem trạng_thái_pomo còn_lại hôm_nay]   giờ + CPU/RAM/Pomodoro + việc cần làm (từ todo.json)
  todos                 đẩy danh sách việc cần làm ngay
  weather               yêu cầu cập nhật thời tiết
  alarm HH:MM|off       báo thức       timer <phút> [nhãn]   hẹn giờ đếm ngược
Điều khiển máy tính & dò thông tin (cần buddyd.py đang chạy, firmware v3)
  mouse <dx> <dy>   click l|r|m|d   scroll <n>   key <ctrl+c>   type <chữ>   act <vol +5|mute|playpause|lock|shot…>
  cmds                  danh sách lệnh PC cho phép       run <id>   chạy lệnh đó (kết quả hiện trên OLED)
  man <lệnh>            PC tra man/tldr, hiện trên OLED   cheat <từ khóa>   tra cứu lệnh Linux có sẵn trong ESP32
  pc | sen              trạng thái nối PC / cảm biến      set <khóa> <giá trị>   (bright invert flip h24 secs night abr mspd home)
  hooks | hook <số>     webhook nhà thông minh            find [off]   báo điện thoại kêu       pin [số|off|new]   PIN trang web
  daemon status|stop|pause|resume   điều khiển buddyd (pause trước khi nạp firmware bằng PlatformIO!)
Mạng / thiết bị
  wifi <ssid> [mật khẩu]   geo <vĩ độ> <kinh độ>   info   net   host [địa chỉ]   time   ping   clearnotes

Kết nối: BUDDY_MODE=auto|usb|net (mặc định auto: ưu tiên USB, không có thì dùng mạng).
  USB: tự tìm /dev/serial/by-id/*, /dev/ttyUSB*, /dev/ttyACM* (ép bằng BUDDY_PORT).
  Mạng: BUDDY_HOST=<ip> hoặc file ~/.config/quickshell/study/buddy.host (tự lưu khi cắm USB), hoặc buddy.local.
  USB cần quyền cổng serial: nhóm `uucp` (Arch) / `dialout` (Debian, Ubuntu).
Mã thoát: 0 = ok, 1 = lỗi, 3 = không thấy thiết bị.
"""
import glob
import hashlib
import json
import os
import re
import select
import shutil
import socket
import subprocess
import sys
import termios
import time
import tty
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
HOME = os.path.expanduser("~")
HOST_FILE = os.path.join(HOME, ".config/quickshell/study/buddy.host")
TODO_JSON = os.path.join(HOME, ".config/quickshell/study/todo.json")
CACHE_DIR = os.path.join(HOME, ".cache/qs-study")
MAX_FILE = 48000
NO_DEVICE = 3


def fail(msg, code=1):
    print(msg)
    sys.exit(code)


# ---------------------------------------------------------------- chuỗi
PUNCT = {"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-", "…": "...", "•": "*", " ": " "}


def strip_accents(s):
    for k, v in PUNCT.items():
        s = s.replace(k, v)
    s = s.replace("đ", "d").replace("Đ", "D")
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c))


def ascii_line(s):
    """Một dòng: chỉ giữ ký tự in được ASCII."""
    return "".join(c if 32 <= ord(c) < 127 else " " for c in strip_accents(s)).strip()


def ascii_text(s):
    """Văn bản nhiều dòng: giữ xuống dòng, bỏ dấu, ký tự lạ thành '?'."""
    s = strip_accents(s.replace("\r\n", "\n").replace("\r", "\n"))
    out = []
    for c in s:
        if c == "\n":
            out.append(c)
        elif c == "\t":
            out.append(" ")
        elif 32 <= ord(c) < 127:
            out.append(c)
        elif ord(c) >= 128:
            out.append("?")
    return "".join(out)


def safe_name(n):
    n = os.path.basename(n.strip())
    n = re.sub(r"[^A-Za-z0-9._-]", "_", strip_accents(n))[:28]
    return n if n not in ("", ".", "..") else ""


# ---------------------------------------------------------------- kết nối USB
def find_port():
    p = os.environ.get("BUDDY_PORT")
    if p:
        return p
    for pat in ("/dev/serial/by-id/*", "/dev/ttyUSB*", "/dev/ttyACM*"):
        found = sorted(glob.glob(pat))
        if found:
            return found[0]
    return None


class SerialLink:
    kind = "usb"

    def __init__(self, port):
        self.port = port
        try:
            self.fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        except PermissionError:
            fail("Không có quyền mở %s (thêm user vào nhóm uucp/dialout rồi đăng nhập lại)" % port)
        except OSError as e:
            fail("Không mở được %s: %s" % (port, e.strerror))
        tty.setraw(self.fd)
        a = termios.tcgetattr(self.fd)
        a[2] = (a[2] | termios.CLOCAL | termios.CREAD) & ~termios.HUPCL   # đóng cổng không giật DTR
        a[4] = a[5] = termios.B115200
        termios.tcsetattr(self.fd, termios.TCSANOW, a)
        self.buf = b""

    def _write(self, data):
        view = memoryview(data)
        while view:
            _, w, _ = select.select([], [self.fd], [], 2)
            if not w:
                fail("Cổng serial không nhận dữ liệu")
            n = os.write(self.fd, view[:256])
            view = view[n:]
            time.sleep(0.004)

    def _readline(self, timeout):
        end = time.time() + timeout
        while True:
            i = self.buf.find(b"\n")
            if i >= 0:
                line, self.buf = self.buf[:i], self.buf[i + 1:]
                return line.decode("ascii", "ignore").strip()
            left = end - time.time()
            if left <= 0:
                return None
            r, _, _ = select.select([self.fd], [], [], left)
            if r:
                try:
                    chunk = os.read(self.fd, 4096)
                except BlockingIOError:
                    continue
                if not chunk:
                    return None
                self.buf += chunk

    def command(self, line, until=None, timeout=6):
        """Gửi 1 dòng; trả về các dòng phản hồi (dừng ở OK/ERR/PONG hoặc dòng `until`)."""
        self._write(line.encode("ascii", "ignore") + b"\n")
        out, end = [], time.time() + timeout
        while time.time() < end:
            l = self._readline(0.5)
            if l is None or l.startswith("@"):
                continue
            out.append(l)
            if until is not None:
                if l == until:
                    break
            elif l.startswith(("OK", "ERR")) or l == "PONG":
                break
        return out

    def wait_ready(self):
        # Mở cổng có thể làm ESP32 tự khởi động lại => hỏi PING tới khi nó trả lời
        end = time.time() + 9
        while time.time() < end:
            self._write(b"\nPING\n")
            t = time.time() + 0.5
            while time.time() < t:
                if self._readline(0.25) == "PONG":
                    return
        fail("ESP32 không trả lời (đã nạp firmware chưa? đã đóng pio monitor chưa?)")


# ---------------------------------------------------------------- qua buddyd (dùng chung cổng USB)
DAEMON_SOCK = os.path.join(os.environ.get("XDG_RUNTIME_DIR") or "/tmp", "buddyd-%d.sock" % os.getuid())


class DaemonLink:
    kind = "usb"

    def __init__(self, sock):
        self.s = sock
        self.f = sock.makefile("rwb")

    def _rpc(self, req):
        self.f.write((json.dumps(req) + "\n").encode())
        self.f.flush()
        raw = self.f.readline()
        if not raw:
            fail("buddyd đã đóng kết nối")
        return json.loads(raw.decode("utf-8"))

    def command(self, line, until=None, timeout=6):
        self.s.settimeout(timeout + 10)
        try:
            r = self._rpc({"line": line, "until": until, "timeout": timeout})
        except (OSError, ValueError) as e:
            fail("Lỗi nói chuyện với buddyd: %s" % e)
        if "error" in r:
            fail("buddyd: ESP32 chưa sẵn sàng (%s)" % r["error"])
        return r.get("lines", [])

    def wait_ready(self):
        pass


def daemon_connect():
    try:
        s = socket.socket(socket.AF_UNIX)
        s.settimeout(2)
        s.connect(DAEMON_SOCK)
        return DaemonLink(s)
    except OSError:
        return None


def daemon_rpc(req):
    link = daemon_connect()
    if not link:
        return None
    try:
        return link._rpc(req)
    except (OSError, ValueError):
        return None


# ---------------------------------------------------------------- kết nối mạng
def saved_host():
    h = os.environ.get("BUDDY_HOST")
    if h:
        return h
    try:
        with open(HOST_FILE) as f:
            h = f.read().strip()
            if h:
                return h
    except OSError:
        pass
    return "buddy.local"


class HttpLink:
    kind = "net"

    def __init__(self, host):
        self.host = host
        self.base = "http://" + host

    def _req(self, path, data=None, timeout=8):
        req = urllib.request.Request(self.base + path, data=data, method="POST" if data is not None else "GET")
        if data is not None:
            req.add_header("Content-Type", "text/plain; charset=utf-8")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", "ignore")

    def command(self, line, until=None, timeout=8):
        try:
            txt = self._req("/api/cmd", line.encode("ascii", "ignore"), timeout)
        except (urllib.error.URLError, OSError) as e:
            fail("Mất kết nối mạng tới %s (%s)" % (self.host, getattr(e, "reason", e)))
        return [l.strip() for l in txt.splitlines() if l.strip()]

    def wait_ready(self):
        pass

    def alive(self):
        try:
            self._req("/api/state", timeout=2)
            return True
        except (urllib.error.URLError, OSError, ValueError):
            return False


def connect():
    mode = os.environ.get("BUDDY_MODE", "auto").lower()
    if mode in ("auto", "usb"):
        d = daemon_connect()
        if d:
            return d
        port = find_port()
        if port:
            link = SerialLink(port)
            link.wait_ready()
            return link
        if mode == "usb":
            fail("Không thấy ESP32 qua USB: hãy cắm cáp", NO_DEVICE)
    host = saved_host()
    link = HttpLink(host)
    if link.alive():
        return link
    fail("Không thấy ESP32 (cắm cáp USB hoặc bật WiFi — địa chỉ %s)" % host, NO_DEVICE)


def is_ok(r):
    return bool(r) and r[-1].startswith("OK")


def need_ok(r, what):
    if not is_ok(r):
        fail("Lỗi %s: %s" % (what, " ".join(r) or "không phản hồi"))
    return r


def remember_host(link):
    """Cắm USB thì hỏi địa chỉ IP của ESP32 và nhớ lại để lần sau dùng được qua mạng."""
    if link.kind != "usb":
        return
    m = re.search(r"ip=(\d+\.\d+\.\d+\.\d+)", " ".join(link.command("NET")))
    if m and m.group(1) not in ("0.0.0.0", "192.168.4.1"):
        try:
            os.makedirs(os.path.dirname(HOST_FILE), exist_ok=True)
            with open(HOST_FILE, "w") as f:
                f.write(m.group(1))
        except OSError:
            pass


# ---------------------------------------------------------------- ảnh
def image_hex(path):
    """Ảnh -> 1024 byte (128x64, 1 bit, MSB trước, bit 1 = điểm sáng) dạng hex."""
    if not os.path.isfile(path):
        fail("Không thấy ảnh: " + path)
    try:
        from PIL import Image, ImageOps
        img = Image.open(path).convert("L")
        img = ImageOps.fit(img, (128, 64), method=Image.LANCZOS, centering=(0.5, 0.35))
        img = ImageOps.autocontrast(img, cutoff=2)
        bw = img.convert("1")                       # dither Floyd-Steinberg
        px = bw.load()
        data = bytearray(1024)
        for y in range(64):
            for x in range(128):
                if px[x, y]:
                    data[y * 16 + x // 8] |= 0x80 >> (x % 8)
        return data.hex()
    except ImportError:
        pass
    exe = shutil.which("magick") or shutil.which("convert")
    if not exe:
        fail("Thiếu Pillow hoặc ImageMagick (Arch: sudo pacman -S python-pillow)")
    cmd = [exe, path + "[0]", "-resize", "128x64^", "-gravity", "center", "-extent", "128x64",
           "-colorspace", "Gray", "-normalize", "-monochrome", "pbm:-"]
    try:
        raw = subprocess.run(cmd, capture_output=True, timeout=30, check=True).stdout
    except Exception:
        fail("ImageMagick không đọc được ảnh")
    body = raw[-1024:]                               # P4: 1 = đen => đảo lại
    if len(body) != 1024:
        fail("Ảnh chuyển đổi sai kích thước")
    return bytes(~b & 0xFF for b in body).hex()


# ---------------------------------------------------------------- file
def send_file_data(link, name, data):
    if len(data) > MAX_FILE:
        fail("File quá lớn (%d byte, tối đa %d)" % (len(data), MAX_FILE))
    need_ok(link.command("PUT " + name), "tạo file")
    step = 512
    for i in range(0, len(data), step):
        need_ok(link.command("APP %s %s" % (name, data[i:i + step].hex())), "ghi file")
    need_ok(link.command("END " + name), "đóng file")


def prepare_text_file(path, name=None):
    if not os.path.isfile(path):
        fail("Không thấy file: " + path)
    name = safe_name(name or path)
    if not name:
        fail("Tên file không hợp lệ")
    with open(path, "rb") as f:
        raw = f.read(MAX_FILE * 3)
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    return name, ascii_text(text).encode("ascii")


# ---------------------------------------------------------------- đồng bộ thông minh
def sync_todos(link, force=False):
    try:
        with open(TODO_JSON, encoding="utf-8") as f:
            items = json.load(f)
    except (OSError, ValueError):
        return False
    parts = []
    for x in items[:30]:
        t = ascii_line(str(x.get("title", ""))).replace("|", "/")[:60]
        if t:
            parts.append("%d:%s" % (1 if x.get("done") else 0, t))
    payload = "|".join(parts)
    digest = hashlib.md5(payload.encode()).hexdigest()
    cache = os.path.join(CACHE_DIR, "buddy-todo.hash")
    if not force:
        try:
            with open(cache) as f:
                if f.read().strip() == digest:
                    return False
        except OSError:
            pass
    r = link.command("TODOSET " + payload)
    if is_ok(r):
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            with open(cache, "w") as f:
                f.write(digest)
        except OSError:
            pass
        return True
    return False


# ---------------------------------------------------------------- lệnh chuyển thẳng sang firmware v3
def _need(args, n, usage):
    if len(args) < n:
        fail("Dùng: " + usage)


def _p(cmdname, n=0, usage="", until=None, upper=True):
    def f(args):
        _need(args, n, usage or cmdname)
        return (cmdname.upper() + (" " + " ".join(args) if args else ""), until)
    return f


PASS = {
    "mouse": _p("mouse", 2, "mouse <dx> <dy>"), "click": _p("click", 1, "click l|r|m|d|ld|lu"), "scroll": _p("scroll", 1, "scroll <n>"),
    "key": _p("key", 1, "key ctrl+c"), "type": lambda a: ("TYPEU " + urllib.parse.quote(" ".join(a), safe=""), None), "act": _p("act", 1, "act vol +5"),
    "run": _p("run", 1, "run <id>"), "man": _p("man", 1, "man <lệnh>"),
    "cheat": lambda a: ("CHEAT " + ascii_line(" ".join(a)), "END"), "pc": lambda a: ("PCLINK", None), "sen": lambda a: ("SEN", None),
    "set": _p("set", 2, "set <khóa> <giá trị>"), "hooks": lambda a: ("HOOKS", "END"), "hook": _p("hook", 1, "hook <số>"),
    "find": lambda a: ("FIND" + (" off" if a and a[0] == "off" else ""), None), "pin": lambda a: ("PIN " + " ".join(a), None),
}


# ---------------------------------------------------------------- main
def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help", "help"):
        print(__doc__.strip())
        sys.exit(0)
    cmd = sys.argv[1].lower()
    args = sys.argv[2:]
    arg = " ".join(args)

    # ---- kiểm tra / chuẩn bị dữ liệu trước khi mở kết nối ----
    payload = None
    if cmd in ("note", "msg"):
        payload = ascii_line(arg)
        if not payload:
            fail("Chưa có nội dung")
    elif cmd == "wall":
        payload = image_hex(arg)
    elif cmd == "put":
        if not args:
            fail("Thiếu đường dẫn file")
        payload = prepare_text_file(args[0], args[1] if len(args) > 1 else None)
    elif cmd == "puttext":
        if len(args) < 2:
            fail("Dùng: puttext <tên|-> <chữ>")
        name = safe_name(args[0]) if args[0] != "-" else time.strftime("clip-%Y%m%d-%H%M%S.txt")
        if not name:
            fail("Tên file không hợp lệ")
        payload = (name, ascii_text(" ".join(args[1:])).encode("ascii"))
    elif cmd in ("rm", "open", "get") and not args:
        fail("Thiếu tên file")
    elif cmd == "cmds":
        try:
            sys.path.insert(0, HERE)
            import buddyd
            for k, v in buddyd.load_commands().items():
                print("%-10s %s   [%s]" % (k, v["name"], " ".join(v["cmd"])))
        except ImportError:
            fail("Không thấy buddyd.py cạnh buddy.py")
        return
    elif cmd == "daemon":
        sub = args[0] if args else "status"
        req = {"status": True} if sub == "status" else ({"stop": True} if sub == "stop" else {"pause": sub == "pause"})
        if sub not in ("status", "stop", "pause", "resume"):
            fail("Dùng: daemon status|stop|pause|resume")
        r = daemon_rpc(req)
        if r is None:
            print("buddyd không chạy")
            sys.exit(1)
        print(json.dumps(r, ensure_ascii=False, indent=1) if sub == "status" else "OK")
        return
    elif cmd == "host":
        if args:
            os.makedirs(os.path.dirname(HOST_FILE), exist_ok=True)
            with open(HOST_FILE, "w") as f:
                f.write(args[0])
            print("Đã lưu địa chỉ ESP32: " + args[0])
        else:
            print("Địa chỉ ESP32: " + saved_host())
        return
    elif cmd == "alarm" and not args:
        fail("Dùng: alarm HH:MM hoặc alarm off")
    elif cmd == "timer" and not args:
        fail("Dùng: timer <phút> [nhãn]")
    elif cmd == "wifi" and not args:
        pass                                          # không tham số = xoá WiFi đã lưu
    elif cmd == "geo" and len(args) < 2:
        fail("Dùng: geo <vĩ độ> <kinh độ>")

    link = connect()

    off = time.localtime().tm_gmtoff or 0
    link.command("TIME %d %d" % (int(time.time()), off))      # ESP32 mất giờ khi mất điện => luôn đồng bộ
    remember_host(link)
    via = " (USB)" if link.kind == "usb" else " (WiFi)"

    if cmd == "ping":
        print("ESP32 sẵn sàng" + via)
    elif cmd == "time":
        print("Đã đồng bộ giờ" + via)
    elif cmd == "note":
        r = need_ok(link.command("NOTE " + payload), "gửi ghi chú")
        print("Đã gửi ghi chú (tổng %s)%s" % (r[-1].split()[-1], via))
    elif cmd == "msg":
        need_ok(link.command("MSG " + payload), "gửi popup")
        print("Đã gửi popup" + via)
    elif cmd == "wall":
        need_ok(link.command("WALL " + payload, timeout=10), "đặt nền")
        print("Đã đặt hình nền trên màn OLED" + via)
    elif cmd == "clearnotes":
        need_ok(link.command("CLEARNOTES"), "xoá ghi chú")
        print("Đã xoá hết ghi chú")
    elif cmd in ("put", "puttext"):
        name, data = payload
        send_file_data(link, name, data)
        print("Đã gửi %s (%d byte)%s" % (name, len(data), via))
    elif cmd == "ls":
        r = link.command("LS", until="END")
        print("\n".join(l for l in r if l != "END" and not l.startswith(("OK", "ERR"))))
    elif cmd == "get":
        name = safe_name(args[0])
        r = link.command("GET " + name, until="END", timeout=20)
        if r and r[0].startswith("ERR"):
            fail("Không thấy file " + name)
        data = b"".join(bytes.fromhex(l[5:]) for l in r if l.startswith("DATA "))
        dest = args[1] if len(args) > 1 else os.path.join(HOME, "Downloads")
        if os.path.isdir(dest):
            dest = os.path.join(dest, name)
        os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)
        print("Đã tải %s (%d byte) về %s" % (name, len(data), dest))
    elif cmd == "rm":
        need_ok(link.command("DEL " + arg), "xoá file")
        print("Đã xoá " + arg)
    elif cmd == "open":
        need_ok(link.command("OPEN " + arg), "mở file")
        print("Đang đọc %s trên màn OLED" % arg)
    elif cmd == "todos":
        sync_todos(link, force=True)
        print("Đã đồng bộ danh sách việc cần làm")
    elif cmd == "sync":
        nums = []
        for a in args[:5]:
            try:
                nums.append(str(int(float(a))))
            except ValueError:
                nums.append("0")
        if len(nums) >= 2:
            link.command("PCSTAT " + " ".join(nums))
        sync_todos(link)
        print("Đã đồng bộ" + via)
    elif cmd == "alarm":
        need_ok(link.command("ALARM " + (arg if arg.lower() == "off" else arg + " on")), "đặt báo thức")
        print("Đã tắt báo thức" if arg.lower() == "off" else "Đã đặt báo thức " + arg)
    elif cmd == "timer":
        need_ok(link.command("TIMER " + ascii_line(arg)), "đặt hẹn giờ")
        print("Đã đặt hẹn giờ " + arg)
    elif cmd == "wifi":
        ssid = args[0] if args else ""
        pw = " ".join(args[1:])
        need_ok(link.command("WIFI %s\t%s" % (ascii_line(ssid), pw.strip()) if ssid else "WIFI"), "lưu WiFi")
        print("Đã lưu WiFi %s, ESP32 đang kết nối…" % ssid if ssid else "Đã xoá WiFi đã lưu")
    elif cmd == "geo":
        need_ok(link.command("GEO %s %s" % (args[0], args[1])), "đặt vị trí")
        print("Đã đặt vị trí thời tiết %s, %s" % (args[0], args[1]))
    elif cmd in ("weather", "wx"):
        need_ok(link.command("WX"), "cập nhật thời tiết")
        print("Đã yêu cầu cập nhật thời tiết" + via)
    elif cmd in ("info", "net"):
        r = link.command("INFO") + link.command("NET")
        print("\n".join(r))
    elif cmd in PASS:
        line, until = PASS[cmd](args)
        r = link.command(line, until=until, timeout=10)
        if r and r[0].startswith("ERR"):
            fail(" ".join(r))
        print("\n".join(l for l in r if l != "END"))
    else:
        fail("Lệnh không hợp lệ: " + cmd + " (buddy.py help)")


if __name__ == "__main__":
    main()
