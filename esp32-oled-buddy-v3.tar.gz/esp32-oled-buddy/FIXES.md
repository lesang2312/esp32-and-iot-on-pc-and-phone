# Ghi chú v3.0
Kế thừa toàn bộ sửa lỗi của v2.1 (WiFi, file TXT, game, thời tiết). Thêm mới: xem README.md.
- `ENABLE_BT=0` (Bluetooth làm tràn flash).
- Trang web chuyển sang `page.h` + `web2.h`, có PIN; `/api/pcs` gộp trạng thái.
- Lệnh `HELLO/PCS2/CMDS/VIEW*/PIN` chỉ nhận từ USB.
- Phím `sudo`… trong trình soạn: giữ B hoàn tác ký tự vừa chọn rồi mở menu.
Chưa build bằng PlatformIO thật. Đã kiểm tra: `g++ -fsyntax-only` với stub, chạy thử xử lý lệnh/giao diện trên máy chủ, daemon thử với ESP giả qua pty, JS trang web bằng `node --check`.
