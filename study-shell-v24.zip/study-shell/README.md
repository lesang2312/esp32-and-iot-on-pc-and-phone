# Shell Quickshell "study" – nhẹ, đủ dùng

## Cài đặt
```sh
mkdir -p ~/.config/quickshell/study ~/Pictures/Wallpapers ~/.cache/qs-study
cp shell.qml Bar.qml Wallpaper.qml Pomodoro.qml ~/.config/quickshell/study/
# bỏ vài ảnh (png/jpg/webp) vào ~/Pictures/Wallpapers
qs -c study
```
Tự chạy khi vào Hyprland: thêm `exec-once = qs -c study` vào hyprland.conf.

## Tính năng
- Nền: lớp Background, quét `~/Pictures/Wallpapers`, nhớ ảnh đã chọn (`~/.cache/qs-study/wallpaper`).
  Bấm 🖼: trái = ảnh kế, phải = ảnh trước.
- Bar: workspace (Hyprland), đồng hồ, Pomodoro 25/5 (trái = chạy/dừng, phải = reset,
  có notify-send khi đổi pha), âm lượng (click = mute, cuộn = chỉnh), pin.
- Nhẹ: không dùng thư viện ngoài, ảnh nền giải mã đúng độ phân giải màn hình,
  đồng hồ cập nhật mỗi phút, timer chỉ chạy khi Pomodoro đang bật.

## Yêu cầu
Quickshell, PipeWire, UPower, `libnotify` (notify-send). Không dùng Hyprland thì
thay khối workspace trong Bar.qml bằng `Quickshell.I3` (Sway/i3) hoặc `Niri`.

## Chỉnh nhanh
- Thư mục nền / màu / thời gian Pomodoro: đầu `shell.qml`, `Bar.qml`, `Pomodoro.qml`.
- Đổi tên thư mục `study` thì chạy `qs -c <tên>` tương ứng.

## Nhận file từ điện thoại (share_png)
- Điện thoại và máy tính cùng WiFi: mở **Win+A** (hoặc nút 📲 trên bar, hoặc nút nổi ở mép phải màn hình) để xem địa chỉ + mã QR, quét bằng điện thoại.
- Trang trên điện thoại cho chọn / chụp và gửi **mọi loại file** (tối đa 500 MB mỗi file). Máy tính hiện thẻ kiểu Huawei Share (vòng sóng lan ra rồi bung thành thẻ có hình xem trước).
  **Lưu** = chuyển vào `~/.config/quickshell/study/share_png`, **Bỏ qua** = xoá; không bấm gì thì thẻ thu lại và file chờ, nút nổi hiện số file đang chờ.
- Nút nổi: trái = mở thư viện (xem ảnh lớn, mở file, xoá, sao chép ảnh), phải = bật/tắt nhận file. Điện thoại cũng thấy kết quả "đã lưu / đã bỏ qua".
- Lệnh: `qs -c study ipc call share toggle|on|off|save|skip`. Đổi nơi lưu: dòng `shareDir` trong `shell.qml`; đổi cổng: biến `SHARE_PORT`.
- Bảo mật: không có mật khẩu mặc định, ai cùng mạng cũng mở được trang gửi (file chỉ vào share_png khi bạn bấm Lưu). Muốn có mã PIN, tạo file `~/.config/quickshell/study/share.pin` chứa mã.
- Cần mở cổng 8765 nếu tường lửa chặn (`sudo ufw allow 8765/tcp`).

## ESP32 Buddy (màn OLED qua USB hoặc WiFi)
- Mở bảng: **Win+E** hoặc nút 📟 trên thanh. Có 3 tab: **Gửi** (ghi chú / tin nhắn / hình nền), **File** (gửi file .txt, danh sách file trên ESP32, ▶ Đọc / ⬇ / ✕) và **Thiết bị** (kết nối Tự động/USB/WiFi, tự đồng bộ, hẹn giờ, báo thức, WiFi, vị trí thời tiết).
- Kết nối: ưu tiên cáp USB, không có thì dùng WiFi (`buddy.local` hoặc IP trong `~/.config/quickshell/study/buddy.host`).
- Tự đồng bộ (tab Thiết bị): mỗi 15 giây gửi giờ, CPU/RAM, Pomodoro và danh sách việc cần làm.
- Gửi nhanh: `qs -c study ipc call buddy note "chữ"` | `msg` | `wall` | `time` | `put /đường/dẫn.txt` | `open tên.txt` | `alarm 06:30` | `timer 25 học` | `sync` | `autosync true`.
- `buddy.py` chỉ cần python3 (ảnh cần python-pillow hoặc imagemagick); mã thoát 3 = không thấy thiết bị.


## v24: Buddy v3 (màn phụ + điều khiển PC) và "script chỉ chạy khi dùng"
- Tab **🎛 PC** trong bảng Buddy (Win+E): công tắc "Liên kết", vòng CPU/RAM/pin/âm lượng sống động, nhạc đang phát, trạng thái chuột/phím. Dùng với firmware `esp32-oled-buddy-v3`.
- `buddyd.py` **chỉ chạy khi bật Liên kết và có ESP32 cắm** (shell dò cổng USB mỗi 5 giây), tự thoát sau 90 giây không thấy thiết bị, và tắt hẳn khi shell đóng. Tắt công tắc là dừng ngay.
- Máy chủ nhận file từ điện thoại (`share.py`) **không còn chạy sẵn**: mở thư viện (Win+A / nút nổi) hoặc chuột phải nút nổi để bật; **tự tắt sau 10 phút không dùng** (không có file chờ, thư viện đóng).
- Trang nhận file có nút "Chuyển sang gửi lên ESP32"; trang ESP32 có nút "Gửi lên PC".
- Nạp firmware PlatformIO: bấm "Nhả cổng USB" (hoặc `qs -c study ipc call buddy pause`), nạp xong bấm "Dùng lại" (`resume`).
- Lệnh PC cho ESP32 chạy: chỉnh `buddy-commands.json` (mẫu `buddy-commands.example.json`). Quyền chuột/phím: xem README firmware.
