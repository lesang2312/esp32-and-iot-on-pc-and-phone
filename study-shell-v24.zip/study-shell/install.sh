#!/bin/sh
# Cài study-shell đúng chỗ. Chạy trong thư mục đã giải nén:  sh install.sh
# Giữ nguyên dữ liệu của bạn khi cài đè: ảnh chụp (scr), ảnh kỷ niệm (memories), mục tiêu (goal.json).
set -e
here="$(cd "$(dirname "$0")" && pwd)"
dest="$HOME/.config/quickshell/study"
keep="scr memories share_png goal.json todo.json pomodoro.json buddy.json share.json share.pin buddy.host buddy-commands.json"

mkdir -p "$HOME/.config/quickshell" "$HOME/.config/hypr" \
         "$HOME/Pictures/Wallpapers" "$HOME/.cache/qs-study"

# Cất dữ liệu người dùng sang chỗ tạm
tmp="$(mktemp -d)"
for item in $keep; do
  if [ -e "$dest/$item" ]; then mv "$dest/$item" "$tmp/$item"; fi
done

rm -rf "$dest"
mkdir -p "$dest"
cp -r "$here/quickshell/study/." "$dest/"

# Trả dữ liệu về chỗ cũ
for item in $keep; do
  if [ -e "$tmp/$item" ]; then rm -rf "$dest/$item"; mv "$tmp/$item" "$dest/$item"; fi
done
mkdir -p "$dest/scr" "$dest/memories" "$dest/share_png"
rm -rf "$tmp"

# Cấu hình Hyprland (sao lưu bản cũ)
if [ -f "$HOME/.config/hypr/hyprland.lua" ]; then
  cp "$HOME/.config/hypr/hyprland.lua" "$HOME/.config/hypr/hyprland.lua.bak"
fi
cp "$here/hypr/hyprland.lua" "$HOME/.config/hypr/hyprland.lua"

# Thông báo giờ do Quickshell (Dynamic Island) nhận. Chỉ một chương trình được giữ dịch vụ thông báo,
# nên phải tắt mako / dunst / swaync nếu đang chạy.
for d in mako dunst swaync; do pkill -x "$d" 2>/dev/null || true; done

# Kiểm tra đã đủ file và đúng bản
for f in shell.qml Bar.qml Launcher.qml PowerMenu.qml ConnectPanel.qml MemoryGallery.qml GoalWidget.qml \
         WallpaperPicker.qml Wallpaper.qml Pomodoro.qml TodoPanel.qml BuddyPanel.qml Island.qml ShareToast.qml ShareDock.qml ShareGallery.qml netcheck.sh diag.sh sysmon.sh buddy.py buddyd.py share.py; do
  [ -f "$dest/$f" ] || { echo "THIẾU $f trong $dest"; exit 1; }
done
grep -q "shareOpen" "$dest/shell.qml" || { echo "shell.qml vẫn là bản cũ"; exit 1; }
if [ -e "$dest/study" ]; then echo "CẢNH BÁO: có thư mục lồng $dest/study, hãy xoá nó"; fi

# Nhận file từ điện thoại: cần python3; mở cổng 8765 trên tường lửa nếu có (ufw/firewalld)
command -v ufw >/dev/null 2>&1 && echo "Nếu dùng ufw và điện thoại không vào được: sudo ufw allow 8765/tcp"
command -v firewall-cmd >/dev/null 2>&1 && echo "Nếu dùng firewalld và điện thoại không vào được: sudo firewall-cmd --add-port=8765/tcp (thêm --permanent để giữ lại)"
command -v xdg-open >/dev/null 2>&1 || echo "Thiếu xdg-open (nút mở thư mục / mở file trong thư viện chia sẻ)"
command -v wl-copy >/dev/null 2>&1 || echo "Thiếu wl-clipboard (nút Sao chép trong thư viện chia sẻ)"

# ESP32 Buddy: cần quyền mở cổng USB serial và python3
command -v python3 >/dev/null 2>&1 || echo "Thiếu python3 (cần cho bảng ESP32 Buddy)"
if ! id -nG | grep -qwE "uucp|dialout"; then
  echo "Muốn gửi sang ESP32: thêm user vào nhóm serial rồi đăng nhập lại (Arch: sudo usermod -aG uucp $USER | Debian: dialout)"
fi
# Điều khiển PC từ ESP32: cần công cụ chuột/phím (ít nhất một trong các bộ dưới)
if [ ! -w /dev/uinput ]; then
  command -v wlrctl >/dev/null 2>&1 || command -v ydotool >/dev/null 2>&1 || command -v xdotool >/dev/null 2>&1 \
    || echo "Muốn ESP32 điều khiển chuột: cấp quyền /dev/uinput (xem README) hoặc cài wlrctl (Wayland) / xdotool (X11)"
fi
command -v wtype >/dev/null 2>&1 || command -v xdotool >/dev/null 2>&1 || [ -w /dev/uinput ] \
  || echo "Muốn ESP32 gõ phím/chữ lên PC: cài wtype (Wayland) hoặc xdotool (X11)"
command -v playerctl >/dev/null 2>&1 || echo "Tùy chọn: playerctl (hiện bài nhạc + nút phát/dừng trên OLED), brightnessctl (độ sáng)"
python3 -c "import PIL" 2>/dev/null || command -v magick >/dev/null 2>&1 || command -v convert >/dev/null 2>&1 \
  || echo "Muốn gửi hình nền sang ESP32: cài python-pillow hoặc imagemagick"

if [ ! -d /usr/share/icons/Papirus-Dark ] && [ ! -d "$HOME/.local/share/icons/Papirus-Dark" ] \
   && [ ! -d "$HOME/.icons/Papirus-Dark" ]; then
  echo "CHƯA CÓ theme Papirus-Dark: hãy cài gói papirus-icon-theme (Arch: sudo pacman -S papirus-icon-theme)"
fi
if ! fc-list 2>/dev/null | grep -qi "Inter"; then
  echo "Chưa thấy font Inter (dùng cho widget mục tiêu): Arch: sudo pacman -S inter-font"
fi

echo "Xong. Chạy:  pkill qs; qs -c study"
echo "Kiểm tra cấu hình Hyprland: hyprctl configerrors"
