import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Bảng điều khiển ESP32 Buddy (màn OLED): gửi chữ, hình, file .txt, báo thức, đồng bộ... qua USB hoặc WiFi.
// 4 tab: Gửi | File | PC (điều khiển, màn phụ) | Thiết bị. Esc để đóng. Logic gửi nằm trong shell.qml (buddyRun) nên phím tắt/ipc
// vẫn gửi được khi bảng đang đóng.
PanelWindow {
    id: win
    property var shell
    property var model              // FolderListModel ảnh nền (dùng làm danh sách ảnh để gửi)

    readonly property color accent: "#cba6f7"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#7f849c"
    property int tab: 0             // 0 Gửi, 1 File, 2 PC, 3 Thiết bị
    property real appear: 0
    property int mode: 0            // 0 = ghi chú (lưu trong ESP32), 1 = popup (hiện tạm)
    property string pasteMode: "note"

    visible: shell.buddyOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-buddy"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#99000000"

    function close() { shell.buddyOpen = false }
    onVisibleChanged: if (visible) { appearAnim.restart(); focusTab() } else appear = 0
    NumberAnimation { id: appearAnim; target: win; property: "appear"; from: 0; to: 1; duration: 320; easing.type: Easing.OutBack; easing.overshoot: 0.7 }

    function focusTab() {
        if (tab === 0) input.forceActiveFocus()
        else if (tab === 1) pathField.focusInput()
        else if (tab === 3) alarmField.focusInput()
    }
    function setTab(t) {
        tab = t
        if (t === 1 && shell.buddyFiles.length === 0) shell.buddyRun(["ls"], true)
        Qt.callLater(focusTab)
    }
    function submit() {
        if (sendText(input.text)) input.text = ""
        input.forceActiveFocus()
    }
    function sendText(t) {
        t = t.trim()
        if (t === "") return false
        shell.buddyRun([mode === 0 ? "note" : "msg", t])
        return true
    }
    function sendPath() {
        const p = pathField.text.trim()
        if (p !== "") shell.buddyRun(["put", p])
    }
    function fmtSize(n) { return n < 1024 ? n + " B" : (n / 1024).toFixed(1) + " KB" }

    // Lấy chữ đang copy rồi gửi đi (thành ghi chú/popup hoặc thành file .txt)
    Process {
        id: pasteProc
        command: ["wl-paste", "-n"]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.trim()
                if (t === "") { win.shell.buddyStatus = "Clipboard không có chữ"; win.shell.buddyOk = false }
                else if (win.pasteMode === "file") win.shell.buddyRun(["puttext", "-", t.slice(0, 40000)])
                else win.sendText(t.slice(0, 500))
            }
        }
    }

    // Hộp thoại chọn file: đóng bảng trong lúc chọn (bảng nằm trên cùng sẽ che hộp thoại), xong mở lại
    Process {
        id: pickProc
        command: ["sh", "-c",
            'zenity --file-selection --title="Chọn file văn bản gửi sang ESP32" --file-filter="Văn bản | *.txt *.md *.log" 2>/dev/null'
            + ' || kdialog --getopenfilename "$HOME" "*.txt *.md *.log" 2>/dev/null'
            + ' || yad --file --file-filter="*.txt *.md *.log" 2>/dev/null']
        stdout: StdioCollector {
            onStreamFinished: {
                win.shell.buddyOpen = true
                const p = text.trim()
                if (p !== "") { pathField.text = p; win.shell.buddyRun(["put", p]) }
                else { win.shell.buddyStatus = "Chưa chọn file (cần cài zenity hoặc kdialog, hoặc dán đường dẫn vào ô)"; win.shell.buddyOk = false }
            }
        }
    }

    component Pill: Rectangle {
        id: pill
        property string label: ""
        property color tint: "#313244"
        property color textColor: "#cdd6f4"
        property bool selected: false
        property int h: 30
        signal clicked()
        implicitWidth: pillText.implicitWidth + 24
        implicitHeight: h
        radius: h / 2
        scale: pillArea.pressed ? 0.93 : (pillArea.containsMouse ? 1.04 : 1)
        Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
        Behavior on color { ColorAnimation { duration: 160 } }
        color: selected ? win.accent : (pillArea.containsMouse ? Qt.lighter(tint, 1.25) : tint)
        Text { id: pillText; anchors.centerIn: parent; text: pill.label
               color: pill.selected ? "#1e1e2e" : pill.textColor; font.pixelSize: 12; font.bold: true }
        MouseArea { id: pillArea; anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor; onClicked: pill.clicked() }
    }

    component Field: Rectangle {
        id: fld
        property alias text: ti.text
        property string hint: ""
        property bool password: false
        property int h: 36
        signal submitted()
        function focusInput() { ti.forceActiveFocus() }
        implicitHeight: h
        radius: h / 2
        color: "#313244"
        border.width: 1
        border.color: ti.activeFocus ? win.accent : "transparent"
        TextInput {
            id: ti
            anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
            verticalAlignment: TextInput.AlignVCenter
            color: win.fg
            font.pixelSize: 13
            clip: true
            selectByMouse: true
            echoMode: fld.password ? TextInput.Password : TextInput.Normal
            Text {
                visible: ti.text === ""
                anchors.verticalCenter: parent.verticalCenter
                text: fld.hint
                color: win.dim
                font.pixelSize: 13
            }
            Keys.onPressed: e => {
                if (e.key === Qt.Key_Escape) { win.close(); e.accepted = true }
                else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) { fld.submitted(); e.accepted = true }
            }
        }
    }

    // Trang của một tab: hiện dần + trượt nhẹ lên khi chuyển tab
    component TabPage: ColumnLayout {
        id: page
        property int idx: 0
        visible: win.tab === idx
        Layout.fillWidth: true
        Layout.fillHeight: true
        transform: Translate { id: pageShift; y: 0 }
        onVisibleChanged: if (visible) pageIn.restart()
        ParallelAnimation {
            id: pageIn
            NumberAnimation { target: page; property: "opacity"; from: 0; to: 1; duration: 240; easing.type: Easing.OutCubic }
            NumberAnimation { target: pageShift; property: "y"; from: 14; to: 0; duration: 280; easing.type: Easing.OutCubic }
        }
    }

    // Vòng số liệu có hoạt ảnh (vẽ bằng Canvas)
    component Ring: Item {
        id: rg
        property real value: -1                   // 0..100, âm = không có dữ liệu
        property string label: ""
        property string unit: "%"
        property color tint: win.accent
        property real shown: 0
        implicitWidth: 84
        implicitHeight: 96
        onValueChanged: shown = value < 0 ? 0 : Math.min(100, value)
        Behavior on shown { NumberAnimation { duration: 800; easing.type: Easing.OutCubic } }
        onShownChanged: cv.requestPaint()
        onTintChanged: cv.requestPaint()
        Canvas {
            id: cv
            width: 66; height: 66
            anchors.horizontalCenter: parent.horizontalCenter
            onPaint: {
                const c = getContext("2d")
                c.reset()
                c.lineWidth = 7
                c.lineCap = "round"
                c.strokeStyle = "#313244"
                c.beginPath(); c.arc(33, 33, 26, 0, 2 * Math.PI); c.stroke()
                if (rg.shown > 0.5) {
                    c.strokeStyle = rg.tint
                    c.beginPath(); c.arc(33, 33, 26, -Math.PI / 2, -Math.PI / 2 + 2 * Math.PI * rg.shown / 100); c.stroke()
                }
            }
            Text {
                anchors.centerIn: parent
                text: rg.value < 0 ? "–" : Math.round(rg.value) + rg.unit
                color: rg.value < 0 ? win.dim : win.fg
                font.pixelSize: 14
                font.bold: true
            }
        }
        Text { anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom } text: rg.label; color: win.dim; font.pixelSize: 11 }
    }

    // Công tắc trượt
    component Toggle: Rectangle {
        id: tg
        property bool on: false
        signal toggled()
        implicitWidth: 50
        implicitHeight: 28
        radius: 14
        color: on ? "#a6e3a1" : "#45475a"
        Behavior on color { ColorAnimation { duration: 200 } }
        Rectangle {
            width: 22; height: 22; radius: 11
            y: 3
            x: tg.on ? tg.width - width - 3 : 3
            color: "#ffffff"
            Behavior on x { NumberAnimation { duration: 220; easing.type: Easing.OutBack } }
        }
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: tg.toggled() }
    }

    component Section: Text {
        color: win.fg
        font.pixelSize: 13
        font.bold: true
        Layout.topMargin: 4
    }

    // Click ra ngoài để đóng
    MouseArea { anchors.fill: parent; onClicked: win.close() }

    Rectangle {
        anchors.centerIn: parent
        width: 560
        height: Math.min(780, win.height - 40)
        radius: 26
        scale: 0.94 + 0.06 * win.appear
        opacity: Math.min(1, win.appear * 1.6)
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                Column {
                    Layout.fillWidth: true
                    spacing: 2
                    Text { text: "📟  ESP32 Buddy"; color: win.accent; font.pixelSize: 20; font.bold: true }
                    Text {
                        text: "Màn OLED · điều khiển PC · lệnh Linux · " + (win.shell.buddyMode === "auto" ? "USB hoặc WiFi tự chọn"
                              : (win.shell.buddyMode === "usb" ? "chỉ USB" : "chỉ WiFi"))
                        color: win.dim; font.pixelSize: 11
                    }
                }
                Pill { label: "✕"; onClicked: win.close() }
            }

            // ---- Thanh tab (có thanh trượt sáng) ----
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 38
                radius: 19
                color: "#181825"
                readonly property var names: ["✉ Gửi", "📄 File", "🎛 PC", "⚙ Thiết bị"]
                Rectangle {
                    y: 3
                    height: parent.height - 6
                    width: (parent.width - 6) / 4
                    radius: height / 2
                    x: 3 + win.tab * width
                    color: win.accent
                    Behavior on x { NumberAnimation { duration: 320; easing.type: Easing.OutBack; easing.overshoot: 0.9 } }
                }
                Row {
                    anchors { fill: parent; margins: 3 }
                    Repeater {
                        model: parent.parent.names
                        delegate: Item {
                            required property int index
                            required property string modelData
                            width: (parent.width) / 4
                            height: parent.height
                            Text {
                                anchors.centerIn: parent
                                text: modelData
                                color: win.tab === index ? "#1e1e2e" : win.fg
                                font.pixelSize: 12
                                font.bold: true
                                Behavior on color { ColorAnimation { duration: 200 } }
                            }
                            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: win.setTab(index) }
                        }
                    }
                }
            }

            // =================== TAB 0: GỬI ===================
            TabPage {
                idx: 0
                spacing: 10

                RowLayout {
                    spacing: 8
                    Pill { label: "📝 Ghi chú (lưu lại)"; selected: win.mode === 0; onClicked: win.mode = 0 }
                    Pill { label: "💬 Popup (hiện tạm)"; selected: win.mode === 1; onClicked: win.mode = 1 }
                }

                // Ô nhập, có nút gửi ➤ nằm trong ô
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 42
                    radius: 21
                    color: "#313244"
                    border.width: 1
                    border.color: input.activeFocus ? win.accent : "transparent"

                    Rectangle {
                        id: sendBtn
                        readonly property bool ready: input.text.trim() !== ""
                        anchors { right: parent.right; rightMargin: 5; verticalCenter: parent.verticalCenter }
                        width: 34; height: 34; radius: 17
                        color: !ready ? "#45475a" : (sendArea.containsMouse ? Qt.lighter(win.accent, 1.15) : win.accent)
                        Text {
                            anchors.centerIn: parent
                            text: win.shell.buddyBusy ? "…" : "➤"
                            color: sendBtn.ready ? "#1e1e2e" : win.dim
                            font.pixelSize: 15
                            font.bold: true
                        }
                        MouseArea {
                            id: sendArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.submit()
                        }
                    }

                    TextInput {
                        id: input
                        anchors { fill: parent; leftMargin: 18; rightMargin: 50 }
                        verticalAlignment: TextInput.AlignVCenter
                        color: win.fg
                        font.pixelSize: 14
                        clip: true
                        selectByMouse: true
                        Text {
                            visible: input.text === ""
                            anchors.verticalCenter: parent.verticalCenter
                            text: win.mode === 0 ? "Gõ ghi chú rồi nhấn Enter hoặc ➤…" : "Gõ nội dung popup rồi nhấn Enter hoặc ➤…"
                            color: win.dim
                            font.pixelSize: 14
                        }
                        Keys.onPressed: e => {
                            if (e.key === Qt.Key_Escape) { win.close(); e.accepted = true }
                            else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) { win.submit(); e.accepted = true }
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    text: "Màn OLED không có dấu tiếng Việt nên chữ được bỏ dấu khi gửi."
                    color: win.dim
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }

                Section { text: "🖼  Chọn ảnh làm nền màn OLED" }

                Item {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 78

                    Text {
                        anchors.centerIn: parent
                        visible: !win.model || win.model.count === 0
                        color: win.dim
                        font.pixelSize: 12
                        text: "Chưa có ảnh trong " + win.shell.wallDir
                    }

                    ListView {
                        anchors.fill: parent
                        clip: true
                        orientation: ListView.Horizontal
                        spacing: 8
                        model: win.model
                        delegate: Rectangle {
                            id: thumb
                            required property string filePath
                            width: 132
                            height: 74
                            radius: 10
                            color: "#313244"
                            clip: true
                            border.width: thumbArea.containsMouse ? 2 : 0
                            border.color: win.accent

                            Image {
                                anchors.fill: parent
                                anchors.margins: 2
                                source: "file://" + thumb.filePath
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                sourceSize: Qt.size(264, 148)
                            }
                            MouseArea {
                                id: thumbArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: win.shell.buddyRun(["wall", thumb.filePath])
                            }
                        }
                    }
                }

                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Pill { label: "📋 Gửi chữ đang copy"; onClicked: { win.pasteMode = "note"; pasteProc.running = true } }
                    Pill { label: "🖼 Nền hiện tại"; onClicked: win.shell.buddyRun(["wall", win.shell.wallpaper]) }
                    Pill { label: "🕒 Đồng bộ giờ"; onClicked: win.shell.buddyRun(["time"]) }
                    Pill { label: "🗑 Xoá hết ghi chú"; tint: "#45475a"; onClicked: win.shell.buddyRun(["clearnotes"]) }
                }

                Item { Layout.fillHeight: true }
            }

            // =================== TAB 1: FILE ===================
            TabPage {
                idx: 1
                spacing: 10

                Text {
                    Layout.fillWidth: true
                    text: "Gửi file văn bản (.txt .md .log, tối đa 48 KB) sang ESP32 để đọc trên màn OLED. Tiếng Việt được bỏ dấu tự động."
                    color: win.dim
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field {
                        id: pathField
                        Layout.fillWidth: true
                        hint: "Dán đường dẫn file rồi Enter…"
                        onSubmitted: win.sendPath()
                    }
                    Pill { label: "📂 Chọn…"; onClicked: { win.shell.buddyOpen = false; pickProc.running = true } }
                    Pill { label: "Gửi"; selected: pathField.text.trim() !== ""; onClicked: win.sendPath() }
                }

                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Pill { label: "📋 Chữ đang copy → file txt"; onClicked: { win.pasteMode = "file"; pasteProc.running = true } }
                    Pill { label: "🔄 Làm mới danh sách"; onClicked: win.shell.buddyRun(["ls"]) }
                }

                Section { text: "📁  File trong ESP32" + (win.shell.buddyFsInfo !== "" ? "  ·  " + win.shell.buddyFsInfo : "") }

                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    Text {
                        anchors.centerIn: parent
                        visible: win.shell.buddyFiles.length === 0
                        text: "Chưa có danh sách — bấm “Làm mới danh sách”"
                        color: win.dim
                        font.pixelSize: 12
                    }

                    ListView {
                        anchors.fill: parent
                        clip: true
                        spacing: 6
                        model: win.shell.buddyFiles
                        delegate: Rectangle {
                            id: fileRow
                            required property var modelData
                            width: ListView.view.width
                            height: 38
                            radius: 12
                            color: "#313244"

                            RowLayout {
                                anchors { fill: parent; leftMargin: 12; rightMargin: 8 }
                                spacing: 8
                                Text {
                                    Layout.fillWidth: true
                                    text: fileRow.modelData.name
                                    color: win.fg
                                    font.pixelSize: 13
                                    elide: Text.ElideRight
                                }
                                Text { text: win.fmtSize(fileRow.modelData.size); color: win.dim; font.pixelSize: 11 }
                                Pill { label: "▶ Đọc"; h: 26; onClicked: win.shell.buddyRun(["open", fileRow.modelData.name]) }
                                Pill { label: "⬇"; h: 26; onClicked: win.shell.buddyRun(["get", fileRow.modelData.name]) }
                                Pill { label: "✕"; h: 26; tint: "#45475a"; onClicked: win.shell.buddyRun(["rm", fileRow.modelData.name]) }
                            }
                        }
                    }
                }
            }

            // =================== TAB 2: PC (liên kết sâu) ===================
            TabPage {
                idx: 2
                spacing: 10

                // Thẻ trạng thái
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 78
                    radius: 18
                    color: "#181825"
                    border.width: 1
                    border.color: win.shell.buddyLinkState === "connected" ? "#4a7f5a" : "#313244"
                    Behavior on border.color { ColorAnimation { duration: 300 } }

                    // chấm nhịp
                    Item {
                        id: dotBox
                        x: 18; anchors.verticalCenter: parent.verticalCenter
                        width: 30; height: 30
                        readonly property color c: win.shell.buddyLinkState === "connected" ? "#a6e3a1"
                              : (win.shell.buddyLinkState === "waiting" ? "#f9e2af" : (win.shell.buddyLinkState === "error" ? "#f38ba8" : "#585b70"))
                        Rectangle {
                            id: pulse
                            anchors.centerIn: parent
                            width: 30; height: 30; radius: 15
                            color: "transparent"
                            border.width: 2
                            border.color: dotBox.c
                            visible: win.shell.buddyLinkState === "connected" || win.shell.buddyLinkState === "waiting"
                            SequentialAnimation on scale {
                                running: pulse.visible && win.visible
                                loops: Animation.Infinite
                                NumberAnimation { from: 0.5; to: 1.3; duration: 1400; easing.type: Easing.OutCubic }
                            }
                            SequentialAnimation on opacity {
                                running: pulse.visible && win.visible
                                loops: Animation.Infinite
                                NumberAnimation { from: 0.9; to: 0; duration: 1400 }
                            }
                        }
                        Rectangle { anchors.centerIn: parent; width: 14; height: 14; radius: 7; color: dotBox.c
                                    Behavior on color { ColorAnimation { duration: 250 } } }
                    }
                    Column {
                        anchors { left: parent.left; leftMargin: 62; right: tgl.left; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        spacing: 3
                        Text {
                            text: ({ off: "Liên kết đang tắt", waiting: "Chờ cắm ESP32…", connected: "Đã nối ESP32", paused: "Đã nhả cổng USB",
                                     lost: "Mất kết nối", error: "Không mở được cổng USB" })[win.shell.buddyLinkState] || "…"
                            color: win.fg; font.pixelSize: 15; font.bold: true
                        }
                        Text {
                            width: parent.width
                            elide: Text.ElideRight
                            color: win.dim; font.pixelSize: 11
                            text: win.shell.buddyLinkState === "connected" ? (win.shell.buddyPort + (win.shell.buddyFw !== "" ? "  ·  firmware v" + win.shell.buddyFw : ""))
                                  : (win.shell.buddyLinkState === "off" ? "Bật để dùng màn phụ, chuột/phím, lệnh Linux"
                                     : (win.shell.buddyLinkState === "error" ? "Thêm user vào nhóm uucp (Arch) / dialout (Debian)" : "Script chỉ chạy khi có ESP32 cắm"))
                        }
                    }
                    Toggle {
                        id: tgl
                        anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
                        on: win.shell.buddyLinkOn
                        onToggled: win.shell.buddySetLink(!win.shell.buddyLinkOn)
                    }
                }

                // Các vòng số liệu
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 128
                    radius: 18
                    color: "#181825"
                    opacity: win.shell.buddyLinkState === "connected" ? 1 : 0.55
                    Behavior on opacity { NumberAnimation { duration: 300 } }
                    Row {
                        anchors.centerIn: parent
                        spacing: 14
                        Ring { label: "CPU"; value: win.shell.buddyStats.cpu === undefined ? -1 : win.shell.buddyStats.cpu; tint: "#89b4fa" }
                        Ring { label: "RAM"; value: win.shell.buddyStats.mem === undefined ? -1 : win.shell.buddyStats.mem; tint: "#cba6f7" }
                        Ring { label: win.shell.buddyStats.chg ? "Pin ⚡" : "Pin"; value: win.shell.buddyStats.bat === undefined ? -1 : win.shell.buddyStats.bat; tint: "#a6e3a1" }
                        Ring { label: win.shell.buddyStats.mute ? "Âm (tắt)" : "Âm lượng"; value: win.shell.buddyStats.vol === undefined ? -1 : (win.shell.buddyStats.mute ? 0 : win.shell.buddyStats.vol); tint: "#f9e2af" }
                    }
                }

                // Đang phát + hoạt động
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 46
                    radius: 14
                    color: "#181825"
                    Row {
                        anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
                        spacing: 10
                        Row {   // thanh nhạc nhảy
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 3
                            Repeater {
                                model: 4
                                delegate: Rectangle {
                                    required property int index
                                    width: 4; radius: 2
                                    anchors.bottom: parent.bottom
                                    color: win.accent
                                    height: 4
                                    SequentialAnimation on height {
                                        running: win.visible && win.shell.buddyStats.mstat === "Playing"
                                        loops: Animation.Infinite
                                        NumberAnimation { to: 18; duration: 380 + index * 90; easing.type: Easing.InOutSine }
                                        NumberAnimation { to: 4; duration: 380 + index * 90; easing.type: Easing.InOutSine }
                                    }
                                }
                            }
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            width: 330
                            elide: Text.ElideRight
                            color: win.fg; font.pixelSize: 12
                            text: win.shell.buddyStats.media ? win.shell.buddyStats.media : "Không có nhạc đang phát"
                        }
                    }
                    Rectangle {
                        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        height: 26; radius: 13
                        width: actTxt.implicitWidth + 20
                        color: win.shell.buddyActive ? "#a6e3a1" : "#313244"
                        scale: win.shell.buddyActive ? 1 : 0.92
                        Behavior on color { ColorAnimation { duration: 200 } }
                        Behavior on scale { NumberAnimation { duration: 200; easing.type: Easing.OutBack } }
                        Text {
                            id: actTxt
                            anchors.centerIn: parent
                            font.pixelSize: 11; font.bold: true
                            color: win.shell.buddyActive ? "#1e1e2e" : win.dim
                            text: win.shell.buddyActive ? ({ mouse: "🖱 chuột", click: "🖱 bấm", scroll: "🖱 cuộn", key: "⌨ phím", type: "⌨ gõ", action: "⚡ lệnh" })[win.shell.buddyActKind] || "⚡" : "rảnh"
                        }
                    }
                }

                Section { text: "🧰  ESP32 đang dùng cách nào để điều khiển PC" }
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: [["🖱 Chuột", win.shell.buddyInject.pointer], ["⌨ Phím/chữ", win.shell.buddyInject.keys], ["📋 Clipboard", win.shell.buddyInject.clipboard]]
                        delegate: Rectangle {
                            required property var modelData
                            height: 28; radius: 14
                            width: chipT.implicitWidth + 22
                            color: modelData[1] ? "#233a2c" : "#45232b"
                            Text { id: chipT; anchors.centerIn: parent; font.pixelSize: 11; color: modelData[1] ? "#a6e3a1" : "#f38ba8"
                                   text: modelData[0] + ": " + (modelData[1] ? modelData[1] : "thiếu công cụ") }
                        }
                    }
                }
                Text {
                    Layout.fillWidth: true
                    visible: !win.shell.buddyInject.pointer || !win.shell.buddyInject.keys || win.shell.buddyInject.pointer !== "uinput"
                    text: "Mượt nhất: cấp quyền /dev/uinput (xem README mục “Chuột & phím”). Hoặc cài wlrctl + wtype (Wayland), xdotool (X11)."
                    color: "#f9e2af"; font.pixelSize: 11; wrapMode: Text.WordWrap
                }

                Section { text: "⚡  Điều khiển nhanh" }
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Pill { label: "⏮"; onClicked: win.shell.buddyRun(["act", "prev"]) }
                    Pill { label: "⏯"; onClicked: win.shell.buddyRun(["act", "playpause"]) }
                    Pill { label: "⏭"; onClicked: win.shell.buddyRun(["act", "next"]) }
                    Pill { label: "🔉"; onClicked: win.shell.buddyRun(["act", "vol -5"]) }
                    Pill { label: "🔊"; onClicked: win.shell.buddyRun(["act", "vol +5"]) }
                    Pill { label: "🔇"; onClicked: win.shell.buddyRun(["act", "mute"]) }
                    Pill { label: "🔒 Khóa"; onClicked: win.shell.buddyRun(["act", "lock"]) }
                    Pill { label: "📸 Chụp"; onClicked: win.shell.buddyRun(["act", "shot"]) }
                    Pill { label: "📱 Tìm điện thoại"; onClicked: win.shell.buddyRun(["find"]) }
                }

                Section { text: "🔌  Nạp firmware" }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Pill { label: win.shell.buddyPaused ? "▶ Dùng lại cổng USB" : "⏸ Nhả cổng USB (để nạp bằng PlatformIO)"
                           selected: win.shell.buddyPaused; onClicked: win.shell.buddyPause(!win.shell.buddyPaused) }
                }

                Item { Layout.fillHeight: true }
            }

            // =================== TAB 3: THIẾT BỊ ===================
            TabPage {
                idx: 3
                spacing: 8

                Section { text: "🔌  Kết nối" }
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Pill { label: "Tự động"; selected: win.shell.buddyMode === "auto"; onClicked: win.shell.buddySetMode("auto") }
                    Pill { label: "USB"; selected: win.shell.buddyMode === "usb"; onClicked: win.shell.buddySetMode("usb") }
                    Pill { label: "WiFi"; selected: win.shell.buddyMode === "net"; onClicked: win.shell.buddySetMode("net") }
                    Pill { label: win.shell.buddyAuto ? "🔄 Tự đồng bộ: BẬT" : "🔄 Tự đồng bộ: tắt"; selected: win.shell.buddyAuto
                           onClicked: win.shell.buddySetAuto(!win.shell.buddyAuto) }
                }
                Text {
                    Layout.fillWidth: true
                    text: "Tự đồng bộ: mỗi 15 giây đẩy giờ, CPU/RAM, Pomodoro và việc cần làm sang ESP32."
                    color: win.dim
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Pill { label: "🕒 Đồng bộ giờ"; onClicked: win.shell.buddyRun(["time"]) }
                    Pill { label: "✅ Đẩy việc cần làm"; onClicked: win.shell.buddyRun(["todos"]) }
                    Pill { label: "ℹ Thông tin"; onClicked: win.shell.buddyRun(["info"]) }
                }

                Section { text: "⏰  Báo thức & hẹn giờ" }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field { id: alarmField; Layout.preferredWidth: 110; hint: "HH:MM"; onSubmitted: win.shell.buddyRun(["alarm", alarmField.text]) }
                    Pill { label: "Đặt báo thức"; onClicked: win.shell.buddyRun(["alarm", alarmField.text]) }
                    Pill { label: "Tắt"; tint: "#45475a"; onClicked: win.shell.buddyRun(["alarm", "off"]) }
                }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field { id: timerMin; Layout.preferredWidth: 80; hint: "phút"; onSubmitted: win.shell.buddyRun(["timer", timerMin.text, timerLabel.text]) }
                    Field { id: timerLabel; Layout.fillWidth: true; hint: "Nhãn (không bắt buộc)"; onSubmitted: win.shell.buddyRun(["timer", timerMin.text, timerLabel.text]) }
                    Pill { label: "⏳ Hẹn giờ"; onClicked: win.shell.buddyRun(["timer", timerMin.text, timerLabel.text]) }
                }

                Section { text: "📶  WiFi của ESP32 (để dùng web, giờ NTP, thời tiết)" }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field { id: wifiSsid; Layout.fillWidth: true; hint: "Tên WiFi" }
                    Field { id: wifiPass; Layout.fillWidth: true; hint: "Mật khẩu"; password: true
                            onSubmitted: win.shell.buddyRun(["wifi", wifiSsid.text, wifiPass.text]) }
                    Pill { label: "Lưu"; onClicked: win.shell.buddyRun(["wifi", wifiSsid.text, wifiPass.text]) }
                }

                Section { text: "🌦  Vị trí thời tiết (mặc định TP.HCM 10.82, 106.63)" }
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Field { id: geoLat; Layout.fillWidth: true; hint: "Vĩ độ, vd 21.03" }
                    Field { id: geoLon; Layout.fillWidth: true; hint: "Kinh độ, vd 105.85"
                            onSubmitted: win.shell.buddyRun(["geo", geoLat.text, geoLon.text]) }
                    Pill { label: "Đặt"; onClicked: win.shell.buddyRun(["geo", geoLat.text, geoLon.text]) }
                }

                Item { Layout.fillHeight: true }
            }

            // ---- Kết quả chung ----
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 74
                radius: 14
                color: "#181825"
                border.width: 1
                border.color: win.shell.buddyBusy ? win.accent : (win.shell.buddyOk ? "#313244" : "#f38ba8")

                Text {
                    anchors { fill: parent; margins: 10 }
                    text: win.shell.buddyStatus !== "" ? win.shell.buddyStatus
                          : "Cắm cáp USB (hoặc bật WiFi trên ESP32) rồi gửi thử một ghi chú."
                    color: win.shell.buddyBusy ? win.accent : (win.shell.buddyOk ? win.fg : "#f38ba8")
                    font.pixelSize: 12
                    font.family: "monospace"
                    wrapMode: Text.WordWrap
                    elide: Text.ElideRight
                }
            }

            Text {
                Layout.fillWidth: true
                text: "Win+E mở bảng · qs -c study ipc call buddy note \"chữ\" | put /đường/dẫn.txt | alarm 06:30 | timer 25 \"Học\""
                color: win.dim
                font.pixelSize: 10
                wrapMode: Text.WordWrap
            }
        }
    }
}
