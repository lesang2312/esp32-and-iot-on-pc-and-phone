-- ───────── Arch TV (Hyprland Lua, cần Hyprland 0.55+) ─────────
-- Launcher là shell của máy: không có nút thoát. Nó tự ẩn khi mở ứng dụng
-- và tự hiện lại khi ứng dụng đóng.

local mod = "SUPER"

-- Tự khởi động giao diện TV
hl.on("hyprland.start", function()
  hl.exec_cmd("qs")
end)

-- Đóng ứng dụng đang xem (launcher tự hiện lại)
hl.bind(mod .. "+BackSpace", hl.dsp.window.close())
hl.bind(mod .. "+Q", hl.dsp.window.close())
-- Mở / ẩn màn hình chính (khi có file từ điện thoại gửi tới, bấm để nhận)
hl.bind(mod .. "+Home", hl.dsp.exec_cmd("qs ipc call tv toggle"))
-- Chia sẻ file với điện thoại (qua Wi-Fi hoặc cáp USB): Alt+Super+S = tab Gửi, Alt+Super+R = tab Nhận
hl.bind(mod .. "+ALT+S", hl.dsp.exec_cmd("qs ipc call share sendpage"))
hl.bind(mod .. "+ALT+R", hl.dsp.exec_cmd("qs ipc call share open"))
-- Bật / tắt thanh gợi ý phím
hl.bind(mod .. "+H", hl.dsp.exec_cmd("qs ipc call tv hints"))
-- Ứng dụng bị treo: buộc tắt
hl.bind(mod .. "+SHIFT+BackSpace", hl.dsp.window.kill())

-- Âm lượng (dùng được cả khi đang xem YouTube)
hl.bind(mod .. "+equal", hl.dsp.exec_cmd("wpctl set-volume -l 1.5 @DEFAULT_AUDIO_SINK@ 5%+"), { repeating = true })
hl.bind(mod .. "+minus", hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"), { repeating = true })
hl.bind(mod .. "+M", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"))

-- Phím media trên bàn phím / remote
hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd("wpctl set-volume -l 1.5 @DEFAULT_AUDIO_SINK@ 5%+"), { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"), { locked = true, repeating = true })
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"), { locked = true })

-- Trải nghiệm kiểu TV
hl.config({
  misc = {
    disable_hyprland_logo    = true,
    disable_splash_rendering = true,
  },
  cursor = {
    inactive_timeout  = 2,      -- ẩn con trỏ sau 2 giây không dùng
    hide_on_key_press = true,
  },
})

-- Ứng dụng luôn toàn màn hình, và không tự tắt màn hình khi đang xem
hl.window_rule({
  name  = "tv-fullscreen",
  match = { class = "^(chromium|Chromium)$" },
  fullscreen = true,
})
hl.window_rule({
  name  = "tv-idle",
  match = { class = ".*" },
  idle_inhibit = "fullscreen",
})
