#!/bin/sh
# Cập nhật Arch TV từ update.zip: giải nén -> kiểm tra -> sao lưu -> thay thế -> khởi động lại -> tự khôi phục nếu lỗi.
#   tv-update.sh prepare <update.zip>   giải nén, kiểm tra, sao lưu (in tiến trình, KHÔNG đổi gì trên máy)
#   tv-update.sh apply                  thay file đã kiểm tra, khởi động lại shell, canh chừng, lỗi thì khôi phục
#   tv-update.sh rollback               khôi phục bản sao lưu gần nhất (dùng tay khi cần)
# Dòng in ra:  STEP|<chữ>   OK|<phiên bản>|<số file>   ERR|<lý do>
# Biến môi trường (để thử): TV_DIR HYPR_LUA CACHE STATE TV_NO_RESTART=1

TV_DIR="${TV_DIR:-$HOME/.config/quickshell}"
HYPR_LUA="${HYPR_LUA:-$HOME/.config/hypr/hyprland.lua}"
CACHE="${CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/arch-tv}"
STATE="${STATE:-${XDG_STATE_HOME:-$HOME/.local/state}/arch-tv}"
STAGE="$CACHE/update/stage"
BACKUPS="$STATE/backups"
NOTE="$STATE/update-note"
ALLOWED="shell.qml android-cast.sh share.py tv-update.sh tv.lua"
MARK_BEGIN="-- >>> ARCH TV BEGIN"
MARK_END="-- <<< ARCH TV END"
MAX_BYTES=52428800
MAX_FILES=300
mkdir -p "$CACHE" "$STATE" "$BACKUPS"

step() { echo "STEP|$1"; }
fail() { echo "ERR|$1"; rm -rf "$CACHE/update"; exit 1; }

restart_shell() {
    [ -n "$TV_NO_RESTART" ] && return 0
    # shell nằm ở ~/.config/quickshell/shell.qml nên dùng qs không cần -c (không đụng tới shell khác như qs -c study)
    qs kill >/dev/null 2>&1 || pkill -fx 'qs' >/dev/null 2>&1
    sleep 1
    setsid qs -d >/dev/null 2>&1 < /dev/null || { setsid sh -c 'qs' >/dev/null 2>&1 < /dev/null & }
}

reload_hypr() { [ -n "$TV_NO_RESTART" ] || hyprctl reload >/dev/null 2>&1; }

# Thay khối ARCH TV trong hyprland.lua bằng nội dung file $1
put_lua_block() {
    blk="$CACHE/update/block.lua"
    { echo "$MARK_BEGIN"; cat "$1"; echo "$MARK_END"; } > "$blk"
    if [ -f "$HYPR_LUA" ] && grep -qF -- "$MARK_BEGIN" "$HYPR_LUA"; then
        awk -v b="$MARK_BEGIN" -v e="$MARK_END" -v f="$blk" '
            index($0, b) { while ((getline line < f) > 0) print line; skip = 1; next }
            index($0, e) { skip = 0; next }
            !skip { print }' "$HYPR_LUA" > "$HYPR_LUA.new" && mv -f "$HYPR_LUA.new" "$HYPR_LUA"
    else
        mkdir -p "$(dirname "$HYPR_LUA")"
        { [ -f "$HYPR_LUA" ] && cat "$HYPR_LUA"; echo; cat "$blk"; } > "$HYPR_LUA.new" && mv -f "$HYPR_LUA.new" "$HYPR_LUA"
    fi
}

prepare() {
    zip="$1"
    [ -f "$zip" ] || fail "Không thấy file cập nhật"
    command -v unzip >/dev/null 2>&1 || fail "Thiếu unzip (chạy lại install.sh)"
    rm -rf "$CACHE/update"; mkdir -p "$STAGE"

    step "Kiểm tra file zip"
    unzip -tqq "$zip" >/dev/null 2>&1 || fail "File zip bị lỗi hoặc không đọc được"
    list="$(unzip -Z1 "$zip" 2>/dev/null)" || fail "Không đọc được danh sách file trong zip"
    [ -n "$list" ] || fail "File zip rỗng"
    n="$(printf '%s\n' "$list" | wc -l)"
    [ "$n" -le "$MAX_FILES" ] || fail "Zip có quá nhiều file ($n)"
    printf '%s\n' "$list" | grep -qE '(^/|(^|/)\.\.(/|$)|\\)' && fail "Zip chứa đường dẫn không an toàn"
    unzip -Z "$zip" 2>/dev/null | grep -q '^l' && fail "Zip chứa liên kết tượng trưng (symlink)"
    total="$(unzip -Zt "$zip" 2>/dev/null | awk '{print $3}' | tail -n1)"
    case "$total" in ''|*[!0-9]*) total=0 ;; esac
    [ "$total" -le "$MAX_BYTES" ] || fail "Zip giải nén quá lớn"

    step "Giải nén"
    unzip -qq -o "$zip" -d "$STAGE" >/dev/null 2>&1 || fail "Giải nén thất bại"
    # đề phòng: xoá mọi symlink còn sót
    find "$STAGE" -type l -delete 2>/dev/null

    # Thư mục gốc: nơi có shell.qml (hoặc file hợp lệ khác), sâu tối đa 2 cấp
    root=""
    for d in "$STAGE" "$STAGE"/* "$STAGE"/*/*; do
        [ -d "$d" ] || continue
        for f in $ALLOWED; do
            [ -f "$d/$f" ] && { root="$d"; break 2; }
        done
    done
    [ -n "$root" ] || fail "Zip không có file nào của TV (shell.qml, share.py, android-cast.sh, tv.lua...)"

    step "Kiểm tra nội dung"
    files=""
    for f in $ALLOWED; do
        [ -f "$root/$f" ] || continue
        # file giống hệt bản đang chạy thì bỏ qua, không ghi đè
        [ -f "$TV_DIR/$f" ] && cmp -s "$root/$f" "$TV_DIR/$f" && continue
        [ -s "$root/$f" ] || fail "$f bị rỗng"
        sz="$(wc -c < "$root/$f")"
        [ "$sz" -le 5242880 ] || fail "$f quá lớn"
        iconv -f UTF-8 -t UTF-8 "$root/$f" >/dev/null 2>&1 || fail "$f không phải văn bản UTF-8"
        case "$f" in
            shell.qml)
                grep -q 'ShellRoot' "$root/$f" || fail "shell.qml không có ShellRoot"
                grep -q '^import Quickshell' "$root/$f" || fail "shell.qml thiếu import Quickshell"
                o="$(tr -cd '{' < "$root/$f" | wc -c)"; c="$(tr -cd '}' < "$root/$f" | wc -c)"
                [ "$o" -eq "$c" ] || fail "shell.qml lệch dấu ngoặc nhọn ($o mở, $c đóng)"
                ;;
            *.sh)
                sh -n "$root/$f" 2>/dev/null || fail "$f có lỗi cú pháp shell"
                ;;
            share.py)
                python3 -I -c 'import sys;compile(open(sys.argv[1],encoding="utf-8").read(),sys.argv[1],"exec")' "$root/$f" 2>/dev/null \
                    || fail "share.py có lỗi cú pháp Python"
                ;;
            tv.lua)
                for lc in luac luac5.4 luac5.3 luajit; do
                    if command -v "$lc" >/dev/null 2>&1; then
                        case "$lc" in luajit) "$lc" -bl "$root/$f" >/dev/null 2>&1 ;; *) "$lc" -p "$root/$f" 2>/dev/null ;; esac \
                            || fail "tv.lua có lỗi cú pháp Lua"
                        break
                    fi
                done
                ;;
        esac
        files="$files $f"
    done
    [ -n "$files" ] || fail "Zip không có file hệ thống nào thay đổi, không ghi đè gì"
    ver=""
    [ -f "$root/VERSION" ] && ver="$(head -n1 "$root/VERSION" | tr -cd 'A-Za-z0-9._+ -' | cut -c1-30)"
    [ -n "$ver" ] || ver="$(date +%Y%m%d-%H%M)"

    step "Sao lưu bản hiện tại"
    ts="$(date +%Y%m%d-%H%M%S)"
    bk="$BACKUPS/$ts"
    mkdir -p "$bk/tv"
    for f in $ALLOWED; do [ -f "$TV_DIR/$f" ] && cp -p "$TV_DIR/$f" "$bk/tv/$f"; done
    [ -f "$HYPR_LUA" ] && cp -p "$HYPR_LUA" "$bk/hyprland.lua"
    [ -f "$TV_DIR/VERSION" ] && cp -p "$TV_DIR/VERSION" "$bk/tv/VERSION"
    echo "$ts" > "$STATE/last-backup"
    # chỉ giữ 5 bản sao lưu gần nhất
    ls -1d "$BACKUPS"/*/ 2>/dev/null | sort | head -n -5 | while read -r old; do rm -rf "$old"; done

    # Chuẩn bị thư mục chờ áp dụng
    rm -rf "$CACHE/update/ready"; mkdir -p "$CACHE/update/ready"
    for f in $files; do cp "$root/$f" "$CACHE/update/ready/$f"; done
    echo "$ver" > "$CACHE/update/ready/VERSION"
    echo "$files" | tr -s ' ' > "$CACHE/update/ready/FILES"
    rm -rf "$STAGE"
    echo "OK|$ver|$(echo $files | wc -w)"
}

restore() {   # $1 = thư mục sao lưu
    bk="$1"
    for f in $ALLOWED VERSION; do
        if [ -f "$bk/tv/$f" ]; then cp -p "$bk/tv/$f" "$TV_DIR/.$f.new" && mv -f "$TV_DIR/.$f.new" "$TV_DIR/$f"; fi
    done
    [ -f "$bk/hyprland.lua" ] && cp -p "$bk/hyprland.lua" "$HYPR_LUA"
}

apply() {
    ready="$CACHE/update/ready"
    [ -f "$ready/FILES" ] || { echo "ERR|Chưa có bản cập nhật đã kiểm tra"; exit 1; }
    ts="$(cat "$STATE/last-backup" 2>/dev/null)"
    bk="$BACKUPS/$ts"
    [ -d "$bk" ] || { echo "ERR|Không thấy bản sao lưu, huỷ cập nhật"; exit 1; }
    ver="$(cat "$ready/VERSION")"
    mkdir -p "$TV_DIR"
    lua_changed=0
    for f in $(cat "$ready/FILES"); do
        cp "$ready/$f" "$TV_DIR/.$f.new" || { restore "$bk"; echo "ERR|Không ghi được $f"; exit 1; }
        case "$f" in *.sh) chmod +x "$TV_DIR/.$f.new" ;; esac
        mv -f "$TV_DIR/.$f.new" "$TV_DIR/$f"
        [ "$f" = tv.lua ] && lua_changed=1
    done
    cp "$ready/VERSION" "$TV_DIR/VERSION"
    [ "$lua_changed" = 1 ] && { mkdir -p "$CACHE/update"; put_lua_block "$TV_DIR/tv.lua"; }
    echo "ok|$ver" > "$NOTE"
    rm -f "$CACHE/alive"
    : > "$CACHE/restart-mark"
    sleep 0.3
    [ "$lua_changed" = 1 ] && reload_hypr
    restart_shell
    # Canh chừng: shell mới phải tự ghi file "alive" trong 20 giây, nếu không thì khôi phục bản cũ
    i=0
    while [ "$i" -lt 20 ]; do
        sleep 1
        [ "$CACHE/alive" -nt "$CACHE/restart-mark" ] && { rm -rf "$CACHE/update"; exit 0; }
        i=$((i + 1))
    done
    restore "$bk"
    echo "rolled|Bản mới không khởi động được, đã khôi phục bản cũ" > "$NOTE"
    [ "$lua_changed" = 1 ] && reload_hypr
    restart_shell
    rm -rf "$CACHE/update"
    exit 2
}

rollback() {
    ts="$(cat "$STATE/last-backup" 2>/dev/null)"
    bk="$BACKUPS/$ts"
    [ -d "$bk" ] || { echo "ERR|Chưa có bản sao lưu nào"; exit 1; }
    restore "$bk"; reload_hypr; restart_shell
    echo "OK|Đã khôi phục $ts|0"
}

case "$1" in
    prepare) prepare "$2" ;;
    apply) apply ;;
    rollback) rollback ;;
    *) echo "Cách dùng: $0 prepare <update.zip> | apply | rollback"; exit 64 ;;
esac
