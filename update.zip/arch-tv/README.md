# Arch TV — Hyprland + Quickshell

Biến máy Arch Linux thành một chiếc TV điều khiển hoàn toàn bằng bàn phím.

## Cập nhật nhanh (không cài gói)

```bash
./deploy.sh
```

Chép các file vào `~/.config/quickshell/`, cập nhật khối Hyprland rồi khởi động lại shell. Tuỳ chọn: `--no-hypr`, `--no-restart`.

## Cài đặt

```bash
chmod +x install.sh
./install.sh
```

Script cài sẵn: Hyprland (cần bản 0.55 trở lên để dùng Lua), Quickshell, Chromium, font, **âm thanh** (PipeWire + WirePlumber) và **Wi-Fi** (NetworkManager), đồng thời bật các dịch vụ tương ứng.

**Cấu hình Hyprland dùng `~/.config/hypr/hyprland.lua`.** Script tự tạo file này (hoặc thêm một khối `ARCH TV` vào file có sẵn, chạy lại nhiều lần không bị trùng). Nếu trước đó bạn dùng `hyprland.conf`, nó được sao lưu thành `hyprland.conf.bak`; vì Lua được ưu tiên nên monitor, input... cũ cần chuyển sang Lua (có thể dùng `hyprlang2lua` trên AUR).
Sau đó đăng xuất rồi vào lại Hyprland, hoặc chạy thử: `qs`

## Phím tắt

**Màn hình chính**

| Phím | Chức năng |
|---|---|
| ← → (hoặc H L) | Chọn ứng dụng |
| 1–5 | Chọn nhanh |
| Enter / Space | Mở |
| ↑ ↓ (hoặc + -) | Âm lượng |
| M | Tắt tiếng |
| F1 | Bảng trợ giúp |

Màn hình chính là shell của máy nên **không có phím thoát**. Nó tự ẩn khi mở ứng dụng và tự hiện lại khi ứng dụng đóng.

**Màn hình Wi-Fi**

| Phím | Chức năng |
|---|---|
| ↑ ↓ | Chọn mạng |
| Enter | Kết nối (mạng có mật khẩu sẽ mở bàn phím ảo) |
| R | Quét lại |
| F | Quên mạng đã lưu |
| Esc | Quay lại màn hình chính |

**Bàn phím ảo:** mũi tên để di chuyển, Enter để nhấn phím, có thể gõ trực tiếp bằng bàn phím thật, Ctrl+Enter để kết nối, Esc để hủy.

**Toàn hệ thống**

| Phím | Chức năng |
|---|---|
| Super + Q / Super + Backspace | Đóng ứng dụng đang xem (launcher tự hiện lại) |
| Super + Shift + Backspace | Buộc tắt ứng dụng bị treo |
| Super + = / - | Âm lượng |
| Super + M | Tắt / bật tiếng |

**Trong YouTube** (giao diện YouTube TV): mũi tên để di chuyển, Enter để chọn, Esc hoặc Backspace để quay lại.

## YouTube

Dùng `youtube.com/tv` với user-agent kiểu Cobalt (giống YouTube trên máy chơi game/TV) nên hiện giao diện TV.
Lần đầu chọn đăng nhập bằng điện thoại, mở `youtube.com/activate` và nhập mã.

## Tuỳ chỉnh

- Thêm ứng dụng: sửa mảng `apps` ở đầu `shell.qml`.
- Đổi trình duyệt: sửa `browser` (ví dụ `google-chrome-stable`, `brave`).
- Khởi động thẳng vào TV: dùng greetd hoặc tự đăng nhập tty rồi chạy `Hyprland`.

## Điều khiển Trình duyệt chỉ bằng bàn phím

| Phím | Chức năng |
|---|---|
| Ctrl + L (hoặc F6) | Nhảy lên thanh địa chỉ, gõ địa chỉ hoặc từ khóa rồi Enter |
| Tab / Shift + Tab | Chuyển giữa liên kết, ô nhập, nút |
| Enter | Mở mục đang chọn |
| ↑ ↓ / Space / Shift + Space | Cuộn trang |
| Alt + ← / Alt + → | Trang trước / sau |
| Ctrl + T / Ctrl + W | Mở / đóng thẻ |
| Ctrl + Tab / Ctrl + Shift + Tab | Chuyển thẻ |
| Ctrl + F | Tìm trong trang |
| F7 | Bật con trỏ văn bản (duyệt bằng mũi tên) |
| Super + Q | Thoát về màn hình TV |

## YouTube (giao diện TV)

| Phím | Chức năng |
|---|---|
| ← ↑ ↓ → | Di chuyển giữa video, menu, nút |
| Enter | Chọn / phát |
| Esc | Quay lại |
| Space | Phát / tạm dừng (khi đang xem) |
| ← → (khi đang xem) | Tua lùi / tới |
| Super + = / - , Super + M | Âm lượng, tắt tiếng |
| Super + Q | Thoát về màn hình TV |

Tìm kiếm: di chuyển lên mục kính lúp, Enter, gõ chữ bằng bàn phím thật rồi Enter.
Đăng nhập lần đầu bằng điện thoại: `youtube.com/activate`.

Nếu vẫn hiện giao diện YouTube thường, bấm Super+Q rồi mở lại. Khi đó có thể dùng: Space hoặc K phát/dừng, J / L lùi/tới 10 giây, ← → lùi/tới 5 giây, ↑ ↓ âm lượng, F toàn màn hình, M tắt tiếng, C phụ đề, `/` nhảy vào ô tìm kiếm.

**Gợi ý phím:** khi mở YouTube hoặc Trình duyệt, một thanh gợi ý phím nổi ở cuối màn hình trong 20 giây. Bấm Super+H để ẩn/hiện lại bất cứ lúc nào.

## Truyền màn hình

Thẻ **Truyền màn hình** (phím 5) cho phép chiếu màn hình điện thoại hoặc máy khác lên TV.

| Phím | Chức năng |
|---|---|
| Enter | Bật / tắt AirPlay (iPhone, iPad, Mac) |
| S | Chiếu điện thoại Android qua cáp USB (scrcpy) |
| Esc | Hủy đang kết nối / tắt AirPlay và quay lại |
| Super + Q | Ngắt kết nối khi đang chiếu |

- **iPhone / iPad:** nhấn Enter để bật AirPlay, mở Trung tâm điều khiển, chọn Phản chiếu màn hình, chọn "Arch TV". Điện thoại và TV phải cùng mạng Wi-Fi.
- **Android (cáp USB):** bật Tùy chọn nhà phát triển và Gỡ lỗi USB, cắm cáp vào TV, chấp nhận kết nối trên điện thoại rồi nhấn **S** (dùng scrcpy).
- **Chiếu video YouTube từ điện thoại:** trong thẻ YouTube trên TV vào Settings, Link with TV code, rồi trên điện thoại mở YouTube và bấm biểu tượng Cast.
- **Mật khẩu AirPlay:** mặc định ai cùng mạng cũng chiếu được. Muốn khóa, đặt `castPw` trong `shell.qml`.
- Khi đang chiếu, launcher tự ẩn và hiện lại khi bạn ngắt kết nối.

## Chia sẻ file với điện thoại (phím 6): Nhận và Gửi

Thẻ **Chia sẻ file** mở một máy chủ nhỏ trên máy. Điện thoại mở địa chỉ hiện trên màn hình (hoặc quét mã QR). Bấm **Tab** để đổi giữa hai tab **NHẬN** và **GỬI**.

**Đường truyền.** Dùng được qua Wi-Fi cùng mạng, hoặc qua **cáp USB khi máy lấy internet từ điện thoại** (bật "Chia sẻ mạng qua USB" / USB tethering trên Android, hoặc "Điểm truy cập cá nhân" trên iPhone). Khi có cổng USB, địa chỉ của cổng đó được ưu tiên hiện đầu tiên (kèm tên cổng, ví dụ `enx…`), các địa chỉ khác hiện ở dòng nhỏ bên dưới. Cắm hoặc rút cáp thì địa chỉ và mã QR tự đổi sau vài giây. Cổng mặc định 8765 (đổi bằng biến `SHARE_PORT`).

### NHẬN (điện thoại → máy)

Điện thoại chọn file rồi bấm Gửi. File chờ ở hàng đợi, **chỉ khi bấm Lưu** mới chuyển vào `~/Downloads`.

| Phím | Chức năng |
|---|---|
| ↑ ↓ | Chọn file trong hàng chờ |
| Enter | Lưu file đang chọn |
| A | Lưu tất cả |
| D (hoặc Delete) | Bỏ qua (xoá) file đang chọn |
| T | Bật / tắt máy chủ |
| Tab (hoặc →) | Sang tab Gửi |
| Esc | Quay lại (file vẫn chờ) |

### GỬI (máy → điện thoại)

Chọn file trên máy, file hiện ở mục **“TV đang chia sẻ”** trên trang web của điện thoại, bấm là tải về (tải tiếp được nếu đứt giữa chừng). Chỉ những file bạn chọn mới được chia sẻ.

| Phím | Chức năng |
|---|---|
| Enter (hoặc A) | Mở trình chọn file trên máy |
| ↑ ↓ | Chọn file đang chia sẻ |
| D | Ngừng chia sẻ file đang chọn |
| C | Ngừng chia sẻ tất cả |
| T | Bật / tắt máy chủ |
| Tab (hoặc ←) | Sang tab Nhận |

**Trình chọn file:** ↑ ↓ chọn, Enter mở thư mục hoặc thêm file, Backspace (hoặc ←) lên thư mục trên, `.` hiện/ẩn file ẩn, Home về thư mục nhà, Esc đóng.

**Gửi từ dòng lệnh** (gắn vào trình quản lý file, script, phím tắt...):

```bash
qs ipc call share send "/đường/dẫn/file"   # chia sẻ file đó
qs ipc call share sendpage                  # mở thẳng tab Gửi
qs ipc call share open                      # mở tab Nhận
```

Phím tắt Hyprland: **Super + Alt + S** mở tab Gửi, **Super + Alt + R** mở tab Nhận, **Super + Home** hiện/ẩn màn hình chính.

Khi đang xem YouTube mà có file gửi tới, một dòng thông báo hiện ở đầu màn hình; bấm **Super + Home** để nhận. Máy chủ tự tắt sau 10 phút không dùng (đang chia sẻ file thì giữ thêm tối đa 20 phút). Muốn PIN cố định cho mọi file (cả nhận lẫn tải): tạo file `~/.config/quickshell/share.pin`. Tường lửa: `install.sh` đã mở cổng 8765-8774/tcp cho ufw và firewalld.

## Chiếu Android không dây (scrcpy)

Ở thẻ **Truyền màn hình**, nhấn **W**. Bật **Gỡ lỗi không dây** trên điện thoại (Cài đặt, Tùy chọn nhà phát triển; Android 11 trở lên). Lần đầu: gõ `P`, nhập địa chỉ ghép nối (IP:cổng) và mã 6 số hiện trên điện thoại, rồi nhập địa chỉ kết nối ở màn hình chính "Gỡ lỗi không dây". Lần sau máy tự tìm lại (mDNS hoặc địa chỉ lần trước). Khi máy lấy internet từ điện thoại qua cáp USB, địa chỉ điện thoại được điền sẵn, bạn chỉ gõ cổng. Nhấn **S** nếu muốn dùng cáp USB + Gỡ lỗi USB. scrcpy luôn cần một dạng gỡ lỗi, không có cách chiếu toàn màn hình hoàn toàn không gỡ lỗi.

## Tự cập nhật TV bằng update.zip

Gửi file tên đúng **update.zip** từ điện thoại. TV chỉ ghi đè những file **thật sự khác** bản đang chạy; zip không có file nào thay đổi thì bị từ chối và không ghi đè gì. Chỉ khi zip có ít nhất một file hệ thống thay đổi, điện thoại mới phải nhập **mã cập nhật** đang hiện trên màn hình TV (mã 6 số, dùng một lần, nhập sai 5 lần bị khoá 1 phút). Sau đó TV tự làm:

1. Kiểm tra zip: không lỗi, không đường dẫn `..`/tuyệt đối, không symlink, nhỏ hơn 50 MB.
2. Giải nén và kiểm tra từng file: `shell.qml` (có ShellRoot, ngoặc cân), `*.sh` (cú pháp sh), `share.py` (biên dịch được), `tv.lua` (nếu có `luac`).
3. Sao lưu bản hiện tại vào `~/.local/state/arch-tv/backups` (giữ 5 bản).
4. Thay file, khởi động lại giao diện. Nếu bản mới không chạy được trong 20 giây, **tự khôi phục bản cũ** và báo lỗi.

Zip chỉ cần chứa các file cần đổi (ở gốc hoặc trong một thư mục con): `shell.qml`, `share.py`, `tv-update.sh`, `tv.lua` (khối cấu hình Hyprland), và tuỳ chọn `VERSION`. File khác bị bỏ qua. Khôi phục tay: `~/.config/quickshell/tv-update.sh rollback`.
