// ~/.config/quickshell/shell.qml
// Arch TV v2 — giao diện Smart TV cho Hyprland, điều khiển hoàn toàn bằng phím.
import QtQuick
import QtQuick.Shapes
import Quickshell
import Quickshell.Io
import Quickshell.Wayland

ShellRoot {
    id: root

    // ───────── Trạng thái ─────────
    property bool shown: true
    property bool powerArmed: false
    property bool showHelp: false
    property string toastText: ""
    property int current: 0
    property bool hintsOn: false
    property string hintKind: "yt"
    readonly property string home: Quickshell.env("HOME")

    Component.onCompleted: bootProc.running = true

    // ───────── Ứng dụng (sửa ở đây) ─────────
    readonly property string tvUA: "Mozilla/5.0 (Linux; Android 12) Cobalt/22.2.3-gold (PS4)"
    readonly property string browser: "chromium"

    readonly property var apps: [
        {
            title: "YouTube", kind: "yt", accent: "#ff3b3b", c1: "#3d0f15", c2: "#140608",
            desc: "Xem video trên màn hình lớn.\nMũi tên di chuyển, Enter chọn, Esc quay lại.",
            cmd: root.browser + " --kiosk --ozone-platform=wayland --user-data-dir=$HOME/.cache/tv-youtube"
                 + " --user-agent='" + root.tvUA + "' --autoplay-policy=no-user-gesture-required"
                 + " --enable-features=VaapiVideoDecodeLinuxGL 'https://www.youtube.com/tv'"
        },
        {
            title: "YouTube Music", kind: "ym", accent: "#ff7a3b", c1: "#3d1c0e", c2: "#150a06",
            desc: "Nghe nhạc, playlist và các mix\ndành riêng cho bạn.",
            cmd: root.browser + " --kiosk --ozone-platform=wayland --user-data-dir=$HOME/.cache/tv-youtube"
                 + " --user-agent='" + root.tvUA + "' 'https://www.youtube.com/tv#/browse?c=FEmusic_home'"
        },
        {
            title: "Trình duyệt", kind: "web", accent: "#4aa3ff", c1: "#0e2c4a", c2: "#07111e",
            desc: "Duyệt web toàn màn hình.",
            cmd: root.browser + " --ozone-platform=wayland --start-fullscreen"
        },
        {
            title: "Wi-Fi", kind: "wifi", accent: "#3fd1a0", c1: "#0d3d30", c2: "#07150f",
            desc: "Quét mạng, chọn Wi-Fi và nhập mật khẩu\nbằng bàn phím ảo.",
            page: "wifi",
            cmd: ""
        },
        {
            title: "Truyền màn hình", kind: "cast", accent: "#b48cff", c1: "#2a1a4d", c2: "#0f0a1d",
            desc: "Chiếu màn hình iPhone, iPad, Mac (AirPlay)\nhoặc điện thoại Android (cáp USB) lên TV.",
            page: "cast",
            cmd: ""
        },
        {
            title: "Chia sẻ file", kind: "share", accent: "#ff8fb0", c1: "#4a1a2e", c2: "#180a10",
            desc: "Nhận và gửi file với điện thoại\nqua Wi-Fi hoặc cáp USB. Tab để đổi Nhận / Gửi.",
            page: "share",
            cmd: ""
        },
        {
            title: "Tắt máy", kind: "power", accent: "#d8b46a", c1: "#3d3114", c2: "#15110a",
            desc: "Tắt máy tính.\nNhấn Enter hai lần để xác nhận.",
            danger: true,
            cmd: "systemctl poweroff"
        }
    ]

    // Màu nhấn đổi mượt theo ứng dụng đang chọn
    property color accent: apps[current].accent
    Behavior on accent { ColorAnimation { duration: 650; easing.type: Easing.InOutQuad } }

    // ───────── IPC: qs ipc call tv toggle ─────────
    IpcHandler {
        target: "tv"
        function toggle(): void { root.shown = !root.shown }
        function show(): void { root.shown = true }
        function hide(): void { root.shown = false }
        function hints(): void { root.hintsOn = !root.hintsOn; if (root.hintsOn) hintTimer.restart() }
    }

    // ───────── Logic ─────────
    function move(d) {
        current = Math.max(0, Math.min(apps.length - 1, current + d))
        powerArmed = false
    }

    function notify(t, ms) {
        toastText = t
        toastTimer.interval = ms || 1800
        toastTimer.restart()
    }

    function launch() {
        const a = apps[current]
        if (a.page === "wifi") { openWifi(); return }
        if (a.page === "cast") { castMsg = ""; page = "cast"; return }
        if (a.page === "share") { openShare(); return }
        if (a.danger && !powerArmed) {
            powerArmed = true
            armTimer.restart()
            notify("Nhấn Enter lần nữa để tắt máy")
            return
        }
        Quickshell.execDetached(["sh", "-c", a.cmd])
        if (!a.danger) {
            launchedAt = Date.now()
            appSeen = false
            hintKind = a.kind
            hintsOn = true
            hintTimer.restart()
            hideTimer.restart()
        }
    }

    function volume(args) {
        Quickshell.execDetached(["wpctl"].concat(args))
        volDelay.restart()
    }

    Process {
        id: volProc
        command: ["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"]
        stdout: StdioCollector {
            onStreamFinished: {
                const m = text.match(/([0-9.]+)/)
                const v = m ? Math.round(parseFloat(m[1]) * 100) : 0
                root.notify(text.indexOf("MUTED") !== -1 ? "Đã tắt tiếng" : "Âm lượng   " + v + "%")
            }
        }
    }
    Timer { id: volDelay; interval: 120; onTriggered: volProc.running = true }
    Timer { id: toastTimer; interval: 1800; onTriggered: root.toastText = "" }
    Timer { id: armTimer; interval: 3000; onTriggered: root.powerArmed = false }
    Timer { id: hideTimer; interval: 350; onTriggered: root.shown = false }
    Timer { id: hintTimer; interval: 20000; onTriggered: root.hintsOn = false }

    // ───────── Tự hiện lại launcher khi ứng dụng đã đóng ─────────
    // (launcher không có nút thoát: nó chỉ ẩn khi mở app và tự quay lại khi app tắt)
    property real launchedAt: 0
    property bool appSeen: false

    function onClients(n) {
        if (page === "cast" && shown && n > 0) {
            appSeen = true
            hintKind = "cast"
            hintsOn = true
            hintTimer.restart()
            shown = false
            return
        }
        if (n > 0) appSeen = true
        else if (appSeen || Date.now() - launchedAt > 25000) {
            appSeen = false
            shown = true
        }
    }
    Process {
        id: clientsProc
        command: ["hyprctl", "clients", "-j"]
        stdout: StdioCollector {
            onStreamFinished: {
                var n = 0
                try { n = JSON.parse(text).length } catch (err) { n = 0 }
                root.onClients(n)
            }
        }
    }
    Timer {
        interval: 1200; repeat: true; running: !root.shown || (root.page === "cast" && (root.castOn || scrProc.running))
        onTriggered: if (!clientsProc.running) clientsProc.running = true
    }

    // ───────── Wi-Fi ─────────
    property string page: "home"      // home | wifi
    property string wStep: "list"     // list | pass | busy
    property var nets: []
    property var saved: ({})
    property int netIndex: 0
    property bool scanning: false
    property string wifiCur: ""
    property string wTarget: ""
    property bool wNew: false
    property bool connWithPw: false
    property string wMsg: ""
    property bool wMsgBad: false
    property string pw: ""
    property bool showPw: false
    property int kbLayer: 0           // 0 thường | 1 HOA | 2 ký hiệu
    property int kr: 1
    property int kc: 0

    function splitNm(line) {
        var out = [], cur = ""
        for (var i = 0; i < line.length; i++) {
            var ch = line[i]
            if (ch === "\\" && i + 1 < line.length) { cur += line[i + 1]; i++ }
            else if (ch === ":") { out.push(cur); cur = "" }
            else cur += ch
        }
        out.push(cur)
        return out
    }

    function openWifi() {
        page = "wifi"; wStep = "list"; wMsg = ""; netIndex = 0
        refreshWifi()
    }
    function refreshWifi() {
        if (scanning) return
        scanning = true
        savedProc.running = true
    }

    Process {
        id: savedProc
        command: ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"]
        stdout: StdioCollector {
            onStreamFinished: {
                var m = {}
                var lines = text.split("\n")
                for (var i = 0; i < lines.length; i++) {
                    if (!lines[i]) continue
                    var f = root.splitNm(lines[i])
                    if (f[1] === "802-11-wireless") m[f[0]] = true
                }
                root.saved = m
                scanProc.running = true
            }
        }
    }
    Process {
        id: scanProc
        command: ["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", "yes"]
        stdout: StdioCollector {
            onStreamFinished: {
                var map = {}
                var lines = text.split("\n")
                for (var i = 0; i < lines.length; i++) {
                    if (!lines[i]) continue
                    var f = root.splitNm(lines[i])
                    var ssid = f[1]
                    if (!ssid) continue
                    var sig = parseInt(f[2]) || 0
                    var sec = f[3] || ""
                    var item = { ssid: ssid, signal: sig, secure: (sec !== "" && sec !== "--"), active: f[0] === "*" }
                    var o = map[ssid]
                    if (!o || item.active || (!o.active && sig > o.signal)) map[ssid] = item
                }
                var arr = Object.keys(map).map(function (k) { return map[k] })
                arr.sort(function (a, b) { return ((b.active ? 1 : 0) - (a.active ? 1 : 0)) || (b.signal - a.signal) })
                root.nets = arr
                root.wifiCur = ""
                for (var j = 0; j < arr.length; j++) if (arr[j].active) root.wifiCur = arr[j].ssid
                if (root.netIndex >= arr.length) root.netIndex = Math.max(0, arr.length - 1)
            }
        }
        onExited: root.scanning = false
    }
    Timer { id: scanGuard; interval: 25000; running: root.scanning; onTriggered: root.scanning = false }
    Timer { id: forgetTimer; interval: 700; onTriggered: root.refreshWifi() }

    Process {
        id: connProc
        onExited: (code, status) => {
            if (code === 0) {
                root.wMsg = "Đã kết nối " + root.wTarget
                root.wMsgBad = false
                root.pw = ""
                root.wStep = "list"
                root.refreshWifi()
            } else {
                root.wMsgBad = true
                if (root.connWithPw) {
                    Quickshell.execDetached(["nmcli", "connection", "delete", "id", root.wTarget])
                    root.wMsg = "Sai mật khẩu hoặc không kết nối được. Thử lại."
                    root.wStep = "pass"
                } else {
                    root.wMsg = "Không kết nối được. Nhấn F để quên mạng rồi nhập lại mật khẩu."
                    root.wStep = "list"
                }
            }
        }
    }

    function connectTo(n) {
        wTarget = n.ssid
        wMsg = ""
        if (n.active) { wMsg = "Bạn đang kết nối mạng này"; wMsgBad = false; return }
        if (saved[n.ssid] || !n.secure) doConnect(false)
        else { pw = ""; showPw = false; kbLayer = 0; kr = 1; kc = 0; wStep = "pass" }
    }
    function doConnect(withPw) {
        connWithPw = withPw
        wStep = "busy"
        if (withPw) connProc.command = ["nmcli", "-w", "25", "dev", "wifi", "connect", wTarget, "password", pw]
        else if (saved[wTarget]) connProc.command = ["nmcli", "-w", "25", "connection", "up", "id", wTarget]
        else connProc.command = ["nmcli", "-w", "25", "dev", "wifi", "connect", wTarget]
        connProc.running = true
    }
    function submitPw() {
        if (pw.length < 8) { wMsg = "Mật khẩu Wi-Fi cần ít nhất 8 ký tự"; wMsgBad = true; return }
        wMsg = ""
        doConnect(true)
    }
    function forgetNet() {
        if (nets.length === 0) return
        var n = nets[netIndex]
        if (!saved[n.ssid]) { wMsg = "Mạng này chưa được lưu"; wMsgBad = true; return }
        Quickshell.execDetached(["nmcli", "connection", "delete", "id", n.ssid])
        wMsg = "Đã quên mạng " + n.ssid; wMsgBad = false
        forgetTimer.restart()
    }

    // ───────── Bàn phím ảo ─────────
    function chars(s) {
        var o = []
        for (var i = 0; i < s.length; i++) o.push({ l: s[i], a: "ch", c: s[i], w: 1 })
        return o
    }
    function kbRows() {
        var rows = []
        if (kbLayer === 2) {
            rows.push(chars("1234567890"))
            rows.push(chars("!@#$%^&*()"))
            rows.push(chars("-_=+/:;.,'"))
            rows.push(chars("[]{}<>~`|\\").concat([{ l: "Xóa", a: "bs", w: 1.6 }]))
        } else {
            var base = kbLayer === 1 ? ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]
                                     : ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
            rows.push(chars("1234567890"))
            rows.push(chars(base[0]))
            rows.push(chars(base[1]))
            rows.push([{ l: "Aa", a: "shift", w: 1.6 }].concat(chars(base[2]), [{ l: "Xóa", a: "bs", w: 1.6 }]))
        }
        rows.push([
            { l: kbLayer === 2 ? "abc" : "?123", a: "sym", w: 1.6 },
            { l: showPw ? "Ẩn" : "Hiện", a: "eye", w: 1.6 },
            { l: "Dấu cách", a: "ch", c: " ", w: 3.4 },
            { l: ".", a: "ch", c: ".", w: 1 },
            { l: "@", a: "ch", c: "@", w: 1 },
            { l: "Kết nối", a: "go", w: 2.4 }
        ])
        return rows
    }
    function pressKey(k) {
        if (!k) return
        if (k.a === "ch") { pw += k.c; if (kbLayer === 1) kbLayer = 0 }
        else if (k.a === "bs") pw = pw.slice(0, -1)
        else if (k.a === "shift") kbLayer = (kbLayer === 1) ? 0 : 1
        else if (k.a === "sym") kbLayer = (kbLayer === 2) ? 0 : 2
        else if (k.a === "eye") showPw = !showPw
        else if (k.a === "go") submitPw()
        var r = kbRows()
        kc = Math.min(kc, r[kr].length - 1)
    }

    function wifiKey(e) {
        var k = e.key
        if (wStep === "busy") return
        if (wStep === "list") {
            if (k === Qt.Key_Up || k === Qt.Key_K) netIndex = Math.max(0, netIndex - 1)
            else if (k === Qt.Key_Down || k === Qt.Key_J) netIndex = Math.min(Math.max(0, nets.length - 1), netIndex + 1)
            else if (k === Qt.Key_Return || k === Qt.Key_Enter || k === Qt.Key_Space) { if (nets.length > 0) connectTo(nets[netIndex]) }
            else if (k === Qt.Key_R) refreshWifi()
            else if (k === Qt.Key_F) forgetNet()
            else if (k === Qt.Key_Escape || k === Qt.Key_Backspace) page = "home"
            return
        }
        // nhập mật khẩu
        var rows = kbRows()
        if (k === Qt.Key_Escape) { wStep = "list"; pw = ""; wMsg = ""; return }
        if (k === Qt.Key_Left) kc = Math.max(0, kc - 1)
        else if (k === Qt.Key_Right) kc = Math.min(rows[kr].length - 1, kc + 1)
        else if (k === Qt.Key_Up) { kr = Math.max(0, kr - 1); kc = Math.min(kc, rows[kr].length - 1) }
        else if (k === Qt.Key_Down) { kr = Math.min(rows.length - 1, kr + 1); kc = Math.min(kc, rows[kr].length - 1) }
        else if ((k === Qt.Key_Return || k === Qt.Key_Enter) && (e.modifiers & Qt.ControlModifier)) submitPw()
        else if (k === Qt.Key_Return || k === Qt.Key_Enter) pressKey(rows[kr][kc])
        else if (k === Qt.Key_Backspace) pw = pw.slice(0, -1)
        else if (e.text.length === 1 && e.text.charCodeAt(0) >= 32 && !(e.modifiers & Qt.ControlModifier)) pw += e.text
    }

    // ───────── Truyền màn hình ─────────
    property bool castOn: false
    property string castMsg: ""
    readonly property string castName: "Arch TV"
    readonly property string castPw: ""     // đặt mật khẩu AirPlay ở đây nếu muốn (để trống = không cần)

    Process {
        id: castProc
        running: root.castOn
        command: ["sh", "-c", "exec uxplay -n '" + root.castName + "' -nh -fs"
                              + (root.castPw !== "" ? " -pw '" + root.castPw + "'" : "")]
        onExited: (code, status) => {
            if (root.castOn) {
                root.castOn = false
                if (code === 127) root.castMsg = "Chưa cài UxPlay. Hãy chạy lại install.sh"
                else if (code !== 0 && code !== 143) root.castMsg = "AirPlay dừng bất thường (mã " + code + ")"
            }
        }
    }
    property string scrSerial: ""          // "" = cáp USB; khác rỗng = máy đã kết nối không dây
    property string castAsk: ""            // "" | connect | pair | code  (đang chờ bạn gõ)
    property string castInput: ""
    property string castHint: ""
    property string castPairAddr: ""
    property bool castGot: false
    Process {
        id: scrProc
        command: ["sh", "-c", "exec scrcpy --fullscreen --stay-awake"
                              + (root.scrSerial !== "" ? " -s '" + root.scrSerial + "'" : "")]
        onExited: (code, status) => {
            if (code === 127) root.castMsg = "Chưa cài scrcpy. Hãy chạy lại install.sh"
            else if (code !== 0) root.castMsg = root.scrSerial !== ""
                ? "scrcpy dừng (mã " + code + "). Kiểm tra điện thoại còn bật Gỡ lỗi không dây, rồi nhấn W."
                : "Không thấy điện thoại Android. Bật Gỡ lỗi USB, cắm cáp và chấp nhận trên điện thoại."
            else root.castMsg = ""
        }
    }
    // Kết nối không dây: android-cast.sh in từng dòng STEP|… HINT|… NEED|… OK|… ERR|…
    Process {
        id: adbProc
        stdout: SplitParser { onRead: data => root.castLine(data) }
        onExited: (code, status) => {
            if (!root.castGot && root.castAsk === "" && !scrProc.running)
                root.castMsg = "Không chạy được android-cast.sh (kiểm tra file có trong ~/.config/quickshell, chạy lại install.sh)"
        }
    }
    function castRun(args) {
        castGot = false
        adbProc.running = false
        adbProc.command = ["sh", tvDir + "/android-cast.sh"].concat(args)
        adbProc.running = true
    }
    function castLine(l) {
        castGot = true
        const p = l.split("|")
        if (p[0] === "STEP") castMsg = p.slice(1).join("|")
        else if (p[0] === "HINT") castHint = p[1] || ""
        else if (p[0] === "NEED") {
            castMsg = ""
            if (p[1] === "pair") { castAsk = "pair"; castInput = castHint !== "" ? castHint + ":" : "" }
            else { castAsk = "connect"; castInput = castHint !== "" ? castHint + ":" : "" }
        } else if (p[0] === "OK") {
            const serial = (p[1] || "").replace(/[^0-9A-Za-z.:_-]/g, "")
            castMsg = "Đã kết nối " + serial + ", đang mở scrcpy…"
            scrSerial = serial
            launchedAt = Date.now()
            scrProc.running = true
        } else if (p[0] === "ERR") castMsg = p.slice(1).join("|")
    }

    function toggleCast() {
        castMsg = ""
        castOn = !castOn
    }
    function startScrcpy() {                 // cáp USB
        if (scrProc.running) return
        castMsg = "Đang tìm điện thoại Android…"
        scrSerial = ""
        launchedAt = Date.now()
        scrProc.running = true
    }
    function startWireless() {               // không dây (Gỡ lỗi không dây)
        if (scrProc.running || adbProc.running) return
        castMsg = "Đang tìm điện thoại Android…"
        castHint = ""
        castRun(["auto"])
    }
    function castAskKey(e) {
        var k = e.key
        if (k === Qt.Key_Escape) { castAsk = ""; castMsg = ""; return }
        if (k === Qt.Key_Backspace) { castInput = castInput.slice(0, -1); return }
        if (k === Qt.Key_Return || k === Qt.Key_Enter) {
            const v = castInput.trim()
            const addrOk = /^[0-9A-Za-z.\-]+:[0-9]{2,5}$/.test(v)
            if (castAsk === "connect") {
                if (v.toLowerCase() === "p") { castAsk = "pair"; castInput = castHint !== "" ? castHint + ":" : ""; castMsg = ""; return }
                if (!addrOk) { castMsg = "Địa chỉ phải dạng IP:cổng, ví dụ 192.168.42.129:37123"; return }
                castAsk = ""; castMsg = "Đang kết nối…"; castRun(["connect", v])
            } else if (castAsk === "pair") {
                if (!addrOk) { castMsg = "Địa chỉ phải dạng IP:cổng, ví dụ 192.168.42.129:41234"; return }
                castPairAddr = v; castAsk = "code"; castInput = ""; castMsg = ""
            } else if (castAsk === "code") {
                if (!/^[0-9]{6}$/.test(v)) { castMsg = "Mã ghép nối gồm đúng 6 chữ số"; return }
                castAsk = ""; castMsg = "Đang ghép nối…"; castRun(["pair", castPairAddr, v])
            }
            return
        }
        if (e.text.length === 1 && /[0-9A-Za-z.:\-]/.test(e.text) && castInput.length < 40) castInput += e.text
    }
    function castKey(e) {
        var k = e.key
        if (castAsk !== "") { castAskKey(e); return }
        if (k === Qt.Key_Return || k === Qt.Key_Enter || k === Qt.Key_Space) toggleCast()
        else if (k === Qt.Key_S) startScrcpy()
        else if (k === Qt.Key_W) startWireless()
        else if (k === Qt.Key_Escape || k === Qt.Key_Backspace) { castOn = false; castMsg = ""; page = "home" }
    }

    // ───────── Nhận file từ điện thoại + tự cập nhật TV (share.py, tv-update.sh) ─────────
    readonly property string shareDir: home + "/Downloads"
    readonly property string shareInbox: home + "/.cache/arch-tv/share-inbox"
    readonly property string tvDir: home + "/.config/quickshell"
    readonly property string updateScript: tvDir + "/tv-update.sh"
    property bool shareOn: false
    property bool shareUp: false
    property string shareUrl: ""
    property var shareQr: []
    property var shareQrCells: []          // [[x, y], ...] các ô tối của mã QR
    property bool sharePin: false
    property string updPin: ""
    property string shareNote: ""
    property var sharePending: []          // [{batch, path, dir, name, size, img, from, dev}]
    property int shareSel: 0
    property string shareTab: "recv"       // recv (nhận) | send (gửi)
    property bool shareUsb: false          // địa chỉ đang hiện là của cổng USB (điện thoại cắm cáp)
    property string shareIface: ""
    property var shareUrls: []
    property var sendList: []              // [{id, path, name, size, dl}] file đang chia sẻ cho điện thoại
    property int sendSel: 0
    property string sendMsg: ""
    property bool sendMsgBad: false
    property int shareIdleExtra: 0
    property bool browseOpen: false
    property string browseDir: ""
    property bool browseHidden: false
    property var browseItems: []
    property int browseSel: 0
    property string shareMsg: ""
    property bool shareMsgBad: false
    property string noticeText: ""
    property var shareFinBatches: []
    property bool shareFinSave: false
    // cập nhật: "" | run | apply | error
    property string updState: ""
    property var updSteps: []
    property string updText: ""
    property string updVer: ""
    property string updBatch: ""
    property string updDir: ""

    function openShare() {
        shareMsg = ""; shareSel = 0; page = "share"
        shareSetOn(true)
    }
    function shareSetOn(on) {
        shareOn = on
        if (on) { shareIdle.restart(); if (!shareProc.running) shareProc.running = true }
        else { shareIdle.stop(); shareRestart.stop(); shareProc.running = false; shareUp = false }
    }

    function fmtBytes(n) {
        n = Number(n) || 0
        if (n < 1024) return n + " B"
        if (n < 1048576) return (n / 1024).toFixed(1) + " KB"
        if (n < 1073741824) return (n / 1048576).toFixed(1) + " MB"
        return (n / 1073741824).toFixed(2) + " GB"
    }
    function fileIcon(name) {
        const m = /\.([A-Za-z0-9]+)$/.exec(name || "")
        const e = m ? m[1].toLowerCase() : ""
        if (e === "pdf") return "📕"
        if (["doc", "docx", "odt", "rtf"].indexOf(e) >= 0) return "📘"
        if (["xls", "xlsx", "ods", "csv"].indexOf(e) >= 0) return "📗"
        if (["ppt", "pptx", "odp"].indexOf(e) >= 0) return "📙"
        if (["txt", "md", "log"].indexOf(e) >= 0) return "📝"
        if (["zip", "rar", "7z", "tar", "gz", "xz"].indexOf(e) >= 0) return "🗜"
        if (["mp4", "mkv", "mov", "avi", "webm"].indexOf(e) >= 0) return "🎞"
        if (["mp3", "wav", "flac", "ogg", "m4a", "aac"].indexOf(e) >= 0) return "🎵"
        if (["png", "jpg", "jpeg", "webp", "gif", "bmp", "heic"].indexOf(e) >= 0) return "🖼"
        if (e === "apk") return "🤖"
        return "📄"
    }

    function shareEvent(line) {
        let o
        try { o = JSON.parse(line) } catch (e) { return }
        shareIdle.restart()
        shareIdleExtra = 0
        if (o.ev === "ready" || o.ev === "net") {
            shareUp = true
            shareUrl = o.url || ""
            shareQr = o.qr || []
            const cells = []
            shareQr.forEach((row, y) => { for (let x = 0; x < row.length; x++) if (row[x] === "1") cells.push([x, y]) })
            shareQrCells = cells
            sharePin = !!o.pin
            updPin = o.updpin || ""
            shareNote = ""
            shareUsb = !!o.usb
            shareUrls = o.urls || []
            const usbIf = (o.ifaces || []).filter(i => i.usb)
            shareIface = usbIf.length > 0 ? usbIf[0].iface : ""
            // máy chủ vừa (khởi động lại) chạy: đăng ký lại các file đang chia sẻ
            if (o.ev === "ready") sendList.forEach(f => shareProc.write("offer " + f.path + "\n"))
        } else if (o.ev === "offer") {
            let hit = sendList.findIndex(f => f.id === o.id || f.path === o.path)
            if (hit < 0) hit = sendList.findIndex(f => f.id === "" && f.name === o.name)
            const item = { id: o.id, path: o.path, name: o.name, size: o.size, dl: o.dl || 0 }
            if (hit >= 0) { const l = sendList.slice(); l[hit] = item; sendList = l }
            else sendList = sendList.concat([item])
        } else if (o.ev === "unoffer") {
            const gone = sendList.find(f => f.id === o.id)
            sendList = sendList.filter(f => f.id !== o.id)
            sendSel = Math.max(0, Math.min(sendSel, sendList.length - 1))
            if (o.msg && gone) { sendMsg = o.msg + ": " + gone.name; sendMsgBad = true }
        } else if (o.ev === "offer_err") {
            sendList = sendList.filter(f => f.id !== "" || (o.msg || "").indexOf(f.name) < 0)
            sendSel = Math.max(0, Math.min(sendSel, sendList.length - 1))
            sendMsg = o.msg || "Không gửi được file"; sendMsgBad = true
        } else if (o.ev === "sent") {
            sendList = sendList.map(f => f.id === o.id ? Object.assign({}, f, { dl: o.dl }) : f)
            const who = o.dev ? o.dev : o.from
            sendMsg = "✓  " + who + " đã tải " + o.name; sendMsgBad = false
            if (!shown) { noticeText = "📤  " + who + " đã tải " + o.name; noticeTimer.restart() }
            else notify("📤  " + who + " đã tải " + o.name, 4000)
        } else if (o.ev === "pin") {
            updPin = o.updpin || ""
        } else if (o.ev === "file") {
            if (o.upd) { startUpdate(o); return }
            sharePending = sharePending.concat([{ batch: o.batch, path: o.path, dir: o.dir, name: o.name, size: o.size,
                                                  img: !!o.img, from: o.from, dev: o.dev || "" }])
            if (!shown) {
                noticeText = "📲  Nhận " + sharePending.length + " file từ " + (o.dev || o.from) + "  ·  nhấn Super+Home để nhận"
                noticeTimer.restart()
            } else if (page === "home") page = "share"
        } else if (o.ev === "error") {
            shareNote = o.msg || "Lỗi máy chủ nhận file"
        }
    }

    function shareFinish(save, all) {
        if (sharePending.length === 0 || shareFinProc.running || updState !== "") return
        const items = all ? sharePending : [sharePending[Math.min(shareSel, sharePending.length - 1)]]
        const rest = sharePending.filter(i => items.indexOf(i) < 0)
        const keep = {}
        rest.forEach(i => keep[i.batch] = true)
        const done = {}
        items.forEach(i => { if (!keep[i.batch]) done[i.batch] = true })
        shareFinBatches = Object.keys(done)
        shareFinSave = save
        shareFinProc.command = ["sh", "-c", shareFinScript, "sh", save ? "save" : "skip", shareDir, shareInbox]
                               .concat(items.map(i => i.path))
        sharePending = rest
        shareSel = Math.max(0, Math.min(shareSel, rest.length - 1))
        shareFinProc.running = true
    }
    readonly property string shareFinScript:
        'mode="$1"; dest="$2"; inbox="$3"; shift 3\n' +
        '[ "$mode" = save ] && mkdir -p "$dest"\n' +
        'n=0\n' +
        'for f in "$@"; do\n' +
        '  d=$(dirname "$f")\n' +
        '  case "$d" in "$inbox"/*) ;; *) continue ;; esac\n' +
        '  [ -f "$f" ] || continue\n' +
        '  if [ "$mode" = save ]; then\n' +
        '    b=$(basename "$f"); stem="${b%.*}"; ext="${b##*.}"; t="$dest/$b"; i=1\n' +
        '    while [ -e "$t" ]; do\n' +
        '      if [ "$stem" = "$b" ]; then t="$dest/$b-$i"; else t="$dest/$stem-$i.$ext"; fi\n' +
        '      i=$((i+1))\n' +
        '    done\n' +
        '    mv "$f" "$t" && n=$((n+1))\n' +
        '  else rm -f "$f"; n=$((n+1)); fi\n' +
        '  rmdir "$d" 2>/dev/null\n' +
        'done\n' +
        'echo "$n"\n'

    function shareKey(e) {
        var k = e.key
        if (updState !== "") {
            if (updState === "error" && (k === Qt.Key_Return || k === Qt.Key_Enter || k === Qt.Key_Escape || k === Qt.Key_Space)) {
                updState = ""; updSteps = []; updText = ""
            }
            return
        }
        if (k === Qt.Key_Tab || k === Qt.Key_Backtab) {
            shareTab = shareTab === "recv" ? "send" : "recv"; browseOpen = false
            if (shareTab === "send" && !shareOn) shareSetOn(true)
            return
        }
        if (shareTab === "send") { sendKey(e); return }
        if (k === Qt.Key_Right) { shareTab = "send"; return }
        var n = sharePending.length
        if (k === Qt.Key_Up || k === Qt.Key_K) shareSel = Math.max(0, shareSel - 1)
        else if (k === Qt.Key_Down || k === Qt.Key_J) shareSel = Math.min(Math.max(0, n - 1), shareSel + 1)
        else if (k === Qt.Key_Return || k === Qt.Key_Enter || k === Qt.Key_Space) shareFinish(true, false)
        else if (k === Qt.Key_A) shareFinish(true, true)
        else if (k === Qt.Key_D || k === Qt.Key_Delete || k === Qt.Key_X) shareFinish(false, false)
        else if (k === Qt.Key_T) { shareSetOn(!shareOn); shareMsg = shareOn ? "" : "Đã tắt nhận file"; shareMsgBad = false }
        else if (k === Qt.Key_Escape || k === Qt.Key_Backspace) page = "home"
    }

    // ── Gửi file từ máy sang điện thoại ──
    function sendAdd(path) {
        if (!path || path.indexOf("\n") >= 0) return
        const name = path.split("/").pop()
        if (sendList.some(f => f.path === path)) { sendMsg = "Đã có trong danh sách: " + name; sendMsgBad = false; return }
        sendList = sendList.concat([{ id: "", path: path, name: name, size: 0, dl: 0 }])
        sendMsg = "Đã thêm " + name; sendMsgBad = false
        if (shareUp && shareProc.running) shareProc.write("offer " + path + "\n")
        else shareSetOn(true)                    // khi máy chủ sẵn sàng, "ready" sẽ đăng ký cả danh sách
    }
    function sendRemove(i) {
        const f = sendList[i]
        if (!f) return
        if (f.id !== "" && shareProc.running) shareProc.write("unoffer " + f.id + "\n")
        sendList = sendList.filter((x, k) => k !== i)
        sendSel = Math.max(0, Math.min(sendSel, sendList.length - 1))
        sendMsg = "Đã ngừng chia sẻ " + f.name; sendMsgBad = false
    }
    function sendClear() {
        if (shareProc.running) shareProc.write("unofferall\n")
        sendList = []; sendSel = 0
        sendMsg = "Đã ngừng chia sẻ tất cả"; sendMsgBad = false
    }
    function sendKey(e) {
        var k = e.key
        if (browseOpen) { browseKey(k); return }
        var n = sendList.length
        if (k === Qt.Key_Up || k === Qt.Key_K) sendSel = Math.max(0, sendSel - 1)
        else if (k === Qt.Key_Down || k === Qt.Key_J) sendSel = Math.min(Math.max(0, n - 1), sendSel + 1)
        else if (k === Qt.Key_Return || k === Qt.Key_Enter || k === Qt.Key_Space || k === Qt.Key_A) openBrowse()
        else if (k === Qt.Key_D || k === Qt.Key_Delete || k === Qt.Key_X) sendRemove(sendSel)
        else if (k === Qt.Key_C) sendClear()
        else if (k === Qt.Key_T) { shareSetOn(!shareOn); sendMsg = shareOn ? "" : "Đã tắt máy chủ chia sẻ"; sendMsgBad = false }
        else if (k === Qt.Key_Left) shareTab = "recv"
        else if (k === Qt.Key_Escape || k === Qt.Key_Backspace) page = "home"
    }

    // Trình chọn file bằng phím (thư mục hiện tại do `find` liệt kê)
    function openBrowse() {
        browseOpen = true
        browseOpenDir(browseDir !== "" ? browseDir : home + "/Downloads")
    }
    function browseOpenDir(d) {
        browseProc.running = false
        browseProc.command = ["sh", "-c",
            'cd "$1" 2>/dev/null || cd "$HOME"; printf "@%s\\n" "$(pwd -P)"\n' +
            'if [ "$2" = 1 ]; then find . -maxdepth 1 -mindepth 1 -printf "%Y\\t%s\\t%f\\n" 2>/dev/null\n' +
            'else find . -maxdepth 1 -mindepth 1 ! -name ".*" -printf "%Y\\t%s\\t%f\\n" 2>/dev/null; fi | head -n 800',
            "sh", d, browseHidden ? "1" : "0"]
        browseProc.running = true
    }
    function browseParse(text) {
        let dir = browseDir
        const items = []
        text.split("\n").forEach(l => {
            if (l === "") return
            if (l[0] === "@") { dir = l.slice(1); return }
            const p = l.split("\t")
            if (p.length < 3) return
            items.push({ dir: p[0] === "d", size: Number(p[1]) || 0, name: p.slice(2).join("\t"), up: false })
        })
        items.sort((a, b) => a.dir !== b.dir ? (a.dir ? -1 : 1) : a.name.toLowerCase().localeCompare(b.name.toLowerCase()))
        if (dir !== "/") items.unshift({ dir: true, size: 0, name: "..", up: true })
        browseDir = dir
        browseItems = items
        browseSel = items.length > 1 && items[0].up ? 1 : 0
    }
    function browseEnter() {
        const it = browseItems[browseSel]
        if (!it) return
        const base = browseDir === "/" ? "" : browseDir
        if (it.up) browseOpenDir(browseDir + "/..")
        else if (it.dir) browseOpenDir(base + "/" + it.name)
        else sendAdd(base + "/" + it.name)
    }
    function browseKey(k) {
        var n = browseItems.length
        if (k === Qt.Key_Up || k === Qt.Key_K) browseSel = Math.max(0, browseSel - 1)
        else if (k === Qt.Key_Down || k === Qt.Key_J) browseSel = Math.min(Math.max(0, n - 1), browseSel + 1)
        else if (k === Qt.Key_Return || k === Qt.Key_Enter || k === Qt.Key_Space || k === Qt.Key_Right || k === Qt.Key_L) browseEnter()
        else if (k === Qt.Key_Backspace || k === Qt.Key_Left) browseOpenDir(browseDir + "/..")
        else if (k === Qt.Key_Period) { browseHidden = !browseHidden; browseOpenDir(browseDir) }
        else if (k === Qt.Key_Home) browseOpenDir(home)
        else if (k === Qt.Key_Escape) browseOpen = false
    }
    Process {
        id: browseProc
        stdout: StdioCollector { onStreamFinished: root.browseParse(text) }
    }

    // ── Cập nhật từ update.zip ──
    function startUpdate(o) {
        if (updState !== "") { shareProc.write("skipped " + o.batch + "\n"); return }
        updState = "run"; updSteps = []; updText = ""; updVer = ""
        updBatch = o.batch; updDir = o.dir
        shown = true; page = "share"; hideTimer.stop()
        updProc.command = ["sh", updateScript, "prepare", o.path]
        updProc.running = true
    }
    function updLine(l) {
        var p = l.split("|")
        if (p[0] === "STEP") updSteps = updSteps.concat([p[1]])
        else if (p[0] === "OK") {
            updVer = p[1]; updState = "apply"
            shareProc.write("saved " + updBatch + "\n")
            updGo.start()
        } else if (p[0] === "ERR") {
            updState = "error"; updText = p.slice(1).join("|")
            shareProc.write("skipped " + updBatch + "\n")
        }
    }
    Process {
        id: updProc
        stdout: SplitParser { onRead: data => root.updLine(data) }
        onExited: {
            if (root.updDir !== "") Quickshell.execDetached(["rm", "-rf", root.updDir])
            if (root.updState === "run") { root.updState = "error"; root.updText = "Cập nhật dừng bất thường, chưa có gì bị thay đổi" }
        }
    }
    // Dừng 2,5 giây cho người xem đọc, rồi thay file + khởi động lại (chạy tách rời vì shell sẽ bị tắt)
    Timer { id: updGo; interval: 2500; onTriggered: Quickshell.execDetached(["setsid", "sh", root.updateScript, "apply"]) }

    // Khi shell vừa chạy: ghi "alive" (để trình cập nhật biết bản mới chạy được) và đọc ghi chú cập nhật
    Process {
        id: bootProc
        command: ["sh", "-c",
            'c="${XDG_CACHE_HOME:-$HOME/.cache}/arch-tv"; s="${XDG_STATE_HOME:-$HOME/.local/state}/arch-tv"\n' +
            'mkdir -p "$c" "$s"; date +%s > "$c/alive"\n' +
            'f="$s/update-note"; if [ -f "$f" ]; then cat "$f"; rm -f "$f"; fi; exit 0']
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim().split("|")
                if (p[0] === "ok") bootNote.text = "Đã cập nhật TV lên bản " + p[1]
                else if (p[0] === "rolled") bootNote.text = p[1] || "Cập nhật lỗi, đã khôi phục bản cũ"
                if (bootNote.text !== "") bootNote.start()
            }
        }
    }
    Timer { id: bootNote; property string text: ""; interval: 1500; onTriggered: root.notify(text, 6000) }

    Timer { id: noticeTimer; interval: 12000; onTriggered: root.noticeText = "" }
    Timer {
        id: shareIdle
        interval: 600000
        onTriggered: {
            if (root.sharePending.length > 0 || root.page === "share" || root.updState !== "") { restart(); return }
            // đang chia sẻ file cho điện thoại: giữ máy chủ thêm tối đa 2 × 10 phút không ai dùng
            if (root.sendList.length > 0 && root.shareIdleExtra < 2) { root.shareIdleExtra++; restart(); return }
            if (root.shareOn) root.shareSetOn(false)
        }
    }
    Timer { id: shareRestart; interval: 5000; onTriggered: if (root.shareOn && !shareProc.running) shareProc.running = true }
    Process {
        id: shareProc
        // Tìm share.py ở ~/.config/quickshell (mới) rồi ~/.config/quickshell/tv (bản cũ); thiếu thì báo lỗi rõ ràng
        command: ["sh", "-c",
            'mkdir -p "$1"; f="$2"; [ -f "$f" ] || f="$3"\n' +
            'command -v python3 >/dev/null 2>&1 || { echo \'{"ev":"error","msg":"Chưa cài python3 (sudo pacman -S python)"}\'; exit 127; }\n' +
            '[ -f "$f" ] || { echo \'{"ev":"error","msg":"Không thấy share.py trong ~/.config/quickshell. Hãy chạy install.sh hoặc chép share.py vào đó."}\'; exit 3; }\n' +
            'exec python3 "$f" --inbox "$1"',
            "sh", root.shareInbox, root.tvDir + "/share.py", root.tvDir + "/tv/share.py"]
        stdinEnabled: true
        stdout: SplitParser { onRead: data => root.shareEvent(data) }
        stderr: StdioCollector {
            onStreamFinished: if (!root.shareUp && text.trim() !== "")
                root.shareNote = "Máy chủ chia sẻ bị lỗi: " + text.trim().split("\n").slice(-2).join("  ")
        }
        onExited: (code, status) => {
            root.shareUp = false
            if (root.shareNote === "" && code !== 0 && code !== 143) root.shareNote = "Máy chủ chia sẻ dừng (mã " + code + ")"
            if (root.shareOn) shareRestart.start()
        }
    }
    Process {
        id: shareFinProc
        stdout: StdioCollector {
            onStreamFinished: {
                shareIdle.restart()
                const n = parseInt(text.trim()) || 0
                root.shareFinBatches.forEach(b => shareProc.write((root.shareFinSave ? "saved " : "skipped ") + b + "\n"))
                root.shareMsgBad = root.shareFinSave && n === 0
                root.shareMsg = root.shareFinSave ? (n > 0 ? "Đã lưu " + n + " file vào thư mục Downloads" : "Không lưu được file nào")
                                                  : "Đã bỏ qua " + n + " file"
            }
        }
    }
    IpcHandler {
        target: "share"
        function open(): void { root.shareTab = "recv"; root.openShare(); root.shown = true }
        // qs ipc call share sendpage   → mở thẳng tab Gửi
        function sendpage(): void { root.shareTab = "send"; root.openShare(); root.shown = true }
        // qs ipc call share send /đường/dẫn/file   → chia sẻ file đó cho điện thoại
        function send(path: string): void {
            root.shareTab = "send"; root.openShare(); root.shown = true
            root.sendAdd(path)
        }
    }

    SystemClock { id: clock; precision: SystemClock.Minutes }

    // ───────── Biểu tượng vẽ bằng vector ─────────
    component AppIcon: Canvas {
        id: cv
        property string kind: "yt"
        antialiasing: true
        onKindChanged: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()

        function rr(ctx, x, y, w, h, r) {
            ctx.beginPath()
            ctx.moveTo(x + r, y)
            ctx.lineTo(x + w - r, y)
            ctx.arcTo(x + w, y, x + w, y + r, r)
            ctx.lineTo(x + w, y + h - r)
            ctx.arcTo(x + w, y + h, x + w - r, y + h, r)
            ctx.lineTo(x + r, y + h)
            ctx.arcTo(x, y + h, x, y + h - r, r)
            ctx.lineTo(x, y + r)
            ctx.arcTo(x, y, x + r, y, r)
            ctx.closePath()
        }

        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            var s = Math.min(width, height) / 100
            ctx.scale(s, s)
            ctx.lineCap = "round"
            ctx.lineJoin = "round"

            if (kind === "yt") {
                var g = ctx.createLinearGradient(0, 22, 0, 78)
                g.addColorStop(0, "#ff4d4d")
                g.addColorStop(1, "#e01616")
                ctx.fillStyle = g
                rr(ctx, 5, 22, 90, 56, 17)
                ctx.fill()
                ctx.fillStyle = "#ffffff"
                ctx.strokeStyle = "#ffffff"
                ctx.lineWidth = 5
                ctx.beginPath()
                ctx.moveTo(42, 37); ctx.lineTo(42, 63); ctx.lineTo(65, 50)
                ctx.closePath()
                ctx.fill(); ctx.stroke()
            } else if (kind === "ym") {
                ctx.strokeStyle = "#ff6a3d"
                ctx.lineWidth = 7
                ctx.beginPath(); ctx.arc(50, 50, 41, 0, Math.PI * 2); ctx.stroke()
                ctx.fillStyle = "#ffffff"
                ctx.strokeStyle = "#ffffff"
                ctx.lineWidth = 5
                ctx.beginPath()
                ctx.moveTo(40, 33); ctx.lineTo(40, 67); ctx.lineTo(69, 50)
                ctx.closePath()
                ctx.fill(); ctx.stroke()
            } else if (kind === "web") {
                ctx.strokeStyle = "#7cc0ff"
                ctx.lineWidth = 5
                ctx.beginPath(); ctx.arc(50, 50, 40, 0, Math.PI * 2); ctx.stroke()
                ctx.beginPath(); ctx.ellipse(31, 10, 38, 80); ctx.stroke()
                ctx.beginPath(); ctx.moveTo(10, 50); ctx.lineTo(90, 50); ctx.stroke()
                ctx.beginPath(); ctx.moveTo(16, 30); ctx.lineTo(84, 30); ctx.stroke()
                ctx.beginPath(); ctx.moveTo(16, 70); ctx.lineTo(84, 70); ctx.stroke()
            } else if (kind === "wifi") {
                ctx.strokeStyle = "#5fe6b8"
                ctx.fillStyle = "#5fe6b8"
                ctx.lineWidth = 8
                var radii = [58, 39, 20]
                for (var i = 0; i < radii.length; i++) {
                    ctx.beginPath()
                    ctx.arc(50, 78, radii[i], -Math.PI * 0.76, -Math.PI * 0.24)
                    ctx.stroke()
                }
                ctx.beginPath(); ctx.arc(50, 78, 6, 0, Math.PI * 2); ctx.fill()
            } else if (kind === "cast") {
                ctx.strokeStyle = "#cdb6ff"
                ctx.fillStyle = "#cdb6ff"
                ctx.lineWidth = 7
                rr(ctx, 10, 20, 80, 56, 10)
                ctx.stroke()
                var cr = [14, 28, 42]
                for (var ci = 0; ci < cr.length; ci++) {
                    ctx.beginPath()
                    ctx.arc(24, 62, cr[ci], -Math.PI / 2, 0, false)
                    ctx.stroke()
                }
                ctx.beginPath(); ctx.arc(24, 62, 5, 0, Math.PI * 2); ctx.fill()
            } else if (kind === "share") {
                ctx.strokeStyle = "#ffa9c4"
                ctx.lineWidth = 6
                rr(ctx, 27, 6, 46, 66, 10)
                ctx.stroke()
                ctx.beginPath(); ctx.moveTo(50, 24); ctx.lineTo(50, 52); ctx.stroke()
                ctx.beginPath(); ctx.moveTo(37, 41); ctx.lineTo(50, 54); ctx.lineTo(63, 41); ctx.stroke()
                ctx.beginPath(); ctx.moveTo(18, 90); ctx.lineTo(82, 90); ctx.stroke()
            } else if (kind === "power") {
                ctx.strokeStyle = "#ecc87e"
                ctx.lineWidth = 8
                ctx.beginPath()
                ctx.arc(50, 54, 33, -Math.PI / 2 + 0.62, Math.PI * 1.5 - 0.62, false)
                ctx.stroke()
                ctx.beginPath(); ctx.moveTo(50, 10); ctx.lineTo(50, 48); ctx.stroke()
            }
        }
    }

    // ───────── Thành phần dùng chung ─────────
    component SignalBars: Item {
        id: sb
        property int level: 0
        property real s: 1
        width: 33 * s; height: 26 * s
        Repeater {
            model: 4
            Rectangle {
                required property int index
                x: index * 9 * sb.s
                width: 6 * sb.s
                height: (8 + index * 6) * sb.s
                y: sb.height - height
                radius: 2 * sb.s
                color: index < sb.level ? "#f4efe3" : "#33ffffff"
            }
        }
    }

    component LockIcon: Item {
        id: lk
        property real s: 1
        property color c: "#9aa0b8"
        width: 20 * s; height: 24 * s
        Rectangle {
            x: 4 * lk.s; width: 12 * lk.s; height: 16 * lk.s; radius: 6 * lk.s
            color: "transparent"; border.width: 2.2 * lk.s; border.color: lk.c
        }
        Rectangle { y: 10 * lk.s; width: 20 * lk.s; height: 14 * lk.s; radius: 3 * lk.s; color: lk.c }
    }

    component KeyHint: Row {
        id: kh
        property string k: ""
        property string t: ""
        property real s: 1
        spacing: 10 * s
        Rectangle {
            height: 32 * kh.s; width: khk.implicitWidth + 22 * kh.s
            radius: 8 * kh.s
            color: "#1affffff"
            border.width: 1; border.color: "#2effffff"
            Text {
                id: khk
                anchors.centerIn: parent
                text: kh.k
                font.family: "Noto Sans"; font.pixelSize: 15 * kh.s
                font.weight: Font.Medium
                color: "#e9e3d2"
            }
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: kh.t
            font.family: "Noto Sans"; font.pixelSize: 17 * kh.s
            color: "#8a90a8"
        }
    }

    // ───────── Cửa sổ (mỗi màn hình một cái) ─────────
    Variants {
        model: Quickshell.screens

        PanelWindow {
            id: win
            required property var modelData
            screen: modelData
            visible: root.shown
            color: "transparent"

            anchors { top: true; bottom: true; left: true; right: true }
            exclusionMode: ExclusionMode.Ignore
            WlrLayershell.layer: WlrLayer.Overlay
            WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
            WlrLayershell.namespace: "tv-launcher"

            readonly property real u: Math.max(0.5, height / 1080)
            readonly property var days: ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"]

            onVisibleChanged: {
                if (visible) {
                    root.showHelp = false
                    root.noticeText = ""
                    if (root.sharePending.length > 0 || root.updState !== "") root.page = "share"
                    else if (!root.castOn && root.page !== "share") root.page = "home"
                    else if (root.page === "share" && root.sharePending.length === 0 && root.updState === "" && root.shareTab !== "send") root.page = "home"
                    content.opacity = 0
                    appear.restart()
                    heroAnim.restart()
                    content.forceActiveFocus()
                }
            }

            // ═════════ NỀN ═════════
            Rectangle { anchors.fill: parent; color: "#06070c" }

            property real drift: 0
            SequentialAnimation on drift {
                loops: Animation.Infinite
                NumberAnimation { to: 1; duration: 14000; easing.type: Easing.InOutSine }
                NumberAnimation { to: 0; duration: 14000; easing.type: Easing.InOutSine }
            }

            // Hào quang lớn theo màu ứng dụng
            Shape {
                anchors.fill: parent
                ShapePath {
                    strokeColor: "transparent"
                    startX: 0; startY: 0
                    fillGradient: RadialGradient {
                        centerX: win.width * (0.70 + 0.05 * win.drift)
                        centerY: win.height * (0.36 + 0.04 * win.drift)
                        centerRadius: win.height * 0.85
                        focalX: centerX; focalY: centerY
                        GradientStop { position: 0.0; color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.34) }
                        GradientStop { position: 0.45; color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.10) }
                        GradientStop { position: 1.0; color: "transparent" }
                    }
                    PathLine { x: win.width; y: 0 }
                    PathLine { x: win.width; y: win.height }
                    PathLine { x: 0; y: win.height }
                    PathLine { x: 0; y: 0 }
                }
            }
            // Ánh vàng ấm ở góc dưới trái
            Shape {
                anchors.fill: parent
                ShapePath {
                    strokeColor: "transparent"
                    startX: 0; startY: 0
                    fillGradient: RadialGradient {
                        centerX: 0; centerY: win.height
                        centerRadius: win.height * 0.9
                        focalX: centerX; focalY: centerY
                        GradientStop { position: 0.0; color: "#2ed8b46a" }
                        GradientStop { position: 1.0; color: "transparent" }
                    }
                    PathLine { x: win.width; y: 0 }
                    PathLine { x: win.width; y: win.height }
                    PathLine { x: 0; y: win.height }
                    PathLine { x: 0; y: 0 }
                }
            }
            // Tối dần phía dưới để hàng thẻ nổi bật
            Rectangle {
                anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                height: parent.height * 0.5
                gradient: Gradient {
                    GradientStop { position: 0.0; color: "transparent" }
                    GradientStop { position: 1.0; color: "#e6040509" }
                }
            }

            // ═════════ NỘI DUNG ═════════
            FocusScope {
                id: content
                anchors.fill: parent
                focus: true
                opacity: 0

                NumberAnimation {
                    id: appear
                    target: content; property: "opacity"
                    from: 0; to: 1; duration: 500; easing.type: Easing.OutCubic
                }

                Keys.onPressed: (e) => {
                    if (root.showHelp) {
                        if (e.key === Qt.Key_Escape || e.key === Qt.Key_F1 || e.key === Qt.Key_Question
                                || e.key === Qt.Key_Return || e.key === Qt.Key_Enter)
                            root.showHelp = false
                        e.accepted = true
                        return
                    }
                    if (root.page === "share") {
                        root.shareKey(e)
                        e.accepted = true
                        return
                    }
                    if (root.page === "cast") {
                        root.castKey(e)
                        e.accepted = true
                        return
                    }
                    if (root.page === "wifi") {
                        root.wifiKey(e)
                        e.accepted = true
                        return
                    }
                    switch (e.key) {
                    case Qt.Key_Left:
                    case Qt.Key_H: root.move(-1); break
                    case Qt.Key_Right:
                    case Qt.Key_L: root.move(1); break
                    case Qt.Key_Return:
                    case Qt.Key_Enter:
                    case Qt.Key_Space: root.launch(); break
                    case Qt.Key_1: case Qt.Key_2: case Qt.Key_3: case Qt.Key_4: case Qt.Key_5: case Qt.Key_6: case Qt.Key_7:
                        root.current = Math.min(root.apps.length - 1, e.key - Qt.Key_1)
                        root.powerArmed = false
                        break
                    case Qt.Key_Up:
                    case Qt.Key_Plus:
                    case Qt.Key_Equal: root.volume(["set-volume", "-l", "1.5", "@DEFAULT_AUDIO_SINK@", "5%+"]); break
                    case Qt.Key_Down:
                    case Qt.Key_Minus: root.volume(["set-volume", "@DEFAULT_AUDIO_SINK@", "5%-"]); break
                    case Qt.Key_M: root.volume(["set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"]); break
                    case Qt.Key_F1:
                    case Qt.Key_Question: root.showHelp = true; break
                    }
                    e.accepted = true
                }

                Connections {
                    target: root
                    function onCurrentChanged() { heroAnim.restart() }
                }

                // ───── Thanh trên ─────
                Row {
                    anchors { left: parent.left; top: parent.top; leftMargin: 96 * win.u; topMargin: 64 * win.u }
                    spacing: 14 * win.u
                    Text {
                        text: "ARCH"
                        font.family: "Noto Sans"; font.pixelSize: 30 * win.u
                        font.weight: Font.DemiBold; font.letterSpacing: 8
                        color: "#f4efe3"
                    }
                    Text {
                        text: "TV"
                        font.family: "Noto Sans"; font.pixelSize: 30 * win.u
                        font.weight: Font.Light; font.letterSpacing: 8
                        color: "#d8b46a"
                    }
                }

                Column {
                    anchors { right: parent.right; top: parent.top; rightMargin: 96 * win.u; topMargin: 48 * win.u }
                    spacing: 2 * win.u
                    Text {
                        anchors.right: parent.right
                        text: Qt.formatDateTime(clock.date, "HH:mm")
                        font.family: "Noto Sans"; font.pixelSize: 64 * win.u
                        font.weight: Font.Light; font.letterSpacing: 2
                        color: "#f4efe3"
                    }
                    Text {
                        anchors.right: parent.right
                        text: win.days[clock.date.getDay()] + ",  " + clock.date.getDate()
                              + " tháng " + (clock.date.getMonth() + 1)
                        font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                        font.letterSpacing: 1
                        color: "#9aa0b8"
                    }
                }

                Item {
                id: homeView
                anchors.fill: parent
                opacity: root.page === "home" ? 1 : 0
                visible: opacity > 0
                Behavior on opacity { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }

                // ───── Nghệ thuật lớn bên phải ─────
                Item {
                    id: bigArt
                    property real floatY: 0
                    width: 400 * win.u; height: width
                    x: parent.width * 0.70 - width / 2
                    y: parent.height * 0.36 - height / 2 + floatY
                    SequentialAnimation on floatY {
                        loops: Animation.Infinite
                        NumberAnimation { to: -10 * win.u; duration: 3200; easing.type: Easing.InOutSine }
                        NumberAnimation { to: 10 * win.u; duration: 3200; easing.type: Easing.InOutSine }
                    }

                    Rectangle {
                        id: ring
                        anchors.centerIn: parent
                        width: parent.width * 1.28; height: width; radius: width / 2
                        color: "transparent"
                        border.width: 1; border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.30)
                        SequentialAnimation on scale {
                            loops: Animation.Infinite
                            NumberAnimation { to: 1.04; duration: 2800; easing.type: Easing.InOutSine }
                            NumberAnimation { to: 1.0; duration: 2800; easing.type: Easing.InOutSine }
                        }
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        width: parent.width * 1.08; height: width; radius: width / 2
                        color: "transparent"
                        border.width: 1; border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18)
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        width: parent.width * 0.86; height: width; radius: width / 2
                        color: "#12ffffff"
                        border.width: 1; border.color: "#24ffffff"
                    }
                    AppIcon {
                        anchors.centerIn: parent
                        width: parent.width * 0.50; height: width
                        kind: root.apps[root.current].kind
                    }
                }

                // ───── Khối giới thiệu ─────
                Item {
                    id: hero
                    property real slide: 0
                    x: 96 * win.u + slide
                    y: parent.height * 0.20
                    width: 860 * win.u
                    height: heroCol.height

                    Column {
                        id: heroCol
                        spacing: 22 * win.u

                        Text {
                            text: "0" + (root.current + 1) + "   /   0" + root.apps.length
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 6
                            color: "#d8b46a"
                        }
                        Text {
                            text: root.apps[root.current].title
                            font.family: "Noto Serif"; font.pixelSize: 112 * win.u
                            font.weight: Font.Light
                            color: "#f7f2e6"
                        }
                        Rectangle {
                            width: 96 * win.u; height: 3 * win.u; radius: 2
                            color: root.accent
                        }
                        Text {
                            text: root.apps[root.current].desc
                            font.family: "Noto Sans"; font.pixelSize: 27 * win.u
                            font.weight: Font.Light
                            lineHeight: 1.35
                            color: "#b4b9cc"
                        }
                        Item { width: 1; height: 6 * win.u }
                        Rectangle {
                            height: 60 * win.u
                            width: pillRow.width + 40 * win.u
                            radius: height / 2
                            color: "#1affffff"
                            border.width: 1; border.color: "#33ffffff"
                            Row {
                                id: pillRow
                                anchors.centerIn: parent
                                spacing: 16 * win.u
                                Rectangle {
                                    anchors.verticalCenter: parent.verticalCenter
                                    height: 34 * win.u; width: enterTxt.implicitWidth + 24 * win.u
                                    radius: 8 * win.u; color: "#f4efe3"
                                    Text {
                                        id: enterTxt
                                        anchors.centerIn: parent
                                        text: "ENTER"
                                        font.family: "Noto Sans"; font.pixelSize: 16 * win.u
                                        font.weight: Font.DemiBold; font.letterSpacing: 2
                                        color: "#0a0c14"
                                    }
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: root.apps[root.current].danger
                                          ? (root.powerArmed ? "Nhấn lần nữa để xác nhận" : "Tắt máy")
                                          : "Mở " + root.apps[root.current].title
                                    font.family: "Noto Sans"; font.pixelSize: 23 * win.u
                                    color: (root.apps[root.current].danger && root.powerArmed) ? "#ff8a8a" : "#f4efe3"
                                }
                            }
                        }
                    }
                }

                ParallelAnimation {
                    id: heroAnim
                    NumberAnimation { target: hero; property: "opacity"; from: 0; to: 1; duration: 450; easing.type: Easing.OutCubic }
                    NumberAnimation { target: hero; property: "slide"; from: 40 * win.u; to: 0; duration: 520; easing.type: Easing.OutCubic }
                    NumberAnimation { target: bigArt; property: "opacity"; from: 0; to: 1; duration: 520; easing.type: Easing.OutCubic }
                    NumberAnimation { target: bigArt; property: "scale"; from: 0.9; to: 1; duration: 600; easing.type: Easing.OutBack; easing.overshoot: 1.1 }
                }

                // ───── Hàng thẻ ứng dụng ─────
                ListView {
                    id: list
                    anchors {
                        left: parent.left; right: parent.right; bottom: parent.bottom
                        leftMargin: 80 * win.u; rightMargin: 80 * win.u; bottomMargin: 132 * win.u
                    }
                    height: 270 * win.u
                    orientation: ListView.Horizontal
                    model: root.apps
                    currentIndex: root.current
                    interactive: false
                    clip: false
                    spacing: 10 * win.u
                    highlightRangeMode: ListView.ApplyRange
                    preferredHighlightBegin: 140 * win.u
                    preferredHighlightEnd: width - 140 * win.u
                    highlightMoveDuration: 420

                    delegate: Item {
                        id: tile
                        required property var modelData
                        required property int index
                        readonly property bool active: ListView.isCurrentItem
                        width: 316 * win.u
                        height: list.height
                        z: active ? 2 : 1

                        Item {
                            id: card
                            width: 296 * win.u; height: 178 * win.u
                            anchors.centerIn: parent
                            anchors.verticalCenterOffset: tile.active ? -8 * win.u : 0
                            scale: tile.active ? 1.13 : 1.0
                            Behavior on scale { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                            Behavior on anchors.verticalCenterOffset { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }

                            // Hào quang mềm (nhiều lớp mờ dần)
                            Repeater {
                                model: 5
                                Rectangle {
                                    required property int index
                                    anchors.fill: parent
                                    anchors.margins: -(6 + index * 7) * win.u
                                    radius: (22 + index * 7) * win.u
                                    color: tile.modelData.accent
                                    opacity: tile.active ? 0.075 : 0
                                    Behavior on opacity { NumberAnimation { duration: 350 } }
                                }
                            }

                            Rectangle {
                                id: body
                                anchors.fill: parent
                                radius: 22 * win.u
                                clip: true
                                gradient: Gradient {
                                    GradientStop { position: 0.0; color: tile.modelData.c1 }
                                    GradientStop { position: 1.0; color: tile.modelData.c2 }
                                }

                                // Ánh sáng nhẹ ở nửa trên
                                Rectangle {
                                    anchors { left: parent.left; right: parent.right; top: parent.top }
                                    height: parent.height * 0.55
                                    gradient: Gradient {
                                        GradientStop { position: 0.0; color: "#1affffff" }
                                        GradientStop { position: 1.0; color: "transparent" }
                                    }
                                }

                                AppIcon {
                                    anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 22 * win.u }
                                    width: 80 * win.u; height: width
                                    kind: tile.modelData.kind
                                }

                                Text {
                                    anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 18 * win.u }
                                    text: tile.modelData.title
                                    font.family: "Noto Sans"; font.pixelSize: 25 * win.u
                                    font.weight: Font.Medium
                                    color: "#f7f2e6"
                                }

                                // Làm tối thẻ không được chọn
                                Rectangle {
                                    anchors.fill: parent
                                    color: "#000000"
                                    opacity: tile.active ? 0 : 0.42
                                    Behavior on opacity { NumberAnimation { duration: 300 } }
                                }
                            }

                            // Viền
                            Rectangle {
                                anchors.fill: parent
                                radius: 22 * win.u
                                color: "transparent"
                                border.width: tile.active ? 3 * win.u : 1
                                border.color: tile.active ? "#f4efe3" : "#26ffffff"
                                Behavior on border.color { ColorAnimation { duration: 250 } }
                            }

                            // Số phím tắt
                            Rectangle {
                                anchors { left: parent.left; top: parent.top; margins: 12 * win.u }
                                width: 28 * win.u; height: width; radius: 8 * win.u
                                color: "#66000000"
                                Text {
                                    anchors.centerIn: parent
                                    text: tile.index + 1
                                    font.family: "Noto Sans"; font.pixelSize: 15 * win.u
                                    font.weight: Font.DemiBold
                                    color: "#d8b46a"
                                }
                            }
                        }
                    }
                }

                // ───── Gợi ý phím ─────
                Row {
                    anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 46 * win.u }
                    spacing: 40 * win.u
                    Repeater {
                        model: [
                            { k: "←  →", t: "Chọn" },
                            { k: "Enter", t: "Mở" },
                            { k: "↑  ↓", t: "Âm lượng" },
                            { k: "M", t: "Tắt tiếng" },
                            { k: "F1", t: "Trợ giúp" }
                        ]
                        delegate: Row {
                            required property var modelData
                            spacing: 10 * win.u
                            Rectangle {
                                height: 32 * win.u; width: kk.implicitWidth + 22 * win.u
                                radius: 8 * win.u
                                color: "#1affffff"
                                border.width: 1; border.color: "#2effffff"
                                Text {
                                    id: kk
                                    anchors.centerIn: parent
                                    text: modelData.k
                                    font.family: "Noto Sans"; font.pixelSize: 15 * win.u
                                    font.weight: Font.Medium
                                    color: "#e9e3d2"
                                }
                            }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                text: modelData.t
                                font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                                color: "#8a90a8"
                            }
                        }
                    }
                }

                } // hết homeView

                // ═════════ MÀN HÌNH WI-FI ═════════
                Item {
                    id: wifiView
                    anchors.fill: parent
                    opacity: root.page === "wifi" ? 1 : 0
                    visible: opacity > 0
                    Behavior on opacity { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }

                    // Tiêu đề + trạng thái (bên trái)
                    Column {
                        x: 96 * win.u
                        y: parent.height * 0.20
                        width: 640 * win.u
                        spacing: 22 * win.u

                        Text {
                            text: "KẾT NỐI"
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 6
                            color: "#d8b46a"
                        }
                        Text {
                            text: "Wi-Fi"
                            font.family: "Noto Serif"; font.pixelSize: 112 * win.u
                            font.weight: Font.Light
                            color: "#f7f2e6"
                        }
                        Rectangle { width: 96 * win.u; height: 3 * win.u; radius: 2; color: root.accent }
                        Text {
                            text: root.wifiCur !== "" ? "Đang kết nối với" : "Chưa kết nối mạng nào"
                            font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                            font.weight: Font.Light
                            color: "#9aa0b8"
                        }
                        Text {
                            visible: root.wifiCur !== ""
                            width: parent.width
                            elide: Text.ElideRight
                            text: root.wifiCur
                            font.family: "Noto Serif"; font.pixelSize: 44 * win.u
                            color: "#f7f2e6"
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            text: root.wMsg
                            visible: root.wMsg !== ""
                            font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                            lineHeight: 1.25
                            color: root.wMsgBad ? "#ff8a8a" : "#7fe3b4"
                        }
                    }

                    // Danh sách mạng (bên phải)
                    Rectangle {
                        id: netPanel
                        x: parent.width * 0.50
                        y: parent.height * 0.17
                        width: parent.width * 0.50 - 96 * win.u
                        height: parent.height * 0.62
                        radius: 28 * win.u
                        color: "#12ffffff"
                        border.width: 1; border.color: "#22ffffff"

                        ListView {
                            id: netList
                            anchors { fill: parent; margins: 14 * win.u }
                            clip: true
                            spacing: 8 * win.u
                            interactive: false
                            model: root.nets
                            currentIndex: root.netIndex
                            highlightMoveDuration: 0
                            onCurrentIndexChanged: positionViewAtIndex(currentIndex, ListView.Contain)

                            delegate: Rectangle {
                                id: row
                                required property var modelData
                                required property int index
                                readonly property bool sel: index === root.netIndex
                                width: ListView.view.width
                                height: 84 * win.u
                                radius: 18 * win.u
                                color: sel ? "#26ffffff" : "transparent"
                                border.width: sel ? 2 * win.u : 0
                                border.color: "#f4efe3"
                                Behavior on color { ColorAnimation { duration: 160 } }

                                SignalBars {
                                    s: win.u
                                    anchors { left: parent.left; leftMargin: 28 * win.u; verticalCenter: parent.verticalCenter }
                                    level: Math.min(4, Math.ceil(row.modelData.signal / 25))
                                }

                                Column {
                                    anchors { left: parent.left; leftMargin: 104 * win.u; verticalCenter: parent.verticalCenter }
                                    width: parent.width - 104 * win.u - 90 * win.u
                                    spacing: 2 * win.u
                                    Text {
                                        width: parent.width
                                        elide: Text.ElideRight
                                        text: row.modelData.ssid
                                        font.family: "Noto Sans"; font.pixelSize: 28 * win.u
                                        font.weight: row.sel ? Font.Medium : Font.Normal
                                        color: "#f7f2e6"
                                    }
                                    Text {
                                        text: row.modelData.active ? "Đang kết nối"
                                              : (root.saved[row.modelData.ssid] ? "Đã lưu"
                                              : (row.modelData.secure ? "Bảo mật" : "Mạng mở"))
                                        font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                                        color: row.modelData.active ? "#7fe3b4" : "#8a90a8"
                                    }
                                }

                                LockIcon {
                                    s: win.u
                                    visible: row.modelData.secure
                                    c: row.sel ? "#f4efe3" : "#8a90a8"
                                    anchors { right: parent.right; rightMargin: 30 * win.u; verticalCenter: parent.verticalCenter }
                                }
                                Rectangle {
                                    visible: row.modelData.active && !row.modelData.secure
                                    width: 14 * win.u; height: width; radius: width / 2
                                    color: "#7fe3b4"
                                    anchors { right: parent.right; rightMargin: 34 * win.u; verticalCenter: parent.verticalCenter }
                                }
                            }
                        }

                        Text {
                            anchors.centerIn: parent
                            visible: root.nets.length === 0
                            horizontalAlignment: Text.AlignHCenter
                            lineHeight: 1.4
                            text: root.scanning ? "Đang quét mạng…" : "Không tìm thấy mạng nào\nNhấn R để quét lại"
                            font.family: "Noto Sans"; font.pixelSize: 26 * win.u
                            color: "#8a90a8"
                        }
                    }

                    // Chỉ báo đang quét
                    Text {
                        anchors { right: netPanel.right; bottom: netPanel.top; bottomMargin: 12 * win.u }
                        text: root.scanning ? "Đang quét…" : root.nets.length + " mạng"
                        font.family: "Noto Sans"; font.pixelSize: 18 * win.u
                        font.letterSpacing: 2
                        color: "#8a90a8"
                    }

                    // Gợi ý phím
                    Row {
                        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 46 * win.u }
                        spacing: 40 * win.u
                        KeyHint { s: win.u; k: "↑  ↓"; t: "Chọn" }
                        KeyHint { s: win.u; k: "Enter"; t: "Kết nối" }
                        KeyHint { s: win.u; k: "R"; t: "Quét lại" }
                        KeyHint { s: win.u; k: "F"; t: "Quên mạng" }
                        KeyHint { s: win.u; k: "Esc"; t: "Quay lại" }
                    }

                    // ───── Nhập mật khẩu + bàn phím ảo ─────
                    Item {
                        id: passModal
                        anchors.fill: parent
                        opacity: root.wStep === "pass" ? 1 : 0
                        visible: opacity > 0
                        Behavior on opacity { NumberAnimation { duration: 260 } }

                        Rectangle { anchors.fill: parent; color: "#e6040509" }

                        Rectangle {
                            id: pcard
                            anchors.centerIn: parent
                            width: 1060 * win.u
                            height: pcol.implicitHeight + 84 * win.u
                            radius: 32 * win.u
                            color: "#f2101320"
                            border.width: 1; border.color: "#44d8b46a"
                            scale: root.wStep === "pass" ? 1 : 0.95
                            Behavior on scale { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }

                            Column {
                                id: pcol
                                anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 42 * win.u }
                                width: parent.width - 100 * win.u
                                spacing: 14 * win.u

                                Text {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    text: "NHẬP MẬT KHẨU"
                                    font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                                    font.letterSpacing: 8
                                    color: "#d8b46a"
                                }
                                Text {
                                    width: parent.width
                                    horizontalAlignment: Text.AlignHCenter
                                    elide: Text.ElideRight
                                    text: root.wTarget
                                    font.family: "Noto Serif"; font.pixelSize: 40 * win.u
                                    font.weight: Font.Light
                                    color: "#f7f2e6"
                                }

                                Rectangle {
                                    id: field
                                    width: parent.width
                                    height: 72 * win.u
                                    radius: 16 * win.u
                                    color: "#16ffffff"
                                    border.width: 2; border.color: root.accent
                                    clip: true

                                    Text {
                                        visible: root.pw.length === 0
                                        anchors { left: parent.left; leftMargin: 46 * win.u; verticalCenter: parent.verticalCenter }
                                        text: "Gõ mật khẩu hoặc dùng bàn phím ảo…"
                                        font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                        color: "#6f758c"
                                    }
                                    Row {
                                        id: frow
                                        anchors.verticalCenter: parent.verticalCenter
                                        x: Math.min(26 * win.u, field.width - width - 26 * win.u)
                                        spacing: 4 * win.u
                                        Text {
                                            text: root.showPw ? root.pw : "•".repeat(root.pw.length)
                                            font.family: "Noto Sans"; font.pixelSize: 34 * win.u
                                            font.letterSpacing: root.showPw ? 1 : 3
                                            color: "#f7f2e6"
                                        }
                                        Rectangle {
                                            width: 3 * win.u; height: 38 * win.u
                                            color: root.accent
                                            SequentialAnimation on opacity {
                                                loops: Animation.Infinite
                                                running: root.wStep === "pass"
                                                NumberAnimation { to: 0; duration: 500 }
                                                NumberAnimation { to: 1; duration: 500 }
                                            }
                                        }
                                    }
                                }

                                Text {
                                    width: parent.width
                                    height: 32 * win.u
                                    horizontalAlignment: Text.AlignHCenter
                                    verticalAlignment: Text.AlignVCenter
                                    elide: Text.ElideRight
                                    text: root.wMsg
                                    font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                                    color: root.wMsgBad ? "#ff8a8a" : "#7fe3b4"
                                }

                                // Bàn phím ảo
                                Column {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    spacing: 10 * win.u

                                    Repeater {
                                        model: root.kbRows()
                                        delegate: Row {
                                            id: krow
                                            required property var modelData
                                            required property int index
                                            anchors.horizontalCenter: parent.horizontalCenter
                                            spacing: 10 * win.u

                                            Repeater {
                                                model: krow.modelData
                                                delegate: Rectangle {
                                                    id: key
                                                    required property var modelData
                                                    required property int index
                                                    readonly property bool sel: root.kr === krow.index && root.kc === key.index
                                                    readonly property bool lit: (modelData.a === "shift" && root.kbLayer === 1)
                                                                                || (modelData.a === "sym" && root.kbLayer === 2)
                                                                                || (modelData.a === "eye" && root.showPw)
                                                    width: (modelData.w * 78 + (modelData.w - 1) * 10) * win.u
                                                    height: 70 * win.u
                                                    radius: 14 * win.u
                                                    z: sel ? 2 : 1
                                                    scale: sel ? 1.07 : 1
                                                    Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                                                    color: sel ? "#f4efe3"
                                                           : (modelData.a === "go" ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.38)
                                                           : (lit ? "#40d8b46a" : "#1cffffff"))
                                                    border.width: 1
                                                    border.color: sel ? "#f4efe3" : (modelData.a === "go" ? root.accent : "#26ffffff")

                                                    Text {
                                                        anchors.centerIn: parent
                                                        text: key.modelData.l
                                                        font.family: "Noto Sans"
                                                        font.pixelSize: (key.modelData.l.length > 1 ? 21 : 30) * win.u
                                                        font.weight: key.modelData.a === "go" ? Font.DemiBold : Font.Normal
                                                        color: key.sel ? "#0a0c14" : "#f4efe3"
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Item { width: 1; height: 4 * win.u }

                                Row {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    spacing: 30 * win.u
                                    KeyHint { s: win.u; k: "←↑↓→"; t: "Di chuyển" }
                                    KeyHint { s: win.u; k: "Enter"; t: "Nhấn phím" }
                                    KeyHint { s: win.u; k: "Ctrl+Enter"; t: "Kết nối" }
                                    KeyHint { s: win.u; k: "Esc"; t: "Hủy" }
                                }
                            }
                        }
                    }

                    // ───── Đang kết nối ─────
                    Item {
                        id: busyModal
                        anchors.fill: parent
                        opacity: root.wStep === "busy" ? 1 : 0
                        visible: opacity > 0
                        Behavior on opacity { NumberAnimation { duration: 260 } }

                        Rectangle { anchors.fill: parent; color: "#e6040509" }

                        Column {
                            anchors.centerIn: parent
                            spacing: 30 * win.u
                            Row {
                                anchors.horizontalCenter: parent.horizontalCenter
                                spacing: 16 * win.u
                                Repeater {
                                    model: 3
                                    Rectangle {
                                        required property int index
                                        width: 16 * win.u; height: width; radius: width / 2
                                        color: root.accent
                                        opacity: 0.25
                                        SequentialAnimation on opacity {
                                            loops: Animation.Infinite
                                            running: root.wStep === "busy"
                                            PauseAnimation { duration: index * 220 }
                                            NumberAnimation { to: 1; duration: 330 }
                                            NumberAnimation { to: 0.25; duration: 330 }
                                            PauseAnimation { duration: (2 - index) * 220 }
                                        }
                                    }
                                }
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: "Đang kết nối"
                                font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                font.letterSpacing: 6
                                color: "#d8b46a"
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: root.wTarget
                                font.family: "Noto Serif"; font.pixelSize: 48 * win.u
                                font.weight: Font.Light
                                color: "#f7f2e6"
                            }
                        }
                    }
                }

                // ═════════ MÀN HÌNH TRUYỀN MÀN HÌNH ═════════
                Item {
                    id: castView
                    anchors.fill: parent
                    opacity: root.page === "cast" ? 1 : 0
                    visible: opacity > 0
                    Behavior on opacity { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }

                    Column {
                        x: 96 * win.u
                        y: parent.height * 0.20
                        width: 700 * win.u
                        spacing: 22 * win.u

                        Text {
                            text: "CHIẾU LÊN TV"
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 6
                            color: "#d8b46a"
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            text: "Truyền màn hình"
                            font.family: "Noto Serif"; font.pixelSize: 92 * win.u
                            font.weight: Font.Light
                            lineHeight: 0.95
                            color: "#f7f2e6"
                        }
                        Rectangle { width: 96 * win.u; height: 3 * win.u; radius: 2; color: root.accent }
                        Row {
                            spacing: 14 * win.u
                            Rectangle {
                                id: castDot
                                anchors.verticalCenter: parent.verticalCenter
                                width: 16 * win.u; height: width; radius: width / 2
                                color: root.castOn ? "#7fe3b4" : "#6f758c"
                                SequentialAnimation on opacity {
                                    loops: Animation.Infinite
                                    running: root.castOn
                                    NumberAnimation { to: 0.3; duration: 900 }
                                    NumberAnimation { to: 1.0; duration: 900 }
                                    onRunningChanged: if (!running) castDot.opacity = 1
                                }
                            }
                            Text {
                                text: root.castOn ? "AirPlay đang chờ. Tên thiết bị: " + root.castName : "AirPlay đang tắt"
                                font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                color: root.castOn ? "#f4efe3" : "#9aa0b8"
                            }
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            visible: root.castMsg !== ""
                            text: root.castMsg
                            font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                            lineHeight: 1.25
                            color: "#ffb48a"
                        }
                        Rectangle {
                            visible: root.castAsk !== ""
                            width: parent.width
                            height: askCol.implicitHeight + 36 * win.u
                            radius: 20 * win.u
                            color: "#18ffffff"
                            border.width: 2 * win.u; border.color: root.accent
                            Column {
                                id: askCol
                                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter
                                          leftMargin: 24 * win.u; rightMargin: 24 * win.u }
                                spacing: 10 * win.u
                                Text {
                                    width: parent.width
                                    wrapMode: Text.WordWrap
                                    text: root.castAsk === "connect" ? "Nhập địa chỉ kết nối (IP:cổng ở màn hình chính “Gỡ lỗi không dây”). Gõ P nếu chưa ghép nối."
                                        : root.castAsk === "pair" ? "Ghép nối: trên điện thoại bấm “Ghép nối thiết bị bằng mã ghép nối”, rồi nhập địa chỉ IP:cổng hiện ra."
                                        : "Nhập mã ghép nối gồm 6 chữ số."
                                    font.family: "Noto Sans"; font.pixelSize: 19 * win.u
                                    color: "#b4b9cc"
                                }
                                Text {
                                    text: root.castInput + "▌"
                                    font.family: "Noto Sans"; font.pixelSize: 36 * win.u
                                    font.weight: Font.Medium
                                    color: "#f7f2e6"
                                }
                                Text {
                                    text: "Enter xác nhận  ·  Esc huỷ"
                                    font.family: "Noto Sans"; font.pixelSize: 16 * win.u
                                    color: "#7d8299"
                                }
                            }
                        }
                    }

                    Column {
                        x: parent.width * 0.50
                        y: parent.height * 0.17
                        width: parent.width * 0.50 - 96 * win.u
                        spacing: 18 * win.u

                        Repeater {
                            model: [
                                { k: "Enter", type: "air", title: "AirPlay", sub: "iPhone, iPad, Mac",
                                  steps: "Nhấn Enter để bật. Trên iPhone mở Trung tâm điều khiển, chọn Phản chiếu màn hình, rồi chọn “" + root.castName + "”." },
                                { k: "W  /  S", type: "and", title: "Android (scrcpy)", sub: "KHÔNG DÂY hoặc CÁP USB",
                                  steps: "W: không dây. Bật Gỡ lỗi không dây (Tùy chọn nhà phát triển), nhấn W; lần đầu ghép nối bằng mã, sau đó tự kết nối lại. Chạy được qua Wi-Fi hoặc cáp USB chia sẻ mạng. S: cáp USB + Gỡ lỗi USB." },
                                { k: "YouTube", type: "yt", title: "Chiếu video YouTube", sub: "Không cần cáp",
                                  steps: "Trên TV: YouTube, Settings, Link with TV code. Trên điện thoại: mở YouTube, bấm biểu tượng Cast." }
                            ]
                            delegate: Rectangle {
                                id: ccard
                                required property var modelData
                                readonly property bool live: modelData.type === "air" && root.castOn
                                width: parent.width
                                height: 186 * win.u
                                radius: 24 * win.u
                                color: live ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.16) : "#12ffffff"
                                border.width: live ? 2 * win.u : 1
                                border.color: live ? root.accent : "#22ffffff"
                                Behavior on color { ColorAnimation { duration: 250 } }

                                Rectangle {
                                    anchors { right: parent.right; top: parent.top; margins: 24 * win.u }
                                    height: 34 * win.u; width: chipTxt.implicitWidth + 24 * win.u
                                    radius: 8 * win.u
                                    color: "#f4efe3"
                                    Text {
                                        id: chipTxt
                                        anchors.centerIn: parent
                                        text: ccard.modelData.k
                                        font.family: "Noto Sans"; font.pixelSize: 16 * win.u
                                        font.weight: Font.DemiBold; font.letterSpacing: 1
                                        color: "#0a0c14"
                                    }
                                }
                                Column {
                                    anchors { left: parent.left; leftMargin: 30 * win.u; right: parent.right; rightMargin: 30 * win.u
                                              verticalCenter: parent.verticalCenter }
                                    spacing: 6 * win.u
                                    Text {
                                        text: ccard.modelData.title + (ccard.live ? "   ● đang bật" : "")
                                        font.family: "Noto Sans"; font.pixelSize: 30 * win.u
                                        font.weight: Font.Medium
                                        color: "#f7f2e6"
                                    }
                                    Text {
                                        text: ccard.modelData.sub
                                        font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                                        font.letterSpacing: 2
                                        color: "#d8b46a"
                                    }
                                    Text {
                                        width: parent.width
                                        wrapMode: Text.WordWrap
                                        text: ccard.modelData.steps
                                        font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                                        lineHeight: 1.25
                                        color: "#b4b9cc"
                                    }
                                }
                            }
                        }
                    }

                    Row {
                        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 46 * win.u }
                        spacing: 40 * win.u
                        KeyHint { s: win.u; k: "Enter"; t: "Bật / tắt AirPlay" }
                        KeyHint { s: win.u; k: "W"; t: "Android không dây" }
                        KeyHint { s: win.u; k: "S"; t: "Android (USB)" }
                        KeyHint { s: win.u; k: "Esc"; t: "Tắt và quay lại" }
                    }
                }

                // ═════════ MÀN HÌNH NHẬN FILE ═════════
                Item {
                    id: shareView
                    anchors.fill: parent
                    opacity: root.page === "share" ? 1 : 0
                    visible: opacity > 0
                    Behavior on opacity { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }

                    Column {
                        x: 96 * win.u
                        y: parent.height * 0.10
                        width: 720 * win.u
                        spacing: 16 * win.u

                        Row {
                            spacing: 14 * win.u
                            Repeater {
                                model: [{ k: "recv", t: "NHẬN" }, { k: "send", t: "GỬI" }]
                                delegate: Rectangle {
                                    id: tabPill
                                    required property var modelData
                                    readonly property bool on: root.shareTab === modelData.k
                                    width: tabTxt.implicitWidth + 48 * win.u
                                    height: 44 * win.u
                                    radius: height / 2
                                    color: on ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.22) : "#12ffffff"
                                    border.width: on ? 2 * win.u : 1
                                    border.color: on ? root.accent : "#22ffffff"
                                    Text {
                                        id: tabTxt
                                        anchors.centerIn: parent
                                        text: tabPill.modelData.t
                                        font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                                        font.weight: Font.Medium; font.letterSpacing: 4
                                        color: tabPill.on ? "#f7f2e6" : "#9aa0b8"
                                    }
                                }
                            }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                text: "Tab để đổi"
                                font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                                color: "#7d8299"
                            }
                        }
                        Text {
                            text: root.shareTab === "recv" ? "TỪ ĐIỆN THOẠI" : "SANG ĐIỆN THOẠI"
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 6
                            color: "#d8b46a"
                        }
                        Text {
                            text: root.shareTab === "recv" ? "Nhận file" : "Gửi file"
                            font.family: "Noto Serif"; font.pixelSize: 88 * win.u
                            font.weight: Font.Light
                            color: "#f7f2e6"
                        }
                        Rectangle { width: 96 * win.u; height: 3 * win.u; radius: 2; color: root.accent }
                        Row {
                            spacing: 14 * win.u
                            Rectangle {
                                anchors.verticalCenter: parent.verticalCenter
                                width: 16 * win.u; height: width; radius: width / 2
                                color: root.shareUp ? "#7fe3b4" : (root.shareOn ? "#ffd27f" : "#6f758c")
                            }
                            Text {
                                width: Math.min(implicitWidth, 600 * win.u)
                                wrapMode: Text.WordWrap
                                text: !root.shareUp ? (root.shareNote !== "" ? root.shareNote
                                                       : (root.shareOn ? "Đang khởi động máy chủ…" : "Đã tắt (nhấn T để bật)"))
                                      : (root.shareTab === "send"
                                         ? (root.sendList.length > 0 ? "Đang chia sẻ " + root.sendList.length + " file cho điện thoại"
                                                                     : "Sẵn sàng — nhấn Enter để chọn file gửi")
                                         : "Đang chờ file từ điện thoại")
                                font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                color: root.shareUp ? "#f4efe3" : "#9aa0b8"
                            }
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            text: (root.shareUsb ? "Điện thoại đang cắm cáp USB (bật chia sẻ mạng qua USB): mở trình duyệt, vào địa chỉ"
                                               : "Điện thoại cùng mạng với TV (Wi-Fi hoặc cáp USB): mở trình duyệt, vào địa chỉ")
                                  + (root.shareTab === "send" ? ". File sẽ hiện ở mục “TV đang chia sẻ”" : "")
                            font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                            color: "#b4b9cc"
                        }
                        Text {
                            text: root.shareUrl !== "" ? root.shareUrl.replace("http://", "") : "…"
                            font.family: "Noto Sans"; font.pixelSize: 44 * win.u
                            font.weight: Font.Medium
                            color: root.accent
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            visible: root.shareIface !== "" || root.shareUrls.length > 1
                            text: (root.shareIface !== "" ? "Cổng USB: " + root.shareIface : "")
                                  + (root.shareUrls.length > 1
                                     ? (root.shareIface !== "" ? "   ·   " : "") + "Địa chỉ khác: "
                                       + root.shareUrls.slice(1).map(u => u.replace("http://", "")).join(",  ")
                                     : "")
                            font.family: "Noto Sans"; font.pixelSize: 18 * win.u
                            color: "#9aa0b8"
                        }
                        Row {
                            spacing: 32 * win.u
                            Rectangle {
                                width: 252 * win.u; height: width; radius: 16 * win.u
                                color: "#ffffff"
                                visible: root.shareQr.length > 0
                                // Vẽ bằng ô vuông thường (không dùng Canvas để khỏi bị lỗi không vẽ lại khi vừa hiện)
                                Item {
                                    id: qrBox
                                    anchors { fill: parent; margins: 14 * win.u }
                                    readonly property real c: root.shareQr.length > 0 ? width / root.shareQr.length : 0
                                    Repeater {
                                        model: root.shareQrCells
                                        delegate: Rectangle {
                                            required property var modelData
                                            x: Math.floor(modelData[0] * qrBox.c)
                                            y: Math.floor(modelData[1] * qrBox.c)
                                            width: Math.ceil(qrBox.c)
                                            height: width
                                            color: "#0a0c14"
                                        }
                                    }
                                }
                            }
                            Column {
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 10 * win.u
                                Text {
                                    text: "Hoặc quét mã QR"
                                    font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                                    color: "#9aa0b8"
                                }
                                Text {
                                    visible: !root.sharePin && root.updPin !== ""
                                    text: "Mã cập nhật (cho update.zip)"
                                    font.family: "Noto Sans"; font.pixelSize: 18 * win.u
                                    font.letterSpacing: 1
                                    color: "#d8b46a"
                                }
                                Text {
                                    visible: !root.sharePin && root.updPin !== ""
                                    text: root.updPin
                                    font.family: "Noto Sans"; font.pixelSize: 46 * win.u
                                    font.weight: Font.DemiBold; font.letterSpacing: 8
                                    color: "#f7f2e6"
                                }
                                Text {
                                    visible: root.sharePin
                                    text: "Đang dùng mã PIN cố định (share.pin)"
                                    font.family: "Noto Sans"; font.pixelSize: 19 * win.u
                                    color: "#d8b46a"
                                }
                                Text {
                                    width: 360 * win.u
                                    wrapMode: Text.WordWrap
                                    visible: root.shareNote !== ""
                                    text: root.shareNote
                                    font.family: "Noto Sans"; font.pixelSize: 19 * win.u
                                    color: "#ffb48a"
                                }
                            }
                        }
                    }

                    // Hàng chờ bên phải
                    Column {
                        id: shareList
                        visible: root.shareTab === "recv"
                        property int start: Math.max(0, Math.min(root.shareSel - 2, root.sharePending.length - 5))
                        x: parent.width * 0.54
                        y: parent.height * 0.10
                        width: parent.width * 0.46 - 96 * win.u
                        spacing: 14 * win.u

                        Text {
                            text: "HÀNG CHỜ  ·  " + root.sharePending.length + " file"
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 5
                            color: "#d8b46a"
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            visible: root.shareMsg !== ""
                            text: root.shareMsg
                            font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                            color: root.shareMsgBad ? "#ffb48a" : "#7fe3b4"
                        }
                        Rectangle {
                            visible: root.sharePending.length === 0
                            width: parent.width
                            height: 200 * win.u
                            radius: 24 * win.u
                            color: "#12ffffff"
                            border.width: 1; border.color: "#22ffffff"
                            Text {
                                anchors { fill: parent; margins: 30 * win.u }
                                wrapMode: Text.WordWrap
                                verticalAlignment: Text.AlignVCenter
                                lineHeight: 1.3
                                text: "Chưa có file nào. Gửi từ điện thoại, file hiện ở đây để bạn Lưu hoặc Bỏ qua.\nMẹo: gửi file tên update.zip để tự cập nhật TV."
                                font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                color: "#9aa0b8"
                            }
                        }
                        Repeater {
                            model: Math.min(5, root.sharePending.length)
                            delegate: Rectangle {
                                id: srow
                                required property int index
                                readonly property int idx: shareList.start + index
                                readonly property var it: root.sharePending[idx]
                                readonly property bool sel: idx === root.shareSel
                                width: shareList.width
                                height: 96 * win.u
                                radius: 20 * win.u
                                color: sel ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18) : "#12ffffff"
                                border.width: sel ? 2 * win.u : 1
                                border.color: sel ? root.accent : "#22ffffff"

                                Rectangle {
                                    id: thumb
                                    anchors { left: parent.left; leftMargin: 16 * win.u; verticalCenter: parent.verticalCenter }
                                    width: 64 * win.u; height: width; radius: 12 * win.u
                                    color: "#1affffff"
                                    clip: true
                                    Image {
                                        anchors.fill: parent
                                        visible: !!(srow.it && srow.it.img)
                                        source: (srow.it && srow.it.img) ? "file://" + srow.it.path : ""
                                        fillMode: Image.PreserveAspectCrop
                                        asynchronous: true
                                        cache: false
                                        sourceSize.width: 160
                                        sourceSize.height: 160
                                    }
                                    Text {
                                        anchors.centerIn: parent
                                        visible: !!(srow.it && !srow.it.img)
                                        text: srow.it ? root.fileIcon(srow.it.name) : ""
                                        font.pixelSize: 34 * win.u
                                    }
                                }
                                Column {
                                    anchors { left: thumb.right; leftMargin: 18 * win.u; right: parent.right; rightMargin: 18 * win.u
                                              verticalCenter: parent.verticalCenter }
                                    spacing: 4 * win.u
                                    Text {
                                        width: parent.width
                                        elide: Text.ElideMiddle
                                        text: srow.it ? srow.it.name : ""
                                        font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                        font.weight: Font.Medium
                                        color: "#f7f2e6"
                                    }
                                    Text {
                                        width: parent.width
                                        elide: Text.ElideRight
                                        text: srow.it ? root.fmtBytes(srow.it.size) + "  ·  " + (srow.it.dev !== "" ? srow.it.dev : srow.it.from) : ""
                                        font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                                        color: "#9aa0b8"
                                    }
                                }
                            }
                        }
                    }

                    // ───── Tab GỬI: danh sách đang chia sẻ ─────
                    Column {
                        id: sendCol
                        visible: root.shareTab === "send" && !root.browseOpen
                        property int start: Math.max(0, Math.min(root.sendSel - 2, root.sendList.length - 5))
                        x: parent.width * 0.54
                        y: parent.height * 0.10
                        width: parent.width * 0.46 - 96 * win.u
                        spacing: 14 * win.u

                        Text {
                            text: "ĐANG CHIA SẺ  ·  " + root.sendList.length + " file"
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 5
                            color: "#d8b46a"
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            visible: root.sendMsg !== ""
                            text: root.sendMsg
                            font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                            color: root.sendMsgBad ? "#ffb48a" : "#7fe3b4"
                        }
                        Rectangle {
                            visible: root.sendList.length === 0
                            width: parent.width
                            height: 200 * win.u
                            radius: 24 * win.u
                            color: "#12ffffff"
                            border.width: 1; border.color: "#22ffffff"
                            Text {
                                anchors { fill: parent; margins: 30 * win.u }
                                wrapMode: Text.WordWrap
                                verticalAlignment: Text.AlignVCenter
                                lineHeight: 1.3
                                text: "Chưa chia sẻ file nào. Nhấn Enter để chọn file trên máy, điện thoại sẽ thấy và bấm tải về.\nMẹo: qs ipc call share send /đường/dẫn/file"
                                font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                color: "#9aa0b8"
                            }
                        }
                        Repeater {
                            model: Math.min(5, root.sendList.length)
                            delegate: Rectangle {
                                id: xrow
                                required property int index
                                readonly property int idx: sendCol.start + index
                                readonly property var it: root.sendList[idx]
                                readonly property bool sel: idx === root.sendSel
                                width: sendCol.width
                                height: 96 * win.u
                                radius: 20 * win.u
                                color: sel ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18) : "#12ffffff"
                                border.width: sel ? 2 * win.u : 1
                                border.color: sel ? root.accent : "#22ffffff"

                                Text {
                                    id: xicon
                                    anchors { left: parent.left; leftMargin: 22 * win.u; verticalCenter: parent.verticalCenter }
                                    text: xrow.it ? root.fileIcon(xrow.it.name) : ""
                                    font.pixelSize: 38 * win.u
                                }
                                Column {
                                    anchors { left: xicon.right; leftMargin: 20 * win.u; right: parent.right; rightMargin: 18 * win.u
                                              verticalCenter: parent.verticalCenter }
                                    spacing: 4 * win.u
                                    Text {
                                        width: parent.width
                                        elide: Text.ElideMiddle
                                        text: xrow.it ? xrow.it.name : ""
                                        font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                        font.weight: Font.Medium
                                        color: "#f7f2e6"
                                    }
                                    Text {
                                        width: parent.width
                                        elide: Text.ElideRight
                                        text: xrow.it ? (xrow.it.id === "" ? "Đang đăng ký…"
                                              : root.fmtBytes(xrow.it.size) + "  ·  " + (xrow.it.dl > 0 ? "đã tải " + xrow.it.dl + " lần" : "chưa ai tải")) : ""
                                        font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                                        color: "#9aa0b8"
                                    }
                                }
                            }
                        }
                    }

                    // ───── Tab GỬI: chọn file trên máy ─────
                    Column {
                        id: browseCol
                        visible: root.shareTab === "send" && root.browseOpen
                        property int start: Math.max(0, Math.min(root.browseSel - 3, root.browseItems.length - 8))
                        x: parent.width * 0.54
                        y: parent.height * 0.10
                        width: parent.width * 0.46 - 96 * win.u
                        spacing: 10 * win.u

                        Text {
                            text: "CHỌN FILE ĐỂ GỬI"
                            font.family: "Noto Sans"; font.pixelSize: 20 * win.u
                            font.letterSpacing: 5
                            color: "#d8b46a"
                        }
                        Text {
                            width: parent.width
                            elide: Text.ElideLeft
                            text: root.browseDir
                            font.family: "Noto Sans"; font.pixelSize: 19 * win.u
                            color: root.accent
                        }
                        Text {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            visible: root.sendMsg !== ""
                            text: root.sendMsg
                            font.family: "Noto Sans"; font.pixelSize: 19 * win.u
                            color: root.sendMsgBad ? "#ffb48a" : "#7fe3b4"
                        }
                        Text {
                            visible: root.browseItems.length === 0
                            text: "Thư mục trống hoặc không đọc được"
                            font.family: "Noto Sans"; font.pixelSize: 21 * win.u
                            color: "#9aa0b8"
                        }
                        Repeater {
                            model: Math.min(8, root.browseItems.length)
                            delegate: Rectangle {
                                id: brow
                                required property int index
                                readonly property int idx: browseCol.start + index
                                readonly property var it: root.browseItems[idx]
                                readonly property bool sel: idx === root.browseSel
                                width: browseCol.width
                                height: 62 * win.u
                                radius: 16 * win.u
                                color: sel ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18) : "#12ffffff"
                                border.width: sel ? 2 * win.u : 1
                                border.color: sel ? root.accent : "#22ffffff"

                                Text {
                                    id: bicon
                                    anchors { left: parent.left; leftMargin: 18 * win.u; verticalCenter: parent.verticalCenter }
                                    text: brow.it ? (brow.it.up ? "↰" : (brow.it.dir ? "📁" : root.fileIcon(brow.it.name))) : ""
                                    font.pixelSize: 28 * win.u
                                    color: "#f7f2e6"
                                }
                                Text {
                                    anchors { left: bicon.right; leftMargin: 16 * win.u; right: bsize.left; rightMargin: 12 * win.u
                                              verticalCenter: parent.verticalCenter }
                                    elide: Text.ElideMiddle
                                    text: brow.it ? (brow.it.up ? "Lên thư mục trên" : brow.it.name) : ""
                                    font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                    color: brow.it && brow.it.dir ? "#ffd9a0" : "#f7f2e6"
                                }
                                Text {
                                    id: bsize
                                    anchors { right: parent.right; rightMargin: 18 * win.u; verticalCenter: parent.verticalCenter }
                                    text: brow.it && !brow.it.dir ? root.fmtBytes(brow.it.size) : ""
                                    font.family: "Noto Sans"; font.pixelSize: 16 * win.u
                                    color: "#9aa0b8"
                                }
                            }
                        }
                    }

                    // Gợi ý phím: tab GỬI
                    Row {
                        visible: root.shareTab === "send" && !root.browseOpen
                        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 46 * win.u }
                        spacing: 34 * win.u
                        KeyHint { s: win.u; k: "↑  ↓"; t: "Chọn" }
                        KeyHint { s: win.u; k: "Enter"; t: "Thêm file" }
                        KeyHint { s: win.u; k: "D"; t: "Ngừng chia sẻ" }
                        KeyHint { s: win.u; k: "C"; t: "Xoá hết" }
                        KeyHint { s: win.u; k: "Tab"; t: "Sang Nhận" }
                        KeyHint { s: win.u; k: "Esc"; t: "Quay lại" }
                    }
                    Row {
                        visible: root.shareTab === "send" && root.browseOpen
                        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 46 * win.u }
                        spacing: 34 * win.u
                        KeyHint { s: win.u; k: "↑  ↓"; t: "Chọn" }
                        KeyHint { s: win.u; k: "Enter"; t: "Mở thư mục / Gửi file" }
                        KeyHint { s: win.u; k: "⌫"; t: "Lên trên" }
                        KeyHint { s: win.u; k: "."; t: "File ẩn" }
                        KeyHint { s: win.u; k: "Home"; t: "Thư mục nhà" }
                        KeyHint { s: win.u; k: "Esc"; t: "Xong" }
                    }

                    Row {
                        visible: root.shareTab === "recv"
                        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 46 * win.u }
                        spacing: 34 * win.u
                        KeyHint { s: win.u; k: "↑  ↓"; t: "Chọn" }
                        KeyHint { s: win.u; k: "Enter"; t: "Lưu" }
                        KeyHint { s: win.u; k: "A"; t: "Lưu tất cả" }
                        KeyHint { s: win.u; k: "D"; t: "Bỏ qua" }
                        KeyHint { s: win.u; k: "T"; t: "Bật / tắt" }
                        KeyHint { s: win.u; k: "Tab"; t: "Sang Gửi" }
                        KeyHint { s: win.u; k: "Esc"; t: "Quay lại" }
                    }

                    // ───── Đang cập nhật TV ─────
                    Item {
                        anchors.fill: parent
                        opacity: root.updState !== "" ? 1 : 0
                        visible: opacity > 0
                        Behavior on opacity { NumberAnimation { duration: 260 } }

                        Rectangle { anchors.fill: parent; color: "#f2040509" }
                        Rectangle {
                            anchors.centerIn: parent
                            width: 900 * win.u
                            height: ucol.implicitHeight + 90 * win.u
                            radius: 32 * win.u
                            color: "#f2101320"
                            border.width: 1; border.color: root.updState === "error" ? "#66ff8a6a" : "#44d8b46a"

                            Column {
                                id: ucol
                                anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 44 * win.u }
                                width: parent.width - 120 * win.u
                                spacing: 16 * win.u

                                Text {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    text: root.updState === "error" ? "CẬP NHẬT KHÔNG THÀNH CÔNG" : "CẬP NHẬT TV"
                                    font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                    font.letterSpacing: 8
                                    color: root.updState === "error" ? "#ff9a7a" : "#d8b46a"
                                }
                                Repeater {
                                    model: root.updSteps
                                    Text {
                                        required property var modelData
                                        required property int index
                                        text: (root.updState === "run" && index === root.updSteps.length - 1 ? "…   " : "✓   ") + modelData
                                        font.family: "Noto Sans"; font.pixelSize: 26 * win.u
                                        color: "#f4efe3"
                                    }
                                }
                                Text {
                                    visible: root.updState === "apply"
                                    width: parent.width
                                    wrapMode: Text.WordWrap
                                    lineHeight: 1.3
                                    text: "✓   Đã kiểm tra và sao lưu\nĐang thay thế bản " + root.updVer + " và khởi động lại giao diện. "
                                          + "Nếu bản mới không chạy được, TV tự khôi phục bản cũ."
                                    font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                    color: "#b4b9cc"
                                }
                                Text {
                                    visible: root.updState === "error"
                                    width: parent.width
                                    wrapMode: Text.WordWrap
                                    lineHeight: 1.3
                                    text: root.updText + "\nKhông có gì bị thay đổi trên TV."
                                    font.family: "Noto Sans"; font.pixelSize: 24 * win.u
                                    color: "#ffb48a"
                                }
                                Item { width: 1; height: 6 * win.u }
                                KeyHint {
                                    visible: root.updState === "error"
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    s: win.u; k: "Enter"; t: "Đóng"
                                }
                            }
                        }
                    }
                }


                // ───── Thông báo ─────
                Rectangle {
                    id: toast
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: root.toastText !== "" ? 56 * win.u : 30 * win.u
                    width: toastLabel.implicitWidth + 72 * win.u
                    height: 60 * win.u
                    radius: height / 2
                    color: "#e60d0f18"
                    border.width: 1; border.color: "#40d8b46a"
                    opacity: root.toastText !== "" ? 1 : 0
                    Behavior on opacity { NumberAnimation { duration: 220 } }
                    Behavior on y { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                    Text {
                        id: toastLabel
                        anchors.centerIn: parent
                        text: root.toastText
                        font.family: "Noto Sans"; font.pixelSize: 23 * win.u
                        color: "#f4efe3"
                    }
                }

                // ───── Bảng trợ giúp ─────
                Rectangle {
                    anchors.fill: parent
                    color: "#d9040509"
                    visible: opacity > 0
                    opacity: root.showHelp ? 1 : 0
                    Behavior on opacity { NumberAnimation { duration: 240 } }

                    Rectangle {
                        anchors.centerIn: parent
                        width: 980 * win.u; height: 640 * win.u
                        radius: 30 * win.u
                        color: "#f0101320"
                        border.width: 1; border.color: "#40d8b46a"
                        scale: root.showHelp ? 1 : 0.95
                        Behavior on scale { NumberAnimation { duration: 280; easing.type: Easing.OutCubic } }

                        Text {
                            anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 44 * win.u }
                            text: "PHÍM TẮT"
                            font.family: "Noto Sans"; font.pixelSize: 30 * win.u
                            font.weight: Font.Light; font.letterSpacing: 10
                            color: "#d8b46a"
                        }

                        Row {
                            anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 130 * win.u }
                            spacing: 40 * win.u
                            property var rows: [
                                ["Super + Home", "Mở / ẩn màn hình chính"],
                                ["Super + Backspace", "Đóng ứng dụng, về màn hình chính"],
                                ["Super + =  /  -", "Tăng / giảm âm lượng"],
                                ["Super + M", "Tắt / bật tiếng"],
                                ["←  →   Enter", "Chọn và mở ứng dụng"],
                                ["YouTube", "Mũi tên, Enter, Esc để quay lại"]
                            ]
                            Column {
                                Repeater {
                                    model: parent.parent.rows
                                    Text {
                                        required property var modelData
                                        width: 300 * win.u; height: 62 * win.u
                                        horizontalAlignment: Text.AlignRight
                                        verticalAlignment: Text.AlignVCenter
                                        text: modelData[0]
                                        font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                        font.weight: Font.DemiBold
                                        color: "#f4efe3"
                                    }
                                }
                            }
                            Column {
                                Repeater {
                                    model: parent.parent.rows
                                    Text {
                                        required property var modelData
                                        width: 480 * win.u; height: 62 * win.u
                                        verticalAlignment: Text.AlignVCenter
                                        text: modelData[1]
                                        font.family: "Noto Sans"; font.pixelSize: 22 * win.u
                                        color: "#a4aac0"
                                    }
                                }
                            }
                        }

                        Text {
                            anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 30 * win.u }
                            text: "Nhấn Esc để đóng"
                            font.family: "Noto Sans"; font.pixelSize: 17 * win.u
                            color: "#6f758c"
                        }
                    }
                }
            }
        }
    }

    // ───────── Thông báo có file mới khi launcher đang ẩn ─────────
    Variants {
        model: Quickshell.screens

        PanelWindow {
            id: noticeWin
            required property var modelData
            screen: modelData
            visible: root.noticeText !== "" && !root.shown
            color: "transparent"
            anchors { top: true; left: true; right: true }
            implicitHeight: 140 * u
            exclusionMode: ExclusionMode.Ignore
            WlrLayershell.layer: WlrLayer.Overlay
            WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
            WlrLayershell.namespace: "tv-notice"
            mask: Region {}
            readonly property real u: Math.max(0.5, modelData.height / 1080)

            Rectangle {
                anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 36 * noticeWin.u }
                width: ntxt.implicitWidth + 64 * noticeWin.u
                height: 64 * noticeWin.u
                radius: height / 2
                color: "#e60d0f18"
                border.width: 1; border.color: "#66ff8fb0"
                Text {
                    id: ntxt
                    anchors.centerIn: parent
                    text: root.noticeText
                    font.family: "Noto Sans"; font.pixelSize: 23 * noticeWin.u
                    color: "#f4efe3"
                }
            }
        }
    }

    // ───────── Thanh gợi ý phím nổi trên ứng dụng (Super+H để ẩn/hiện) ─────────
    Variants {
        model: Quickshell.screens

        PanelWindow {
            id: hintWin
            required property var modelData
            screen: modelData
            visible: root.hintsOn && !root.shown
            color: "transparent"
            anchors { left: true; right: true; bottom: true }
            implicitHeight: 150 * u
            exclusionMode: ExclusionMode.Ignore
            WlrLayershell.layer: WlrLayer.Overlay
            WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
            WlrLayershell.namespace: "tv-hints"
            mask: Region {}

            readonly property real u: Math.max(0.5, modelData.height / 1080)
            readonly property var hintList: root.hintKind === "cast" ? [["Super+Q", "Ngắt kết nối"], ["Super+H", "Ẩn gợi ý"]] : root.hintKind === "web"
                ? [["Ctrl+L", "Địa chỉ"], ["Tab", "Chuyển mục"], ["Enter", "Mở"], ["Space", "Cuộn"], ["Alt+←", "Trang trước"], ["Super+Q", "Thoát"], ["Super+H", "Ẩn gợi ý"]]
                : [["←↑↓→", "Di chuyển"], ["Enter", "Chọn"], ["Esc", "Quay lại"], ["Space", "Phát / dừng"], ["F", "Toàn màn hình"], ["Super+Q", "Thoát"], ["Super+H", "Ẩn gợi ý"]]

            Rectangle {
                anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 36 * hintWin.u }
                width: hrow.width + 56 * hintWin.u
                height: 66 * hintWin.u
                radius: height / 2
                color: "#e60d0f18"
                border.width: 1; border.color: "#55d8b46a"

                Row {
                    id: hrow
                    anchors.centerIn: parent
                    spacing: 30 * hintWin.u
                    Repeater {
                        model: hintWin.hintList
                        delegate: KeyHint {
                            required property var modelData
                            s: hintWin.u
                            k: modelData[0]
                            t: modelData[1]
                        }
                    }
                }
            }
        }
    }
}
