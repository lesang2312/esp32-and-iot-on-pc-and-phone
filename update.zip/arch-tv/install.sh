#!/usr/bin/env bash
# Cài đặt Arch TV (Hyprland Lua + Quickshell) kèm âm thanh và Wi-Fi
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
HYPR="$HOME/.config/hypr"
MARK_BEGIN="-- >>> ARCH TV BEGIN"
MARK_END="-- <<< ARCH TV END"

if [ "$(id -u)" -eq 0 ]; then
    echo "Hãy chạy script bằng user thường (không dùng root/sudo)."
    exit 1
fi

echo "==> [1/6] Cài gói: Hyprland, trình duyệt, font, âm thanh, Wi-Fi"
sudo pacman -Syu --needed --noconfirm \
    hyprland chromium noto-fonts noto-fonts-cjk noto-fonts-emoji \
    pipewire pipewire-pulse pipewire-alsa pipewire-jack wireplumber alsa-utils \
    networkmanager iw wireless_tools rfkill linux-firmware \
    libva-utils polkit \
    avahi nss-mdns android-tools scrcpy python unzip findutils \
    gst-plugins-base gst-plugins-good gst-plugins-bad gst-libav
# iPhone chia sẻ mạng qua USB cần usbmuxd (Android dùng sẵn trình điều khiển của nhân Linux)
sudo pacman -S --needed --noconfirm usbmuxd libimobiledevice || echo "    (bỏ qua usbmuxd)"
# Giải mã video bằng GPU (không bắt buộc)
sudo pacman -S --needed --noconfirm gst-plugin-va || echo "    (bỏ qua gst-plugin-va)"

# Cấu hình Lua cần Hyprland 0.55 trở lên
ver="$(Hyprland --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1 || true)"
if [ -n "$ver" ]; then
    major="${ver%%.*}"; rest="${ver#*.}"; minor="${rest%%.*}"
    if [ "$major" -eq 0 ] && [ "$minor" -lt 55 ]; then
        echo "Hyprland $ver chưa hỗ trợ hyprland.lua (cần >= 0.55)."
        echo "Hãy cập nhật hệ thống (sudo pacman -Syu) hoặc dùng hyprland-git rồi chạy lại."
        exit 1
    fi
    echo "    Hyprland $ver"
fi

echo "==> [2/6] Cài Quickshell"
if ! command -v qs >/dev/null 2>&1; then
    if pacman -Si quickshell >/dev/null 2>&1; then
        sudo pacman -S --needed --noconfirm quickshell
    elif command -v yay >/dev/null 2>&1; then
        yay -S --needed --noconfirm quickshell-git
    elif command -v paru >/dev/null 2>&1; then
        paru -S --needed --noconfirm quickshell-git
    else
        echo "Không tìm thấy quickshell. Hãy cài 'quickshell' hoặc 'quickshell-git' (AUR) rồi chạy lại."
        exit 1
    fi
fi

echo "==> [+] Truyền màn hình (AirPlay + Android qua Wi-Fi)"
if ! command -v uxplay >/dev/null 2>&1; then
    if pacman -Si uxplay >/dev/null 2>&1; then
        sudo pacman -S --needed --noconfirm uxplay
    elif command -v yay >/dev/null 2>&1; then
        yay -S --needed --noconfirm uxplay
    elif command -v paru >/dev/null 2>&1; then
        paru -S --needed --noconfirm uxplay
    else
        echo "    Không tìm thấy 'uxplay'. Cài từ AUR (yay -S uxplay) rồi chạy lại để dùng AirPlay."
    fi
fi
# avahi giúp iPhone/Mac tìm thấy TV trong mạng
sudo systemctl enable --now avahi-daemon.service || true
# Mở cổng AirPlay nếu máy đang dùng ufw
if command -v ufw >/dev/null 2>&1 && sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    sudo ufw allow 7000,7001,7100/tcp
    sudo ufw allow 6000,6001,7011/udp
    sudo ufw allow 5353/udp
    sudo ufw allow 8765:8774/tcp      # gửi/nhận file với điện thoại (Wi-Fi hoặc cáp USB)
fi
if command -v firewall-cmd >/dev/null 2>&1 && sudo firewall-cmd --state >/dev/null 2>&1; then
    sudo firewall-cmd --permanent --add-port=8765-8774/tcp && sudo firewall-cmd --reload || true
fi

echo "==> [3/6] Bật dịch vụ âm thanh"
systemctl --user enable --now pipewire.socket pipewire-pulse.socket wireplumber.service || true
wpctl set-mute @DEFAULT_AUDIO_SINK@ 0 2>/dev/null || true
wpctl set-volume @DEFAULT_AUDIO_SINK@ 70% 2>/dev/null || true

echo "==> [4/6] Bật dịch vụ Wi-Fi (NetworkManager)"
sudo systemctl disable --now iwd.service 2>/dev/null || true
sudo systemctl enable --now NetworkManager.service
sudo rfkill unblock wifi 2>/dev/null || true
sudo nmcli radio wifi on 2>/dev/null || true
sudo tee /etc/polkit-1/rules.d/50-arch-tv-network.rules >/dev/null <<'EOF'
polkit.addRule(function(action, subject) {
    if (action.id.indexOf("org.freedesktop.NetworkManager.") == 0 && subject.local && subject.active) {
        return polkit.Result.YES;
    }
});
EOF

echo "==> [5/6] Chép giao diện Quickshell"
QS="$HOME/.config/quickshell"      # shell nằm thẳng ở ~/.config/quickshell/shell.qml (chạy bằng: qs)
mkdir -p "$QS" "$HYPR"
# Đã có shell.qml khác (không phải của Arch TV) thì sao lưu trước khi ghi đè
if [ -f "$QS/shell.qml" ] && ! grep -q "Arch TV" "$QS/shell.qml"; then
    cp "$QS/shell.qml" "$QS/shell.qml.bak"
    echo "    Đã sao lưu shell.qml cũ thành shell.qml.bak"
fi
cp "$HERE/shell.qml" "$QS/shell.qml"
for f in android-cast.sh share.py tv-update.sh tv.lua VERSION; do
    [ -f "$HERE/$f" ] && cp "$HERE/$f" "$QS/$f"
done
chmod +x "$QS/tv-update.sh"; [ -f "$QS/android-cast.sh" ] && chmod +x "$QS/android-cast.sh"
[ -d "$QS/tv" ] && echo "    Bản cũ ở $QS/tv không còn dùng, có thể xoá: rm -r $QS/tv"
mkdir -p "$HOME/Downloads" "$HOME/Share/send"

echo "==> [6/6] Cấu hình Hyprland (hyprland.lua)"
# Khối cấu hình TV, bọc trong marker để cập nhật lại nhiều lần không bị trùng
block="$(mktemp)"
{
    echo "$MARK_BEGIN"
    cat "$HERE/tv.lua"
    echo "$MARK_END"
} > "$block"

LUA="$HYPR/hyprland.lua"
if [ -f "$LUA" ]; then
    cp "$LUA" "$LUA.bak"
    if grep -qF -- "$MARK_BEGIN" "$LUA"; then
        # Thay khối cũ bằng khối mới
        awk -v b="$MARK_BEGIN" -v e="$MARK_END" -v f="$block" '
            index($0, b) { while ((getline line < f) > 0) print line; skip = 1; next }
            index($0, e) { skip = 0; next }
            !skip { print }
        ' "$LUA.bak" > "$LUA"
        echo "    Đã cập nhật khối Arch TV trong hyprland.lua"
    else
        { echo; cat "$block"; } >> "$LUA"
        echo "    Đã thêm khối Arch TV vào hyprland.lua có sẵn"
    fi
else
    if [ -f "$HYPR/hyprland.conf" ]; then
        cp "$HYPR/hyprland.conf" "$HYPR/hyprland.conf.bak"
        echo "    Lưu ý: hyprland.lua mới sẽ được ưu tiên hơn hyprland.conf."
        echo "    Cấu hình cũ đã được sao lưu ở hyprland.conf.bak (monitor, input... cần chuyển sang Lua)."
        echo "    Gợi ý: dùng 'hyprlang2lua' (AUR) để chuyển tự động."
    fi
    {
        echo "-- ~/.config/hypr/hyprland.lua"
        echo 'hl.env("XCURSOR_SIZE", "24")'
        echo 'hl.env("HYPRCURSOR_SIZE", "24")'
        echo
        cat "$block"
    } > "$LUA"
    echo "    Đã tạo hyprland.lua mới"
fi
rm -f "$block"

echo
echo "Xong! Đăng xuất rồi vào lại Hyprland (hoặc chạy thử: qs)."
echo "Kiểm tra âm thanh: wpctl status    |    Kiểm tra Wi-Fi: nmcli dev wifi"
echo "Đăng nhập YouTube lần đầu bằng mã trên điện thoại: youtube.com/activate"
