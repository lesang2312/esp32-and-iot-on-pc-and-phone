#!/usr/bin/env python3
"""Máy chủ nhận file từ điện thoại trong cùng mạng Wi-Fi cho Arch TV (chỉ dùng thư viện chuẩn của Python).

Shell (Quickshell) chạy file này nền. Điện thoại mở  http://<IP TV>:8765  rồi bấm "Gửi".
File được lưu TẠM vào thư mục inbox; TV hiện hàng chờ, chỉ khi bấm Lưu mới chuyển vào Downloads.
File tên update.zip là bản cập nhật cho chính TV: bắt buộc nhập "mã cập nhật" hiện trên màn hình TV (dùng một lần),
vì cập nhật chạy được mã trên máy. Có PIN cố định (share.pin hoặc SHARE_PIN) thì mọi file đều phải nhập PIN đó.

Giao tiếp với shell:
  stdout  mỗi dòng một JSON:  {"ev":"ready",...} | {"ev":"file",...} | {"ev":"pin",...} | {"ev":"error","msg":...}
  stdin   mỗi dòng một lệnh:  "saved <batch>" | "skipped <batch>"  (điện thoại sẽ thấy kết quả)
          "offer <đường dẫn file>" | "unoffer <id>" | "unofferall"   (GỬI file từ máy sang điện thoại)
  Gửi file: file được "offer" hiện trong mục "Tải từ TV" ở trang web; điện thoại bấm để tải (có tải tiếp khi đứt).
  Mạng: ưu tiên địa chỉ của cổng USB (điện thoại cắm cáp, bật chia sẻ mạng qua USB), tự cập nhật khi cắm/rút cáp.
  stdin đóng (shell tắt) -> máy chủ tự thoát.

Dùng thử không cần shell:  python3 share.py --inbox /tmp/inbox --no-stdin
"""
import argparse
import hmac
import zipfile
import random
import json
import mimetypes
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

MAX_BYTES = 500 * 1024 * 1024
OUT_LOCK = threading.Lock()
STATUS = {}                      # batch -> "pending" | "saved" | "skipped"
STATUS_LOCK = threading.Lock()
PIN = ""
UPDATE_PIN = ""                  # mã dùng một lần cho update.zip (= PIN nếu đã đặt PIN cố định)
INBOX = ""
OFFERS = {}                      # id -> {id, path, name, size, dl}: file máy đang chia sẻ cho điện thoại
OFFER_LOCK = threading.Lock()
PORT = 0
UPD_FAILS = []                   # thời điểm các lần nhập sai mã cập nhật (chặn dò mã)


def emit(obj):
    with OUT_LOCK:
        try:
            sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
            sys.stdout.flush()
        except (BrokenPipeError, ValueError):
            os._exit(0)


# ---------------------------------------------------------------- QR (phiên bản 1-6, mức sửa lỗi L)
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]

# version: (số khối, số byte dữ liệu mỗi khối, số byte sửa lỗi mỗi khối)
_QR_VER = {1: (1, 19, 7), 2: (1, 34, 10), 3: (1, 55, 15), 4: (1, 80, 20), 5: (1, 108, 26), 6: (2, 68, 18)}
_QR_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34]}


def _gmul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _rs_remainder(data, n):
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            ng[j + 1] ^= _gmul(c, _EXP[i])
        g = ng
    res = [0] * n
    for b in data:
        f = b ^ res[0]
        res = res[1:] + [0]
        for i in range(n):
            res[i] ^= _gmul(g[i + 1], f)
    return res


def qr_matrix(text):
    """Trả về danh sách các dòng '0'/'1' (1 = ô tối), hoặc [] nếu chữ quá dài."""
    data = text.encode("utf-8")
    ver = 0
    for v, (nb, dcw, _ec) in _QR_VER.items():
        if len(data) <= nb * dcw - 2:
            ver = v
            break
    if not ver:
        return []
    nblocks, dcw, ecw = _QR_VER[ver]
    cap = nblocks * dcw
    bits = "0100" + format(len(data), "08b") + "".join(format(b, "08b") for b in data)
    bits += "0" * min(4, cap * 8 - len(bits))
    bits += "0" * (-len(bits) % 8)
    cw = [int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)]
    pad = [0xEC, 0x11]
    while len(cw) < cap:
        cw.append(pad[(len(cw) - len(bits) // 8) % 2])
    blocks = [cw[i * dcw:(i + 1) * dcw] for i in range(nblocks)]
    ecs = [_rs_remainder(b, ecw) for b in blocks]
    final = []
    for i in range(dcw):
        for b in blocks:
            final.append(b[i])
    for i in range(ecw):
        for e in ecs:
            final.append(e[i])
    size = 17 + 4 * ver
    mod = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]

    def setf(x, y, v):
        mod[y][x] = v
        fn[y][x] = True

    for i in range(size):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                xx, yy = cx + dx, cy + dy
                if 0 <= xx < size and 0 <= yy < size:
                    setf(xx, yy, max(abs(dx), abs(dy)) not in (2, 4))
    pos = _QR_ALIGN[ver]
    for i, py in enumerate(pos):
        for j, px in enumerate(pos):
            if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(px + dx, py + dy, max(abs(dx), abs(dy)) != 1)

    def put_format(mask):
        d = (1 << 3) | mask                      # mức L = 01
        rem = d
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        fb = ((d << 10) | rem) ^ 0x5412
        bit = lambda i: ((fb >> i) & 1) != 0
        for i in range(6):
            setf(8, i, bit(i))
        setf(8, 7, bit(6))
        setf(8, 8, bit(7))
        setf(7, 8, bit(8))
        for i in range(9, 15):
            setf(14 - i, 8, bit(i))
        for i in range(8):
            setf(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, bit(i))
        setf(8, size - 8, True)

    put_format(0)                                # đánh dấu vùng chức năng trước khi đặt dữ liệu
    i = 0
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not fn[y][x] and i < len(final) * 8:
                    mod[y][x] = ((final[i >> 3] >> (7 - (i & 7))) & 1) != 0
                    i += 1
        right -= 2

    masks = (lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
             lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
             lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
             lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0)

    def penalty(m):
        p = 0
        for grid in (m, [list(r) for r in zip(*m)]):
            for row in grid:
                run = 1
                for k in range(1, size):
                    if row[k] == row[k - 1]:
                        run += 1
                    else:
                        if run >= 5:
                            p += 3 + run - 5
                        run = 1
                if run >= 5:
                    p += 3 + run - 5
        for y in range(size - 1):
            for x in range(size - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    p += 3
        dark = sum(r.count(True) for r in m)
        p += (abs(dark * 20 - size * size * 10) // (size * size)) * 10
        return p

    best, best_m, best_p = 0, None, None
    for mk in range(8):
        m = [row[:] for row in mod]
        f = masks[mk]
        for y in range(size):
            for x in range(size):
                if not fn[y][x] and f(x, y):
                    m[y][x] = not m[y][x]
        pen = penalty(m)
        if best_p is None or pen < best_p:
            best, best_m, best_p = mk, m, pen
    mod = best_m
    put_format(best)
    return ["".join("1" if c else "0" for c in row) for row in mod]


# ---------------------------------------------------------------- mạng / tệp
_SKIP_IF = ("docker", "veth", "br-", "virbr", "tailscale", "zt", "wg", "tun", "tap")


def _is_usb_iface(name):
    """Card mạng nằm trên cổng USB (điện thoại chia sẻ mạng qua cáp: Android RNDIS/CDC, iPhone ipheth...)."""
    if name.startswith(("usb", "rndis")):
        return True
    try:
        if "/usb" in os.path.realpath("/sys/class/net/%s/device" % name):
            return True
    except OSError:
        pass
    try:
        with open("/sys/class/net/%s/device/uevent" % name, encoding="utf-8", errors="replace") as fh:
            if re.search(r"DRIVER=(rndis_host|cdc_ether|cdc_ncm|cdc_eem|ipheth)", fh.read()):
                return True
    except OSError:
        pass
    return False


def lan_info():
    """[{ip, iface, usb}], card USB đứng đầu, rồi card đang ra internet, rồi các card còn lại."""
    items = []
    try:
        out = subprocess.run(["ip", "-4", "-o", "addr", "show", "scope", "global"], capture_output=True,
                             text=True, timeout=3).stdout
        for m in re.finditer(r"^\d+:\s+([^\s@]+)\S*\s+inet (\d+\.\d+\.\d+\.\d+)/", out, re.M):
            name, ip = m.group(1), m.group(2)
            if name.startswith(_SKIP_IF) or any(i["ip"] == ip for i in items):
                continue
            items.append({"ip": ip, "iface": name, "usb": _is_usb_iface(name)})
    except (OSError, subprocess.SubprocessError):
        pass
    primary = ""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))          # không gửi gói nào, chỉ để hệ điều hành chọn card mạng
        primary = s.getsockname()[0]
        s.close()
    except OSError:
        pass
    if primary and not primary.startswith("127.") and not any(i["ip"] == primary for i in items):
        items.append({"ip": primary, "iface": "", "usb": False})
    items.sort(key=lambda i: (not i["usb"], i["ip"] != primary))
    return items or [{"ip": "127.0.0.1", "iface": "lo", "usb": False}]


def lan_ips():
    return [i["ip"] for i in lan_info()]


def ready_payload(ev="ready"):
    info = lan_info()
    urls = ["http://%s:%d" % (i["ip"], PORT) for i in info]
    return {"ev": ev, "port": PORT, "ips": [i["ip"] for i in info], "ifaces": info, "usb": bool(info[0]["usb"]),
            "url": urls[0], "urls": urls, "qr": qr_matrix(urls[0]), "pin": bool(PIN), "updpin": UPDATE_PIN}


def net_watch():
    """Cắm / rút cáp USB hoặc đổi Wi-Fi thì địa chỉ đổi theo: báo cho shell cập nhật địa chỉ và mã QR."""
    def sig():
        return json.dumps([(i["ip"], i["iface"]) for i in lan_info()])
    last = sig()
    while True:
        time.sleep(3)
        try:
            cur = sig()
        except Exception:
            continue
        if cur != last:
            last = cur
            emit(ready_payload("net"))


# ---------------------------------------------------------------- gửi file từ máy sang điện thoại
def offer_add(path):
    try:
        real = os.path.realpath(path)
        if not os.path.isfile(real) or not os.access(real, os.R_OK):
            raise OSError("không đọc được")
        size = os.path.getsize(real)
    except OSError:
        emit({"ev": "offer_err", "msg": "Không đọc được file: " + os.path.basename(path)})
        return
    with OFFER_LOCK:
        item = next((o for o in OFFERS.values() if o["path"] == real), None)
        if item is None:
            item = {"id": uuid.uuid4().hex[:8], "path": real, "name": os.path.basename(real), "size": size, "dl": 0}
            OFFERS[item["id"]] = item
        item["size"] = size
    emit({"ev": "offer", "id": item["id"], "name": item["name"], "size": size, "path": real, "dl": item["dl"]})


def offer_drop(oid, why=""):
    with OFFER_LOCK:
        gone = OFFERS.pop(oid, None)
    if gone:
        emit({"ev": "unoffer", "id": oid, "msg": why})


def sniff(head):
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    return ""


def safe_name(orig, kind, stamp):
    """Tên file an toàn: bỏ đường dẫn, ký tự lạ; ảnh thì ép đuôi đúng với nội dung thật."""
    name = os.path.basename(orig.replace("\\", "/"))
    stem, ext = os.path.splitext(name)
    stem = re.sub(r"[^\w\-. ()]", "_", stem, flags=re.UNICODE).strip(" ._")[:80]
    ext = re.sub(r"[^A-Za-z0-9]", "", ext)[:10].lower()
    if kind:
        ext = kind
    if not stem or stem.lower() in ("image", "photo", "blob", "img", "download", "unknown", "file"):
        stem = ("anh-" if kind else "file-") + stamp
    return stem + ("." + ext if ext else "")


def device_name(ua):
    m = re.search(r"Android[^;)]*;\s*([^;)]+?)(?:\sBuild|[;)])", ua)
    if m and m.group(1).strip() and m.group(1).strip() != "K":
        return m.group(1).strip()[:30]
    for key in ("iPhone", "iPad", "Android", "Windows", "Macintosh", "Linux"):
        if key in ua:
            return key
    return ""


def clean_old(inbox):
    now = time.time()
    try:
        for d in os.listdir(inbox):
            p = os.path.join(inbox, d)
            if os.path.isdir(p) and now - os.path.getmtime(p) > 12 * 3600:
                shutil.rmtree(p, ignore_errors=True)
    except OSError:
        pass


SYSTEM_FILES = ("shell.qml", "android-cast.sh", "share.py", "tv-update.sh", "tv.lua")
TV_DIR = os.path.dirname(os.path.abspath(__file__))


def zip_changes(path):
    """Số file hệ thống trong zip khác bản đang chạy (-1 nếu zip lỗi). Không giải nén ra đĩa."""
    n = 0
    try:
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                parts = info.filename.replace("\\", "/").split("/")
                if info.is_dir() or ".." in parts or info.filename.startswith("/") or len(parts) > 3:
                    continue
                base = parts[-1]
                if base not in SYSTEM_FILES or info.file_size > 5 * 1024 * 1024:
                    continue
                new = z.read(info)
                try:
                    with open(os.path.join(TV_DIR, base), "rb") as fh:
                        if fh.read() == new:
                            continue
                except OSError:
                    pass
                n += 1
    except (zipfile.BadZipFile, OSError, RuntimeError):
        return -1
    return n


def new_update_pin():
    return "%06d" % random.SystemRandom().randrange(1000000)


PAGE = r"""<!doctype html>
<html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#11111b"><title>File giữa điện thoại và TV</title>
<style>
:root{--bg:#11111b;--card:#1e1e2e;--line:#313244;--fg:#cdd6f4;--dim:#9399b2;--ac:#89b4fa;--ok:#a6e3a1;--bad:#f38ba8}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:radial-gradient(120% 60% at 50% 0,#1b1d33 0,var(--bg) 60%) fixed;color:var(--fg);
 font:16px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;min-height:100vh;
 padding:max(18px,env(safe-area-inset-top)) 16px max(24px,env(safe-area-inset-bottom))}
main{max-width:520px;margin:0 auto}
h1{font-size:22px;margin:6px 0 2px}.sub{color:var(--dim);font-size:14px;margin:0 0 18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:22px;padding:16px;margin-bottom:14px}
.drop{border:2px dashed #45475a;border-radius:18px;padding:26px 12px;text-align:center;color:var(--dim)}
.drop.on{border-color:var(--ac);background:#89b4fa14}
.row{display:flex;gap:10px;margin-top:12px}
button,label.btn{flex:1;border:0;border-radius:16px;padding:15px 12px;font:600 16px system-ui;color:var(--fg);
 background:#313244;text-align:center;cursor:pointer;display:block}
button.pri{background:var(--ac);color:#11111b}button:disabled{opacity:.45}
input[type=file]{display:none}
.dl a{display:flex;align-items:center;gap:10px;padding:13px 14px;margin-top:8px;border-radius:16px;background:#313244;
 color:var(--fg);text-decoration:none;font-weight:600}
.dl a span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dl a small{color:var(--dim);font-weight:400}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:14px}
.th{position:relative;aspect-ratio:1;border-radius:14px;overflow:hidden;background:#181825}
.th img{width:100%;height:100%;object-fit:cover}
.th b{position:absolute;top:4px;right:4px;width:26px;height:26px;border-radius:50%;background:#000a;color:#fff;
 text-align:center;line-height:26px;font-size:15px}
.bar{height:8px;border-radius:4px;background:#313244;overflow:hidden;margin-top:14px;display:none}
.bar i{display:block;height:100%;width:0;background:var(--ac);transition:width .15s}
#msg{margin-top:12px;text-align:center;min-height:24px}.ok{color:var(--ok)}.bad{color:var(--bad)}
input[type=password],input[type=text]{width:100%;border:1px solid var(--line);background:#181825;color:var(--fg);
 border-radius:14px;padding:13px;font-size:17px;text-align:center;letter-spacing:4px}
</style></head><body><main>
<h1>📲 File giữa điện thoại và TV</h1>
<p class="sub" id="host">Cùng mạng Wi-Fi với TV</p>
<div class="card" id="pinbox" style="display:none"><div class="sub" id="pinlbl">Nhập mã PIN hiển thị trên TV</div>
<input id="pin" type="password" inputmode="numeric" autocomplete="off" placeholder="••••"></div>
<div class="card dl" id="dlbox" style="display:none"><div class="sub" style="margin:0">⬇️ TV đang chia sẻ cho bạn — bấm để tải</div><div id="dllist"></div></div>
<div class="card">
 <div class="drop" id="drop">Chọn file hoặc chụp ảnh mới<br><small>Mọi loại file, tối đa 500 MB mỗi file.<br>Gửi <b>update.zip</b> để cập nhật TV (chỉ ghi đè file có thay đổi; cần mã nếu có file hệ thống đổi)</small></div>
 <div class="row">
  <label class="btn" for="f1">📁 Chọn file</label>
  <label class="btn" for="f2">📷 Chụp ảnh</label>
 </div>
 <input id="f1" type="file" multiple><input id="f2" type="file" accept="image/*" capture="environment">
 <div class="grid" id="grid"></div>
 <div class="bar" id="bar"><i id="fill"></i></div>
 <div class="row"><button class="pri" id="send" disabled>Gửi</button></div>
 <div id="msg"></div>
</div></main>
<script>
const $=id=>document.getElementById(id);
let files=[],pinNeeded=false;
const isUpd=f=>/^update\.zip$/i.test(f.name||'');
const MAX=500*1024*1024;
try{$('pin').value=localStorage.getItem('sharepin')||''}catch(e){}
function fmt(n){return n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':n<1073741824?(n/1048576).toFixed(1)+' MB':(n/1073741824).toFixed(2)+' GB'}
function loadList(){
 if(pinNeeded&&!$('pin').value){$('dlbox').style.display='none';return}
 fetch('/list',{headers:pinNeeded?{'X-Pin':$('pin').value}:{}}).then(r=>r.ok?r.json():[]).then(rows=>{
  const box=$('dllist');box.innerHTML='';$('dlbox').style.display=rows.length?'block':'none';
  rows.forEach(f=>{const a=document.createElement('a');
   a.href='/dl/'+f.id+'/'+encodeURIComponent(f.name)+(pinNeeded?'?pin='+encodeURIComponent($('pin').value):'');
   a.setAttribute('download',f.name);
   const i=document.createElement('b');i.textContent='⬇️';const n=document.createElement('span');n.textContent=f.name;
   const z=document.createElement('small');z.textContent=fmt(f.size);a.append(i,n,z);box.appendChild(a)})}).catch(()=>{})}
setInterval(loadList,4000);$('pin').addEventListener('input',loadList);
fetch('/info').then(r=>r.json()).then(j=>{pinNeeded=j.pin;showPin();loadList();
 if(j.name)$('host').textContent='Gửi tới TV "'+j.name+'" trong cùng Wi-Fi'}).catch(()=>{});
let forcePin=false;
function needPin(){return pinNeeded||forcePin}
function showPin(){$('pinbox').style.display=needPin()?'block':'none';
 $('pinlbl').textContent=pinNeeded?'Nhập mã PIN hiển thị trên TV':'Nhập mã cập nhật hiện trên màn hình TV'}
function say(t,c){$('msg').textContent=t;$('msg').className=c||''}
function render(){
 const g=$('grid');g.innerHTML='';
 files.forEach((f,i)=>{const d=document.createElement('div');d.className='th';
  if(/^image\//.test(f.type)){const im=document.createElement('img');im.src=URL.createObjectURL(f);d.appendChild(im)}
  else{const t=document.createElement('div');t.style.cssText='height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:12px;color:#9399b2;padding:6px;text-align:center;word-break:break-all';
   t.innerHTML='<div style="font-size:28px">📄</div>';t.appendChild(document.createTextNode(f.name.slice(-18)));d.appendChild(t)}
  const x=document.createElement('b');x.textContent='×';x.onclick=()=>{files.splice(i,1);render()};d.appendChild(x);g.appendChild(d)});
 $('send').disabled=!files.length;$('send').textContent=files.length?'Gửi '+files.length+' file':'Gửi';showPin();
}
function add(list){
 for(const f of list){
  if(f.size>MAX){say(f.name+' lớn hơn 500 MB','bad');continue}
  files.push(f)}
 render()}
$('f1').onchange=e=>{add(e.target.files);e.target.value=''};
$('f2').onchange=e=>{add(e.target.files);e.target.value=''};
const dr=$('drop');
['dragover','dragenter'].forEach(n=>dr.addEventListener(n,e=>{e.preventDefault();dr.classList.add('on')}));
['dragleave','drop'].forEach(n=>dr.addEventListener(n,e=>{e.preventDefault();dr.classList.remove('on')}));
dr.addEventListener('drop',e=>add(e.dataTransfer.files));
function one(f,batch,pr){return new Promise((ok,no)=>{
 const x=new XMLHttpRequest();x.open('POST','/up');
 x.setRequestHeader('X-Name',encodeURIComponent(f.name||'image'));x.setRequestHeader('X-Batch',batch);
 if(needPin())x.setRequestHeader('X-Pin',$('pin').value);
 x.upload.onprogress=e=>{if(e.lengthComputable)pr(e.loaded/e.total)};
 x.onload=()=>{if(x.status==200)ok();else{let m='Lỗi '+x.status,np=false;try{const j=JSON.parse(x.responseText);m=j.error||m;np=!!j.needpin}catch(e){}const er=new Error(m);er.needpin=np;no(er)}};
 x.onerror=()=>no(new Error('Mất kết nối tới TV'));x.send(f)})}
$('send').onclick=async()=>{
 if(!files.length)return;
 try{if(pinNeeded)localStorage.setItem('sharepin',$('pin').value)}catch(e){}
 const batch=Date.now().toString(36)+Math.random().toString(36).slice(2,8);
 $('send').disabled=true;$('bar').style.display='block';say('Đang gửi…');
 const n=files.length;
 try{
  for(let i=0;i<n;i++){await one(files[i],batch,p=>{$('fill').style.width=((i+p)/n*100)+'%'});say('Đã gửi '+(i+1)+'/'+n)}
  $('fill').style.width='100%';files=[];render();say('Đã gửi ✓ — chờ TV nhận…','ok');poll(batch,0)
 }catch(e){if(e.needpin){forcePin=true;showPin();$('pin').focus();say(e.message+'. Nhập mã rồi bấm Gửi lại.','bad')}else say(e.message,'bad');$('send').disabled=!files.length}
 setTimeout(()=>{$('bar').style.display='none';$('fill').style.width='0'},1200)};
function poll(b,k){
 fetch('/s/'+b).then(r=>r.json()).then(j=>{
  if(j.state=='saved')say('TV đã nhận ✓','ok');
  else if(j.state=='skipped')say('TV đã bỏ qua','bad');
  else if(k<90)setTimeout(()=>poll(b,k+1),1000);
  else say('Đã gửi ✓','ok')}).catch(()=>{})}
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    timeout = 60
    server_version = "qs-share"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _err(self, code, msg, **extra):
        self._send(code, json.dumps(dict({"ok": False, "error": msg}, **extra), ensure_ascii=False))

    def _pin_ok(self):
        if not PIN:
            return True
        got = self.headers.get("X-Pin", "") or parse_qs(urlparse(self.path).query).get("pin", [""])[0]
        return hmac.compare_digest(got.encode("utf-8"), PIN.encode("utf-8"))

    def _download(self, path):
        if not self._pin_ok():
            self.close_connection = True
            self._err(403, "Sai mã PIN")
            return
        oid = re.sub(r"[^A-Za-z0-9]", "", path[4:].split("/")[0])[:16]
        with OFFER_LOCK:
            o = OFFERS.get(oid)
        if not o:
            self._err(404, "File này TV không còn chia sẻ")
            return
        try:
            fh = open(o["path"], "rb")
            size = os.fstat(fh.fileno()).st_size
        except OSError:
            offer_drop(oid, "File không còn trên máy")
            self._err(404, "File không còn trên TV")
            return
        ok = True
        with fh:
            start, end, code = 0, size - 1, 200
            m = re.match(r"bytes=(\d*)-(\d*)$", self.headers.get("Range", "").strip())
            if m and (m.group(1) or m.group(2)) and size > 0:
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                else:
                    start = max(0, size - int(m.group(2)))
                if start >= size or start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", "bytes */%d" % size)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                end = min(end, size - 1)
                code = 206
            length = max(0, end - start + 1)
            ascii_name = re.sub(r'[^\x20-\x7e]|["\\]', "_", o["name"])
            self.send_response(code)
            self.send_header("Content-Type", mimetypes.guess_type(o["name"])[0] or "application/octet-stream")
            self.send_header("Content-Length", str(length))
            self.send_header("Accept-Ranges", "bytes")
            if code == 206:
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            self.send_header("Content-Disposition",
                             "attachment; filename=\"%s\"; filename*=UTF-8''%s" % (ascii_name, quote(o["name"])))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            emit({"ev": "dl", "id": oid, "name": o["name"], "from": self.client_address[0]})
            fh.seek(start)
            left = length
            try:
                while left > 0:
                    chunk = fh.read(min(left, 1 << 20))
                    if not chunk:
                        ok = False
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (OSError, ConnectionError):
                ok = False
        if not ok:
            self.close_connection = True
            return
        if size == 0 or end >= size - 1:
            with OFFER_LOCK:
                o["dl"] += 1
                n = o["dl"]
            emit({"ev": "sent", "id": oid, "name": o["name"], "dl": n, "from": self.client_address[0],
                  "dev": device_name(self.headers.get("User-Agent", ""))})

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif path == "/info":
            self._send(200, json.dumps({"pin": bool(PIN), "name": socket.gethostname()}))
        elif path.startswith("/s/"):
            b = re.sub(r"[^A-Za-z0-9]", "", path[3:])[:24]
            with STATUS_LOCK:
                st = STATUS.get(b, "none")
            self._send(200, json.dumps({"state": st}))
        elif path == "/list":
            if not self._pin_ok():
                self._err(403, "Sai mã PIN")
                return
            with OFFER_LOCK:
                rows = [{"id": o["id"], "name": o["name"], "size": o["size"]} for o in OFFERS.values()]
            self._send(200, json.dumps(rows, ensure_ascii=False))
        elif path.startswith("/dl/"):
            self._download(path)
        elif path == "/favicon.ico":
            self._send(204, b"", "image/x-icon")
        else:
            self._err(404, "Không có trang này")

    def do_POST(self):
        if urlparse(self.path).path != "/up":
            self._err(404, "Không có trang này")
            return
        got = self.headers.get("X-Pin", "")
        is_update = os.path.basename(unquote(self.headers.get("X-Name", "")).replace("\\", "/")).lower() == "update.zip"
        if PIN and not hmac.compare_digest(got, PIN):
            self.close_connection = True
            self._err(403, "Sai mã PIN")
            return
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            length = -1
        if length <= 0:
            self.close_connection = True
            self._err(411, "Thiếu dữ liệu file")
            return
        if is_update and length > 50 * 1024 * 1024:
            self.close_connection = True
            self._err(413, "update.zip lớn hơn 50 MB")
            return
        if length > MAX_BYTES:
            self.close_connection = True
            self._err(413, "File lớn hơn 500 MB")
            return
        batch = re.sub(r"[^A-Za-z0-9]", "", self.headers.get("X-Batch", ""))[:24] or uuid.uuid4().hex[:10]
        orig = unquote(self.headers.get("X-Name", "image"))[:200]
        item_dir = os.path.join(INBOX, uuid.uuid4().hex[:10])
        os.makedirs(item_dir, exist_ok=True)
        part = os.path.join(item_dir, ".part")
        kind, left, size, first = "", length, 0, True
        try:
            with open(part, "wb") as fh:
                while left > 0:
                    chunk = self.rfile.read(min(left, 1 << 20))
                    if not chunk:
                        raise ConnectionError("đứt kết nối")
                    if first:
                        kind = sniff(chunk[:16])
                        first = False
                    fh.write(chunk)
                    left -= len(chunk)
                    size += len(chunk)
        except (OSError, ConnectionError):
            shutil.rmtree(item_dir, ignore_errors=True)
            self.close_connection = True
            return
        stamp = time.strftime("%Y%m%d-%H%M%S")
        name = "update.zip" if is_update else safe_name(orig, kind, stamp)
        final = os.path.join(item_dir, name)
        os.replace(part, final)
        if is_update:
            changed = zip_changes(final)
            if changed < 0:
                shutil.rmtree(item_dir, ignore_errors=True)
                self._err(400, "update.zip bị lỗi hoặc không đọc được")
                return
            if changed == 0:
                shutil.rmtree(item_dir, ignore_errors=True)
                self._err(422, "update.zip không có file hệ thống nào thay đổi, TV không ghi đè gì")
                return
            if not PIN:          # có file hệ thống thay đổi: bắt buộc mã cập nhật (PIN cố định đã kiểm tra ở trên)
                now = time.time()
                with STATUS_LOCK:
                    UPD_FAILS[:] = [t for t in UPD_FAILS if now - t < 60]
                    locked = len(UPD_FAILS) >= 5
                    ok = not locked and hmac.compare_digest(got.encode("utf-8"), UPDATE_PIN.encode("utf-8"))
                    if not ok and not locked:
                        UPD_FAILS.append(now)
                if locked or not ok:
                    shutil.rmtree(item_dir, ignore_errors=True)
                    if locked:
                        self._err(429, "Nhập sai quá nhiều lần, thử lại sau 1 phút", needpin=True)
                    else:
                        self._err(403, "update.zip có %d file hệ thống thay đổi nên cần mã cập nhật hiện trên màn hình TV"
                                  % changed, needpin=True)
                    return
        with STATUS_LOCK:
            STATUS[batch] = "pending"
            while len(STATUS) > 200:
                STATUS.pop(next(iter(STATUS)))
        if is_update:
            rotate_update_pin()                    # mã chỉ dùng được một lần
        emit({"ev": "file", "batch": batch, "path": final, "dir": item_dir, "name": name, "size": size, "img": bool(kind),
              "upd": is_update, "from": self.client_address[0], "dev": device_name(self.headers.get("User-Agent", ""))})
        self._send(200, json.dumps({"ok": True}))


def rotate_update_pin():
    global UPDATE_PIN
    if PIN:
        return
    UPDATE_PIN = new_update_pin()
    emit({"ev": "pin", "updpin": UPDATE_PIN})


def stdin_loop():
    try:
        for line in sys.stdin:
            line = line.rstrip("\r\n")
            cmd, _, arg = line.partition(" ")
            if cmd in ("saved", "skipped") and arg.strip():
                with STATUS_LOCK:
                    STATUS[arg.strip()] = cmd
            elif cmd == "offer" and arg:
                offer_add(arg)
            elif cmd == "unoffer" and arg.strip():
                offer_drop(arg.strip())
            elif cmd == "unofferall":
                with OFFER_LOCK:
                    ids = list(OFFERS)
                for i in ids:
                    offer_drop(i)
    except (OSError, ValueError):
        pass
    os._exit(0)                                  # shell đã tắt -> thoát theo


def main():
    global PIN, INBOX, UPDATE_PIN, PORT
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=int(os.environ.get("SHARE_PORT", "8765")))
    ap.add_argument("--inbox", default=os.path.expanduser("~/.cache/arch-tv/share-inbox"))
    ap.add_argument("--no-stdin", action="store_true", help="không đọc stdin (chạy tay)")
    a = ap.parse_args()
    INBOX = os.path.abspath(a.inbox)
    os.makedirs(INBOX, exist_ok=True)
    clean_old(INBOX)
    PIN = os.environ.get("SHARE_PIN", "")
    if not PIN:
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "share.pin"), encoding="utf-8") as fh:
                PIN = fh.read().strip()[:16]
        except OSError:
            pass
    UPDATE_PIN = PIN or new_update_pin()
    srv = None
    for port in range(a.port, a.port + 10):
        try:
            ThreadingHTTPServer.daemon_threads = True
            ThreadingHTTPServer.allow_reuse_address = True
            srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
            break
        except OSError:
            continue
    if srv is None:
        emit({"ev": "error", "msg": "Không mở được cổng %d-%d (đang bị chiếm?)" % (a.port, a.port + 9)})
        sys.exit(2)
    PORT = srv.server_address[1]
    emit(ready_payload("ready"))
    threading.Thread(target=net_watch, daemon=True).start()
    if not a.no_stdin and not sys.stdin.isatty():
        threading.Thread(target=stdin_loop, daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
