#!/usr/bin/env bash
# Chép nhanh các file của Arch TV vào ~/.config/quickshell rồi nạp lại shell + Hyprland.
# Không cài gói, không cần sudo (muốn cài gói lần đầu thì dùng install.sh).
#   ./deploy.sh            chép + nạp lại Hyprland + khởi động lại shell
#   ./deploy.sh --no-hypr  không đụng tới hyprland.lua
#   ./deploy.sh --no-restart  chỉ chép file
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
QS="${QS_DIR:-$HOME/.config/quickshell}"          # shell nằm ở $QS/shell.qml, chạy bằng: qs
LUA="${HYPR_LUA:-$HOME/.config/hypr/hyprland.lua}"
MARK_BEGIN="-- >>> ARCH TV BEGIN"
MARK_END="-- <<< ARCH TV END"
DO_HYPR=1; DO_RESTART=1
for a in "$@"; do
    case "$a" in
        --no-hypr) DO_HYPR=0 ;;
        --no-restart) DO_RESTART=0 ;;
        -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
        *) echo "Tuỳ chọn lạ: $a"; exit 64 ;;
    esac
done
[ "$(id -u)" -ne 0 ] || { echo "Hãy chạy bằng user thường (không dùng sudo)."; exit 1; }
[ -f "$HERE/shell.qml" ] || { echo "Không thấy shell.qml cạnh deploy.sh"; exit 1; }

echo "==> Chép file vào $QS"
mkdir -p "$QS" "$HOME/Downloads" "$HOME/Share/send"
# shell.qml khác (không phải của Arch TV) thì sao lưu trước khi ghi đè
if [ -f "$QS/shell.qml" ] && ! grep -q "Arch TV" "$QS/shell.qml"; then
    cp "$QS/shell.qml" "$QS/shell.qml.bak"
    echo "    Đã sao lưu shell.qml cũ thành shell.qml.bak"
fi
n=0
for f in shell.qml share.py android-cast.sh tv-update.sh tv.lua VERSION; do
    [ -f "$HERE/$f" ] || continue
    if [ -f "$QS/$f" ] && cmp -s "$HERE/$f" "$QS/$f"; then continue; fi
    cp "$HERE/$f" "$QS/$f.new" && mv -f "$QS/$f.new" "$QS/$f"
    echo "    đã chép $f"
    n=$((n + 1))
done
chmod +x "$QS/tv-update.sh" 2>/dev/null || true
[ -f "$QS/android-cast.sh" ] && chmod +x "$QS/android-cast.sh"
python3 -c 'import sys;compile(open(sys.argv[1],encoding="utf-8").read(),sys.argv[1],"exec")' "$QS/share.py" \
    || { echo "share.py có lỗi cú pháp, dừng."; exit 1; }
[ "$n" -gt 0 ] || echo "    (không có file nào thay đổi)"
[ -d "$QS/tv" ] && echo "    Lưu ý: thư mục cũ $QS/tv không còn dùng, có thể xoá: rm -r $QS/tv"

if [ "$DO_HYPR" = 1 ] && [ -f "$HERE/tv.lua" ]; then
    echo "==> Cập nhật khối ARCH TV trong hyprland.lua"
    mkdir -p "$(dirname "$LUA")"
    block="$(mktemp)"
    { echo "$MARK_BEGIN"; cat "$HERE/tv.lua"; echo "$MARK_END"; } > "$block"
    if [ -f "$LUA" ]; then
        cp "$LUA" "$LUA.bak"
        if grep -qF -- "$MARK_BEGIN" "$LUA"; then
            awk -v b="$MARK_BEGIN" -v e="$MARK_END" -v f="$block" '
                index($0, b) { while ((getline line < f) > 0) print line; skip = 1; next }
                index($0, e) { skip = 0; next }
                !skip { print }
            ' "$LUA.bak" > "$LUA"
            echo "    Đã thay khối cũ (bản sao lưu: hyprland.lua.bak)"
        else
            { echo; cat "$block"; } >> "$LUA"
            echo "    Đã thêm khối mới vào cuối file (bản sao lưu: hyprland.lua.bak)"
        fi
    else
        { echo "-- ~/.config/hypr/hyprland.lua"; echo; cat "$block"; } > "$LUA"
        echo "    Đã tạo hyprland.lua mới"
    fi
    rm -f "$block"
    command -v hyprctl >/dev/null 2>&1 && hyprctl reload >/dev/null 2>&1 && echo "    Đã nạp lại Hyprland" || echo "    (chưa nạp lại được Hyprland: đang không chạy trong Hyprland?)"
fi

if [ "$DO_RESTART" = 1 ]; then
    echo "==> Khởi động lại shell"
    if ! command -v qs >/dev/null 2>&1; then
        echo "    Chưa có lệnh qs (quickshell). Chạy ./install.sh trước."; exit 1
    fi
    # chỉ tắt shell mặc định (shell.qml), không đụng tới shell khác như: qs -c study
    qs kill >/dev/null 2>&1 || pkill -fx 'qs' >/dev/null 2>&1 || true
    sleep 1
    mkdir -p "${XDG_CACHE_HOME:-$HOME/.cache}/arch-tv"
    if [ -n "${WAYLAND_DISPLAY:-}" ] || [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]; then
        setsid qs -d >/dev/null 2>&1 < /dev/null || setsid sh -c 'qs' >/dev/null 2>&1 < /dev/null &
        sleep 2
        if qs list >/dev/null 2>&1 && qs list 2>/dev/null | grep -q .; then
            echo "    Shell đã chạy lại."
        else
            echo "    Chưa thấy shell chạy. Xem lỗi bằng:  qs   (chạy ở terminal)"
        fi
    else
        echo "    Không thấy phiên Wayland: hãy chạy deploy.sh từ terminal trong Hyprland, hoặc chạy tay: qs -d"
    fi
fi
echo "Xong. Phiên bản: $(cat "$QS/VERSION" 2>/dev/null || echo '?')"
