#!/bin/sh
# Kết nối điện thoại Android không dây cho scrcpy (dùng "Gỡ lỗi không dây", Android 11 trở lên).
# Chạy được qua Wi-Fi hoặc qua đường USB-tethering (điện thoại cắm cáp chia sẻ mạng cho máy).
#   android-cast.sh auto                    thử: máy đã kết nối -> mDNS -> địa chỉ lần trước; không được thì xin địa chỉ
#   android-cast.sh connect <IP:cổng>       kết nối tới địa chỉ ở màn hình chính "Gỡ lỗi không dây"
#   android-cast.sh pair <IP:cổng> <mã>     ghép nối một lần (nút "Ghép nối thiết bị bằng mã ghép nối")
# Dòng in ra:  STEP|chữ   HINT|ip điện thoại (nếu đang qua USB)   NEED|connect   NEED|pair   OK|serial   ERR|lý do

CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/arch-tv"
LAST="$CACHE/adb-last"
mkdir -p "$CACHE"

command -v adb >/dev/null 2>&1 || { echo "ERR|Chưa cài adb (gói android-tools). Hãy chạy lại install.sh"; exit 0; }
command -v scrcpy >/dev/null 2>&1 || { echo "ERR|Chưa cài scrcpy. Hãy chạy lại install.sh"; exit 0; }

okaddr() { case "$1" in ''|*[!0-9A-Za-z.:_-]*) return 1 ;; esac; return 0; }

dev() { adb devices 2>/dev/null | awk 'NR>1 && $2=="device" {print $1; exit}'; }
done_ok() { s="$(dev)"; if [ -n "$s" ]; then echo "OK|$s"; exit 0; fi; }

# Đang lấy internet từ điện thoại qua cáp USB thì cổng mặc định chính là điện thoại
hint() {
    d="$(ip -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}')"
    g="$(ip -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="via"){print $(i+1); exit}}')"
    [ -n "$d" ] && [ -n "$g" ] && readlink -f "/sys/class/net/$d/device" 2>/dev/null | grep -q /usb && echo "HINT|$g"
    return 0
}

try_connect() {
    out="$(timeout 10 adb connect "$1" 2>&1)"
    case "$out" in
        *"connected to"*|*"already connected"*)
            printf '%s\n' "$1" > "$LAST"
            sleep 1
            done_ok ;;
    esac
    LASTERR="$out"
    return 1
}

mdns_connect() {
    for c in $(adb mdns services 2>/dev/null | awk '/_adb-tls-connect/ {print $NF}'); do
        okaddr "$c" && try_connect "$c"
    done
}

case "$1" in
    auto)
        echo "STEP|Đang tìm điện thoại Android…"
        adb start-server >/dev/null 2>&1
        done_ok
        mdns_connect
        if [ -f "$LAST" ]; then
            c="$(head -n1 "$LAST")"
            okaddr "$c" && try_connect "$c"
        fi
        hint
        echo "NEED|connect"
        ;;
    connect)
        okaddr "$2" || { echo "ERR|Địa chỉ không hợp lệ"; exit 0; }
        echo "STEP|Đang kết nối $2…"
        adb start-server >/dev/null 2>&1
        try_connect "$2"
        case "$LASTERR" in
            *uthenticat*|*nauthorized*|*"not paired"*) hint; echo "NEED|pair" ;;
            *) echo "ERR|Không kết nối được: $LASTERR. Kiểm tra địa chỉ và cổng, hoặc nhấn W rồi gõ P để ghép nối." ;;
        esac
        ;;
    pair)
        okaddr "$2" || { echo "ERR|Địa chỉ không hợp lệ"; exit 0; }
        case "$3" in ''|*[!0-9]*) echo "ERR|Mã ghép nối phải là số"; exit 0 ;; esac
        echo "STEP|Đang ghép nối…"
        adb start-server >/dev/null 2>&1
        out="$(timeout 20 adb pair "$2" "$3" 2>&1)"
        case "$out" in
            *"Successfully paired"*)
                echo "STEP|Đã ghép nối, đang kết nối…"
                sleep 2
                done_ok
                mdns_connect
                hint
                echo "NEED|connect" ;;
            *) echo "ERR|Ghép nối thất bại: $out (sai mã hoặc mã đã hết hạn?)" ;;
        esac
        ;;
    *)
        echo "ERR|Cách dùng: android-cast.sh auto | connect IP:cổng | pair IP:cổng mã"
        ;;
esac
exit 0
